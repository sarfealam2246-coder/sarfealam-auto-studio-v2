import { useState } from 'react';
import { Check, Code2, Copy, Download, Save, X } from 'lucide-react';
import type { GeneratedFile } from '../types/studio';

interface CodePanelProps {
  files: GeneratedFile[];
  onUpdateFile: (path: string, content: string) => void;
  onStartBuild: () => void;
  onClose: () => void;
}

export function CodePanel({ files, onUpdateFile, onStartBuild, onClose }: CodePanelProps) {
  const [selectedPath, setSelectedPath] = useState<string>(files[0]?.path ?? '');
  const [copied, setCopied] = useState(false);
  const [savedNotice, setSavedNotice] = useState(false);

  const activeFile = files.find((f) => f.path === selectedPath) ?? files[0] ?? null;

  async function handleCopy() {
    if (!activeFile) return;
    try {
      await navigator.clipboard.writeText(activeFile.content);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      // ignore
    }
  }

  function handleDownload() {
    if (!activeFile) return;
    const blob = new Blob([activeFile.content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = activeFile.path.split('/').pop() || 'studio-file.txt';
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <section
      aria-label="Generated Code Inspector"
      className="rounded-2xl border border-violet-400/30 bg-[#070C1B]/95 p-4 sm:p-5"
    >
      <div className="flex items-center justify-between gap-3 border-b border-white/[0.08] pb-3">
        <div className="flex items-center gap-2">
          <Code2 className="h-5 w-5 text-violet-300" />
          <div>
            <h2 className="font-display text-base font-semibold text-slate-100">
              Generated Code Inspector
            </h2>
            <p className="text-xs text-slate-400 font-mono tabular-nums">
              {files.length} file{files.length === 1 ? '' : 's'} in live World State
            </p>
          </div>
        </div>
        <button
          type="button"
          onClick={onClose}
          aria-label="Close Code Panel"
          className="flex h-9 w-9 items-center justify-center rounded-lg border border-white/10 bg-white/[0.04] text-slate-300 hover:text-white cursor-pointer"
        >
          <X className="h-4 w-4" />
        </button>
      </div>

      {files.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-10 text-center">
          <p className="text-sm text-slate-300">No generated files in the workspace yet.</p>
          <p className="mt-1 text-xs text-slate-400">
            Tap “OK · Build/APK” or tell JARVIS what to build to generate live source code.
          </p>
          <button
            type="button"
            onClick={onStartBuild}
            className="mt-4 rounded-xl bg-cyan-500 px-4 py-2 text-xs font-semibold text-slate-950 hover:bg-cyan-400 cursor-pointer"
          >
            Run Starter Build
          </button>
        </div>
      ) : (
        <div className="mt-3 space-y-3">
          {/* File Tabs */}
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex flex-wrap items-center gap-1.5">
              {files.map((file) => {
                const isSelected = activeFile?.path === file.path;
                return (
                  <button
                    key={file.path}
                    type="button"
                    onClick={() => setSelectedPath(file.path)}
                    className={`rounded-lg border px-2.5 py-1.5 font-mono text-xs transition-colors cursor-pointer ${
                      isSelected
                        ? 'border-violet-400/50 bg-violet-500/20 text-violet-100'
                        : 'border-white/10 bg-[#0B1225] text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {file.path}
                  </button>
                );
              })}
            </div>

            <div className="flex items-center gap-1.5">
              {savedNotice && (
                <span className="text-xs text-emerald-300 mr-1">Saved to World State</span>
              )}
              <button
                type="button"
                onClick={handleCopy}
                className="inline-flex h-8 items-center gap-1 rounded-lg border border-white/10 bg-[#0B1225] px-2.5 text-xs text-slate-200 hover:border-cyan-400/40 cursor-pointer"
              >
                {copied ? <Check className="h-3.5 w-3.5 text-emerald-300" /> : <Copy className="h-3.5 w-3.5" />}
                <span>{copied ? 'Copied' : 'Copy'}</span>
              </button>
              <button
                type="button"
                onClick={handleDownload}
                className="inline-flex h-8 items-center gap-1 rounded-lg border border-white/10 bg-[#0B1225] px-2.5 text-xs text-slate-200 hover:border-cyan-400/40 cursor-pointer"
              >
                <Download className="h-3.5 w-3.5" />
                <span>Download</span>
              </button>
            </div>
          </div>

          {/* Live Editable Code Surface */}
          {activeFile && (
            <div className="relative">
              <textarea
                aria-label={`Source code for ${activeFile.path}`}
                value={activeFile.content}
                onChange={(e) => {
                  onUpdateFile(activeFile.path, e.target.value);
                  setSavedNotice(true);
                  setTimeout(() => setSavedNotice(false), 1200);
                }}
                spellCheck={false}
                rows={13}
                className="w-full rounded-xl border border-white/10 bg-[#040711] p-3.5 font-mono text-xs leading-relaxed text-cyan-100 focus:border-violet-400/50 focus:outline-none"
              />
              <div className="mt-1.5 flex items-center justify-between text-[11px] text-slate-500 font-mono">
                <span>Language: {activeFile.language}</span>
                <span className="inline-flex items-center gap-1">
                  <Save className="h-3 w-3" /> Auto-persisted to localStorage
                </span>
              </div>
            </div>
          )}
        </div>
      )}
    </section>
  );
}
