import type {
  ActiveBuildJob,
  AppsRemoteConfig,
  EngineType,
  ErrorMemoryRecord,
  GeneratedFile,
  StudioAssetItem,
  SupabaseEndpointConfig,
  WorldState,
} from '../types/studio';

const LOCAL_ACTIVE_JOB_KEY = 'sarfealam_active_job_v1';
const LOCAL_ERROR_MEMORY_KEY = 'sarfealam_error_memory_v1';

// ============================================================================
// 1. STRICTLY ISOLATED DUAL SUPABASE SQL SCHEMAS (RLS ENABLED)
// ============================================================================

export const STUDIO_SUPABASE_SQL = `-- 1. Studio Supabase Schema (Strictly Isolated from Exported Apps)
-- Tables: studio_state, user_rules, dynamic_skills, error_memory, active_jobs

create table if not exists public.studio_state (
  id text primary key default 'primary',
  active_prompt text default '',
  selected_engine text default 'Auto',
  paused boolean default false,
  current_stage integer default 0,
  world_snapshot jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

create table if not exists public.user_rules (
  id text primary key,
  rule text not null,
  created_at timestamptz not null default now()
);

create table if not exists public.dynamic_skills (
  id text primary key,
  name text not null,
  role text not null,
  skill_payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists public.error_memory (
  id text primary key,
  engine text not null default 'Capacitor 3D/App',
  error_signature text not null,
  diagnosis text not null,
  fix_summary text not null,
  patched_path text not null,
  patched_content_snippet text not null default '',
  created_at timestamptz not null default now()
);

create table if not exists public.active_jobs (
  id text primary key,
  prompt text not null default '',
  selected_engine text not null default 'Auto',
  current_stage integer not null default 0,
  github_repo text not null default '',
  github_run_id bigint,
  status text not null default 'pushing',
  heal_round integer not null default 0,
  selected_assets jsonb not null default '[]'::jsonb,
  generated_files jsonb not null default '[]'::jsonb,
  job_payload jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

alter table public.studio_state enable row level security;
alter table public.user_rules enable row level security;
alter table public.dynamic_skills enable row level security;
alter table public.error_memory enable row level security;
alter table public.active_jobs enable row level security;

drop policy if exists "Studio state anon full access" on public.studio_state;
create policy "Studio state anon full access"
  on public.studio_state for all using (true) with check (true);

drop policy if exists "User rules anon full access" on public.user_rules;
create policy "User rules anon full access"
  on public.user_rules for all using (true) with check (true);

drop policy if exists "Dynamic skills anon full access" on public.dynamic_skills;
create policy "Dynamic skills anon full access"
  on public.dynamic_skills for all using (true) with check (true);

drop policy if exists "Error memory anon full access" on public.error_memory;
create policy "Error memory anon full access"
  on public.error_memory for all using (true) with check (true);

drop policy if exists "Active jobs anon full access" on public.active_jobs;
create policy "Active jobs anon full access"
  on public.active_jobs for all using (true) with check (true);`;

export const APPS_SUPABASE_SQL = `-- 2. Apps Supabase Schema (Dedicated & Strictly Isolated for Exported APKs + Owner Admin Web)
-- Table: apps_config

create table if not exists public.apps_config (
  id uuid primary key default gen_random_uuid(),
  app_slug text unique not null,
  app_name text not null,
  engine text not null default 'Capacitor 3D/App',
  version_name text not null default '1.0.0',
  banner_text text not null default 'Welcome! Live remote offers active.',
  discount_percent integer not null default 0 check (discount_percent >= 0 and discount_percent <= 95),
  game_speed numeric(4,2) not null default 1.00 check (game_speed >= 0.25 and game_speed <= 3.00),
  difficulty text not null default 'normal' check (difficulty in ('easy', 'normal', 'hard')),
  owner_pin_hash text default '',
  feature_flags jsonb not null default '{}'::jsonb,
  remote_assets jsonb not null default '[]'::jsonb,
  updated_at timestamptz not null default now()
);

alter table public.apps_config enable row level security;

drop policy if exists "Exported apps config read/write" on public.apps_config;
create policy "Exported apps config read/write"
  on public.apps_config for all using (true) with check (true);`;

function normalizeSupabaseEndpoint(config: SupabaseEndpointConfig): {
  baseUrl: string;
  anonKey: string;
} | null {
  const baseUrl = config.url.trim().replace(/\/+$/, '');
  const anonKey = config.anonKey.trim();
  if (!baseUrl || !anonKey) return null;
  if (!/^https?:\/\//i.test(baseUrl)) return null;
  return { baseUrl, anonKey };
}

function buildRestHeaders(anonKey: string, extra?: Record<string, string>): Record<string, string> {
  return {
    apikey: anonKey,
    Authorization: `Bearer ${anonKey}`,
    Accept: 'application/json',
    ...extra,
  };
}

// ============================================================================
// 2. LOCAL + STUDIO SUPABASE: ACTIVE JOBS AUTO-RESUME PERSISTENCE
// ============================================================================

export function loadLocalActiveJob(): ActiveBuildJob | null {
  try {
    const raw = localStorage.getItem(LOCAL_ACTIVE_JOB_KEY);
    if (!raw) return null;
    return JSON.parse(raw) as ActiveBuildJob;
  } catch {
    return null;
  }
}

export function saveLocalActiveJob(job: ActiveBuildJob | null): void {
  try {
    if (!job) {
      localStorage.removeItem(LOCAL_ACTIVE_JOB_KEY);
    } else {
      localStorage.setItem(LOCAL_ACTIVE_JOB_KEY, JSON.stringify(job));
    }
  } catch (err) {
    console.warn('[SupabaseClient] Could not persist local active job:', err);
  }
}

export async function persistActiveJobToStudioSupabase(
  job: ActiveBuildJob,
  state: Pick<WorldState, 'activePrompt' | 'selectedEngine' | 'currentStage' | 'selectedAssets' | 'generatedFiles'>,
  studioConfig: SupabaseEndpointConfig
): Promise<boolean> {
  saveLocalActiveJob(job);
  const ep = normalizeSupabaseEndpoint(studioConfig);
  if (!ep) return false;

  try {
    // Keep generated_files reasonably sized for REST JSON payload
    const compactFiles = state.generatedFiles.slice(0, 24).map((f) => ({
      path: f.path,
      language: f.language,
      content: f.content.slice(0, 65000),
      updatedAt: f.updatedAt,
    }));

    const res = await fetch(`${ep.baseUrl}/rest/v1/active_jobs`, {
      method: 'POST',
      headers: buildRestHeaders(ep.anonKey, {
        'Content-Type': 'application/json',
        Prefer: 'resolution=merge-duplicates',
      }),
      body: JSON.stringify({
        id: 'primary_active_job',
        prompt: state.activePrompt || job.prompt,
        selected_engine: state.selectedEngine || job.engine,
        current_stage: state.currentStage,
        github_repo: job.repoFullName,
        github_run_id: job.githubRunId ?? null,
        status: job.status,
        heal_round: job.healRound,
        selected_assets: state.selectedAssets.slice(0, 24),
        generated_files: compactFiles,
        job_payload: job,
        updated_at: new Date().toISOString(),
      }),
    });
    return res.ok;
  } catch {
    return false;
  }
}

export interface RestoredCloudJobSnapshot {
  job: ActiveBuildJob;
  prompt: string;
  selectedEngine: EngineType;
  currentStage: number;
  selectedAssets: StudioAssetItem[];
  generatedFiles: GeneratedFile[];
}

export async function loadActiveJobFromStudioSupabase(
  studioConfig: SupabaseEndpointConfig
): Promise<RestoredCloudJobSnapshot | null> {
  const ep = normalizeSupabaseEndpoint(studioConfig);
  if (!ep) return null;

  try {
    const res = await fetch(
      `${ep.baseUrl}/rest/v1/active_jobs?id=eq.${encodeURIComponent('primary_active_job')}&select=*&limit=1`,
      {
        method: 'GET',
        headers: buildRestHeaders(ep.anonKey),
      }
    );
    if (!res.ok) return null;
    const rows = (await res.json()) as Array<{
      prompt?: string;
      selected_engine?: EngineType;
      current_stage?: number;
      selected_assets?: StudioAssetItem[];
      generated_files?: GeneratedFile[];
      job_payload?: ActiveBuildJob;
    }>;
    const row = rows[0];
    if (!row || !row.job_payload || !row.job_payload.repoFullName) return null;

    return {
      job: row.job_payload,
      prompt: row.prompt || row.job_payload.prompt || '',
      selectedEngine: row.selected_engine || row.job_payload.engine || 'Auto',
      currentStage: typeof row.current_stage === 'number' ? row.current_stage : 5,
      selectedAssets: Array.isArray(row.selected_assets) ? row.selected_assets : [],
      generatedFiles: Array.isArray(row.generated_files) ? row.generated_files : [],
    };
  } catch {
    return null;
  }
}

// ============================================================================
// 3. STUDIO SUPABASE: ERROR MEMORY (SELF-HEALING KNOWLEDGE BASE)
// ============================================================================

function loadLocalErrorMemory(): ErrorMemoryRecord[] {
  try {
    const raw = localStorage.getItem(LOCAL_ERROR_MEMORY_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? (parsed as ErrorMemoryRecord[]) : [];
  } catch {
    return [];
  }
}

function saveLocalErrorMemory(records: ErrorMemoryRecord[]): void {
  try {
    localStorage.setItem(LOCAL_ERROR_MEMORY_KEY, JSON.stringify(records.slice(0, 40)));
  } catch {
    // ignore quota errors
  }
}

export async function searchErrorMemory(
  errorLog: string,
  engine: EngineType,
  studioConfig: SupabaseEndpointConfig
): Promise<ErrorMemoryRecord | null> {
  const tokens = errorLog
    .toLowerCase()
    .replace(/[^a-z0-9_.\-/\s]/g, ' ')
    .split(/\s+/)
    .filter((t) => t.length >= 4)
    .slice(0, 24);

  const scoreRecord = (rec: ErrorMemoryRecord): number => {
    const haystack = `${rec.errorSignature} ${rec.diagnosis} ${rec.patchedPath}`.toLowerCase();
    let score = rec.engine === engine ? 2 : 0;
    for (const tok of tokens) {
      if (haystack.includes(tok)) score += 1;
    }
    return score;
  };

  let candidates: ErrorMemoryRecord[] = loadLocalErrorMemory();

  const ep = normalizeSupabaseEndpoint(studioConfig);
  if (ep) {
    try {
      const res = await fetch(
        `${ep.baseUrl}/rest/v1/error_memory?engine=eq.${encodeURIComponent(engine)}&order=created_at.desc&limit=25`,
        {
          method: 'GET',
          headers: buildRestHeaders(ep.anonKey),
        }
      );
      if (res.ok) {
        const rows = (await res.json()) as Array<{
          id: string;
          engine: EngineType;
          error_signature: string;
          diagnosis: string;
          fix_summary: string;
          patched_path: string;
          patched_content_snippet: string;
          created_at: string;
        }>;
        const remoteRecords: ErrorMemoryRecord[] = rows.map((r) => ({
          id: r.id,
          engine: r.engine,
          errorSignature: r.error_signature,
          diagnosis: r.diagnosis,
          fixSummary: r.fix_summary,
          patchedPath: r.patched_path,
          patchedContentSnippet: r.patched_content_snippet,
          createdAt: Date.parse(r.created_at) || Date.now(),
        }));
        candidates = [...remoteRecords, ...candidates];
      }
    } catch {
      // Fall back to local cache seamlessly
    }
  }

  let best: ErrorMemoryRecord | null = null;
  let bestScore = 3; // Require meaningful overlap
  for (const rec of candidates) {
    const sc = scoreRecord(rec);
    if (sc > bestScore) {
      bestScore = sc;
      best = rec;
    }
  }

  return best;
}

export async function saveErrorMemory(
  record: ErrorMemoryRecord,
  studioConfig: SupabaseEndpointConfig
): Promise<boolean> {
  const local = loadLocalErrorMemory();
  saveLocalErrorMemory([record, ...local.filter((r) => r.id !== record.id)]);

  const ep = normalizeSupabaseEndpoint(studioConfig);
  if (!ep) return false;

  try {
    const res = await fetch(`${ep.baseUrl}/rest/v1/error_memory`, {
      method: 'POST',
      headers: buildRestHeaders(ep.anonKey, {
        'Content-Type': 'application/json',
        Prefer: 'resolution=merge-duplicates',
      }),
      body: JSON.stringify({
        id: record.id,
        engine: record.engine,
        error_signature: record.errorSignature.slice(0, 320),
        diagnosis: record.diagnosis.slice(0, 500),
        fix_summary: record.fixSummary.slice(0, 500),
        patched_path: record.patchedPath,
        patched_content_snippet: record.patchedContentSnippet.slice(0, 2000),
        created_at: new Date(record.createdAt).toISOString(),
      }),
    });
    return res.ok;
  } catch {
    return false;
  }
}

// ============================================================================
// 4. APPS SUPABASE: STRICTLY ISOLATED REMOTE CONFIG (EXPORTED APKS & ADMIN WEB)
// ============================================================================

export async function upsertAppsRemoteConfig(
  payload: AppsRemoteConfig,
  appsConfig: SupabaseEndpointConfig
): Promise<{ ok: boolean; httpStatus: number; message: string }> {
  const ep = normalizeSupabaseEndpoint(appsConfig);
  if (!ep) {
    return {
      ok: false,
      httpStatus: 0,
      message: 'Apps Supabase URL and Anon Key are not configured in Secrets Vault.',
    };
  }

  try {
    const clampedDiscount = Math.max(0, Math.min(95, Math.round(payload.discountPercent)));
    const clampedSpeed = Math.max(0.25, Math.min(3.0, Number(payload.gameSpeed) || 1));

    const res = await fetch(`${ep.baseUrl}/rest/v1/apps_config?on_conflict=app_slug`, {
      method: 'POST',
      headers: buildRestHeaders(ep.anonKey, {
        'Content-Type': 'application/json',
        Prefer: 'resolution=merge-duplicates',
      }),
      body: JSON.stringify({
        app_slug: payload.appSlug,
        app_name: payload.appName,
        engine: payload.engine,
        version_name: payload.versionName,
        banner_text: payload.bannerText,
        discount_percent: clampedDiscount,
        game_speed: clampedSpeed,
        difficulty: payload.difficulty,
        owner_pin_hash: payload.ownerPinHash ?? '',
        feature_flags: {
          bannerText: payload.bannerText,
          discountPercent: clampedDiscount,
          gameSpeed: clampedSpeed,
          difficulty: payload.difficulty,
        },
        updated_at: new Date().toISOString(),
      }),
    });

    if (res.ok) {
      return {
        ok: true,
        httpStatus: res.status,
        message: `Live remote config synced to Apps Supabase (${payload.appSlug}).`,
      };
    }

    const errText = await res.text().catch(() => '');
    return {
      ok: false,
      httpStatus: res.status,
      message: `Apps Supabase HTTP ${res.status}: ${errText.slice(0, 140) || res.statusText}`,
    };
  } catch (err) {
    return {
      ok: false,
      httpStatus: 0,
      message: err instanceof Error ? err.message : 'Network error updating Apps Supabase.',
    };
  }
}

export async function fetchAppsRemoteConfig(
  appSlug: string,
  appsConfig: SupabaseEndpointConfig
): Promise<AppsRemoteConfig | null> {
  const ep = normalizeSupabaseEndpoint(appsConfig);
  if (!ep || !appSlug.trim()) return null;

  try {
    const res = await fetch(
      `${ep.baseUrl}/rest/v1/apps_config?app_slug=eq.${encodeURIComponent(appSlug.trim())}&select=*&limit=1`,
      {
        method: 'GET',
        headers: buildRestHeaders(ep.anonKey),
      }
    );
    if (!res.ok) return null;
    const rows = (await res.json()) as Array<{
      app_slug: string;
      app_name: string;
      engine: EngineType;
      version_name: string;
      banner_text?: string;
      discount_percent?: number;
      game_speed?: number;
      difficulty?: 'easy' | 'normal' | 'hard';
      owner_pin_hash?: string;
      updated_at?: string;
    }>;
    const row = rows[0];
    if (!row) return null;

    return {
      appSlug: row.app_slug,
      appName: row.app_name,
      engine: row.engine || 'Capacitor 3D/App',
      versionName: row.version_name || '1.0.0',
      bannerText: row.banner_text ?? 'Welcome! Live remote offers active.',
      discountPercent: typeof row.discount_percent === 'number' ? row.discount_percent : 0,
      gameSpeed: typeof row.game_speed === 'number' ? Number(row.game_speed) : 1.0,
      difficulty: row.difficulty || 'normal',
      ownerPinHash: row.owner_pin_hash || '',
      updatedAt: row.updated_at ? Date.parse(row.updated_at) : Date.now(),
    };
  } catch {
    return null;
  }
}
