import { callActiveLLM } from './aiRouter';
import { studioBus } from './eventBus';
import {
  getApkWorkflowFileName,
  pushAtomicGitTreeCommit,
  resolveEffectiveEngine,
  type AtomicExportFile,
} from './githubExporter';
import {
  persistActiveJobToStudioSupabase,
  saveErrorMemory,
  searchErrorMemory,
} from './supabaseClient';
import type {
  ActiveBuildJob,
  ErrorMemoryRecord,
  GeneratedFile,
  ReleaseLinks,
  SecretsConfig,
  WorldState,
} from '../types/studio';

const GITHUB_API = 'https://api.github.com';
const POLL_INTERVAL_MS = 12_000;

function ghHeaders(pat: string): Record<string, string> {
  return {
    Accept: 'application/vnd.github+json',
    Authorization: `Bearer ${pat.trim()}`,
    'X-GitHub-Api-Version': '2022-11-28',
  };
}

interface GitHubActionRun {
  id: number;
  name?: string;
  path?: string;
  status: string;
  conclusion: string | null;
  html_url: string;
  head_sha: string;
  created_at: string;
}

interface GitHubActionJob {
  id: number;
  name: string;
  status: string;
  conclusion: string | null;
  html_url: string;
  steps?: Array<{
    name: string;
    status: string;
    conclusion: string | null;
    number: number;
  }>;
}

interface GitHubRelease {
  html_url: string;
  tag_name: string;
  assets?: Array<{
    name: string;
    browser_download_url: string;
    size: number;
  }>;
}

interface SelfHealPatchResponse {
  diagnosis: string;
  summary: string;
  patches: AtomicExportFile[];
}

export interface SelfHealCallbacks {
  isPaused: () => boolean;
  isAborted: () => boolean;
  getWorldState: () => WorldState;
  getSecrets: () => SecretsConfig;
  onJobUpdated: (job: ActiveBuildJob, releaseLinks?: Partial<ReleaseLinks>) => void;
  onFilesPatched: (patches: AtomicExportFile[]) => void;
  onLogMessage: (message: string, provider?: string) => void;
}

async function sleepInterruptible(
  ms: number,
  isAborted: () => boolean,
  isPaused: () => boolean
): Promise<boolean> {
  const step = 300;
  let elapsed = 0;
  while (elapsed < ms) {
    if (isAborted()) return false;
    if (isPaused()) {
      await new Promise((r) => setTimeout(r, 400));
      continue;
    }
    await new Promise((r) => setTimeout(r, step));
    elapsed += step;
  }
  return !isAborted();
}

async function fetchLatestApkRelease(
  owner: string,
  repoName: string,
  pat: string
): Promise<{ apkUrl: string; apkName: string; releaseUrl: string } | null> {
  const base = `${GITHUB_API}/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repoName)}`;

  const inspectRelease = (rel: GitHubRelease | null) => {
    if (!rel || !Array.isArray(rel.assets)) return null;
    const apk = rel.assets.find((a) => a.name.toLowerCase().endsWith('.apk'));
    if (!apk || !/^https:\/\//i.test(apk.browser_download_url)) return null;
    return {
      apkUrl: apk.browser_download_url,
      apkName: apk.name,
      releaseUrl: rel.html_url,
    };
  };

  try {
    const latestRes = await fetch(`${base}/releases/latest`, {
      method: 'GET',
      headers: ghHeaders(pat),
    });
    if (latestRes.ok) {
      const found = inspectRelease((await latestRes.json()) as GitHubRelease);
      if (found) return found;
    }

    const listRes = await fetch(`${base}/releases?per_page=5`, {
      method: 'GET',
      headers: ghHeaders(pat),
    });
    if (listRes.ok) {
      const releases = (await listRes.json()) as GitHubRelease[];
      for (const rel of releases) {
        const found = inspectRelease(rel);
        if (found) return found;
      }
    }
  } catch {
    // ignore transient poll error
  }
  return null;
}

async function fetchFailingJobLog(
  owner: string,
  repoName: string,
  runId: number,
  pat: string
): Promise<{ jobName: string; failedStep: string; logExcerpt: string }> {
  const base = `${GITHUB_API}/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repoName)}`;
  const jobsRes = await fetch(`${base}/actions/runs/${runId}/jobs`, {
    method: 'GET',
    headers: ghHeaders(pat),
  });

  if (!jobsRes.ok) {
    return {
      jobName: 'APK Build Job',
      failedStep: 'Unknown step',
      logExcerpt: `Could not fetch jobs list (HTTP ${jobsRes.status}).`,
    };
  }

  const jobsPayload = (await jobsRes.json()) as { jobs?: GitHubActionJob[] };
  const jobs = jobsPayload.jobs ?? [];
  const failedJob = jobs.find((j) => j.conclusion === 'failure') || jobs[0];

  if (!failedJob) {
    return {
      jobName: 'APK Build Job',
      failedStep: 'No job details',
      logExcerpt: 'GitHub Actions run failed without returning job metadata.',
    };
  }

  const failedStepObj = failedJob.steps?.find((s) => s.conclusion === 'failure');
  const failedStep = failedStepObj?.name || 'Build step failed';

  let logExcerpt = `Failed job: ${failedJob.name} · Failed step: ${failedStep}`;
  try {
    const logRes = await fetch(`${base}/actions/jobs/${failedJob.id}/logs`, {
      method: 'GET',
      headers: ghHeaders(pat),
    });
    if (logRes.ok) {
      const rawLog = await logRes.text();
      // Extract the last 3600 chars where compiler/gradle/export errors actually appear
      const lines = rawLog.split('\n');
      const errorLines = lines.filter((l) =>
        /error|fatal|exception|failed|cannot find|missing|not found|exit code/i.test(l)
      );
      const tail = rawLog.slice(-3000);
      logExcerpt = [
        `Job: ${failedJob.name} | Step: ${failedStep}`,
        errorLines.length > 0 ? `Key Errors:\n${errorLines.slice(-25).join('\n')}` : '',
        `Log Tail:\n${tail}`,
      ]
        .filter(Boolean)
        .join('\n\n')
        .slice(0, 4800);
    }
  } catch {
    // Some browsers block cross-origin redirect to pipelines.actions.githubusercontent.com;
    // preserve exact step summary cleanly for LLM diagnosis.
    logExcerpt = `Job "${failedJob.name}" failed at step "${failedStep}" (${failedJob.html_url}). Steps summary: ${(failedJob.steps || [])
      .map((s) => `${s.number}. ${s.name} [${s.conclusion || s.status}]`)
      .join(' | ')}`;
  }

  return { jobName: failedJob.name, failedStep, logExcerpt };
}

function parseHealJson(rawText: string): SelfHealPatchResponse | null {
  const cleaned = rawText
    .replace(/^```json\s*/i, '')
    .replace(/^```\s*/i, '')
    .replace(/```\s*$/i, '')
    .trim();

  const tryParse = (str: string): SelfHealPatchResponse | null => {
    try {
      const parsed = JSON.parse(str) as Partial<SelfHealPatchResponse>;
      if (!Array.isArray(parsed.patches) || parsed.patches.length === 0) return null;
      const validPatches = parsed.patches
        .filter(
          (p): p is AtomicExportFile =>
            Boolean(p) && typeof p.path === 'string' && typeof p.content === 'string' && p.path.trim().length > 0
        )
        .map((p) => ({
          path: p.path.replace(/^\/+/, ''),
          content: p.content,
        }));
      if (validPatches.length === 0) return null;
      return {
        diagnosis: String(parsed.diagnosis || 'Build failure diagnosed'),
        summary: String(parsed.summary || 'Applied automated CI patch'),
        patches: validPatches,
      };
    } catch {
      return null;
    }
  };

  const direct = tryParse(cleaned);
  if (direct) return direct;

  const first = cleaned.indexOf('{');
  const last = cleaned.lastIndexOf('}');
  if (first !== -1 && last > first) {
    return tryParse(cleaned.slice(first, last + 1));
  }
  return null;
}

async function retriggerWorkflowIfNeeded(
  owner: string,
  repoName: string,
  workflowFile: string,
  pat: string
): Promise<void> {
  try {
    await fetch(
      `${GITHUB_API}/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repoName)}/actions/workflows/${encodeURIComponent(workflowFile)}/dispatches`,
      {
        method: 'POST',
        headers: {
          ...ghHeaders(pat),
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ ref: 'main' }),
      }
    );
  } catch {
    // Atomic push already triggers `on: push`, dispatch is only a safety backup
  }
}

export async function runSelfHealingActionsLoop(
  initialJob: ActiveBuildJob,
  callbacks: SelfHealCallbacks
): Promise<void> {
  let job: ActiveBuildJob = { ...initialJob };
  const effectiveEngine = resolveEffectiveEngine(job.engine);
  const targetWorkflowFile = getApkWorkflowFileName(effectiveEngine);
  let lastPendingHealFix: ErrorMemoryRecord | null = null;
  let lastCheckedFailedRunId = 0;

  const emitJob = (patch: Partial<ActiveBuildJob>, linkPatch?: Partial<ReleaseLinks>) => {
    job = {
      ...job,
      ...patch,
      updatedAt: Date.now(),
    };
    callbacks.onJobUpdated(job, linkPatch);
    const st = callbacks.getWorldState();
    const sec = callbacks.getSecrets();
    persistActiveJobToStudioSupabase(job, st, sec.studioSupabase).catch(() => {});
  };

  studioBus.emit('bot:progress', {
    botId: 'github-heal',
    status: 'active',
    task: `Monitoring ${job.repoName}`,
    progress: 25,
  });

  // Poll up to ~15 minutes total across up to 3 auto-heal rounds
  for (let tick = 0; tick < 80; tick++) {
    if (callbacks.isAborted()) return;

    if (callbacks.isPaused()) {
      emitJob({ status: 'paused', statusMessage: 'Paused monitoring — resume anytime.' });
      studioBus.emit('bot:progress', {
        botId: 'github-heal',
        status: 'paused',
        task: 'Monitor paused',
        progress: 50,
      });
      const resumed = await sleepInterruptible(1000, callbacks.isAborted, callbacks.isPaused);
      if (!resumed) return;
      continue;
    }

    const secrets = callbacks.getSecrets();
    const pat = secrets.githubPat.trim();
    if (!pat) {
      emitJob({
        status: 'failed',
        statusMessage: 'GitHub PAT removed from Secrets Vault — stopped polling.',
      });
      return;
    }

    const runsUrl = `${GITHUB_API}/repos/${encodeURIComponent(job.repoOwner)}/${encodeURIComponent(job.repoName)}/actions/runs?per_page=10`;
    let runs: GitHubActionRun[] = [];
    try {
      const res = await fetch(runsUrl, { method: 'GET', headers: ghHeaders(pat) });
      if (res.ok) {
        const data = (await res.json()) as { workflow_runs?: GitHubActionRun[] };
        runs = data.workflow_runs ?? [];
      }
    } catch {
      // Transient network hiccup — retry next 12s poll
    }

    // Prioritize the APK workflow run over Pages deploy run
    const apkRun =
      runs.find((r) => r.path?.endsWith(targetWorkflowFile)) ||
      runs.find((r) => /apk|android|godot|flutter|unity/i.test(r.name || '')) ||
      runs[0];

    if (!apkRun) {
      emitJob({
        status: 'queued',
        statusMessage: `Waiting for GitHub Actions (${targetWorkflowFile}) to register...`,
      });
      studioBus.emit('bot:progress', {
        botId: 'github-heal',
        status: 'active',
        task: 'Waiting for Actions queue',
        progress: 30,
      });
      if (!(await sleepInterruptible(POLL_INTERVAL_MS, callbacks.isAborted, callbacks.isPaused))) return;
      continue;
    }

    // Track active run
    if (apkRun.status !== 'completed') {
      const pct = apkRun.status === 'in_progress' ? Math.min(85, 40 + (tick % 8) * 6) : 32;
      emitJob({
        githubRunId: apkRun.id,
        runHtmlUrl: apkRun.html_url,
        status: apkRun.status === 'in_progress' ? 'in_progress' : 'queued',
        statusMessage: `GitHub Actions #${apkRun.id} ${apkRun.status} (Heal round ${job.healRound}/${job.maxHealRounds})...`,
      });
      studioBus.emit('bot:progress', {
        botId: 'github-heal',
        status: 'active',
        task: `CI ${apkRun.status} · R${job.healRound}/${job.maxHealRounds}`,
        progress: pct,
      });
      if (!(await sleepInterruptible(POLL_INTERVAL_MS, callbacks.isAborted, callbacks.isPaused))) return;
      continue;
    }

    // COMPLETED: SUCCESS
    if (apkRun.conclusion === 'success') {
      const release = await fetchLatestApkRelease(job.repoOwner, job.repoName, pat);

      // If we just healed a prior failure and this run succeeded, save the verified fix to error_memory!
      if (lastPendingHealFix) {
        await saveErrorMemory(lastPendingHealFix, secrets.studioSupabase);
        lastPendingHealFix = null;
      }

      if (release) {
        emitJob(
          {
            githubRunId: apkRun.id,
            runHtmlUrl: apkRun.html_url,
            status: 'completed',
            apkDownloadUrl: release.apkUrl,
            apkFileName: release.apkName,
            statusMessage: `Real APK published: ${release.apkName}`,
          },
          {
            apkDownloadUrl: release.apkUrl,
            apkFileName: release.apkName,
            releasesUrl: release.releaseUrl,
          }
        );
        studioBus.emit('bot:progress', {
          botId: 'github-heal',
          status: 'done',
          task: `APK Ready: ${release.apkName.slice(0, 18)}`,
          progress: 100,
        });
        callbacks.onLogMessage(
          `Android APK build succeeded! Real APK ready: ${release.apkName}. Public APK Download, Live Web Test, and PIN-Locked Owner Admin links are now live in Display A and Admin.`
        );
        return;
      }

      // Run succeeded but release asset might still be finalizing — give it 1 retry
      if (tick < 78) {
        emitJob({
          githubRunId: apkRun.id,
          runHtmlUrl: apkRun.html_url,
          status: 'in_progress',
          statusMessage: 'Workflow succeeded — verifying APK asset in /releases/latest...',
        });
        if (!(await sleepInterruptible(8000, callbacks.isAborted, callbacks.isPaused))) return;
        const retryRelease = await fetchLatestApkRelease(job.repoOwner, job.repoName, pat);
        if (retryRelease) {
          emitJob(
            {
              status: 'completed',
              apkDownloadUrl: retryRelease.apkUrl,
              apkFileName: retryRelease.apkName,
              statusMessage: `Real APK published: ${retryRelease.apkName}`,
            },
            {
              apkDownloadUrl: retryRelease.apkUrl,
              apkFileName: retryRelease.apkName,
              releasesUrl: retryRelease.releaseUrl,
            }
          );
          studioBus.emit('bot:progress', {
            botId: 'github-heal',
            status: 'done',
            task: 'APK Published',
            progress: 100,
          });
          callbacks.onLogMessage(`Real APK verified in GitHub Releases: ${retryRelease.apkName}.`);
          return;
        }
      }

      emitJob({
        status: 'completed',
        statusMessage: 'Workflow completed. Open Releases link to inspect build artifacts.',
      });
      studioBus.emit('bot:progress', {
        botId: 'github-heal',
        status: 'done',
        task: 'Workflow completed',
        progress: 100,
      });
      return;
    }

    // COMPLETED: FAILURE -> AUTONOMOUS SELF-HEALING LOOP (UP TO 3 ROUNDS)
    if (apkRun.conclusion === 'failure') {
      if (apkRun.id === lastCheckedFailedRunId) {
        // Still seeing the old failed run while the new healed commit queues
        if (!(await sleepInterruptible(POLL_INTERVAL_MS, callbacks.isAborted, callbacks.isPaused))) return;
        continue;
      }

      if (job.healRound >= job.maxHealRounds) {
        const failInfo = await fetchFailingJobLog(job.repoOwner, job.repoName, apkRun.id, pat);
        emitJob({
          githubRunId: apkRun.id,
          runHtmlUrl: apkRun.html_url,
          status: 'failed',
          lastErrorLog: failInfo.logExcerpt.slice(0, 600),
          statusMessage: `Reached max ${job.maxHealRounds} auto-heal rounds. Last error: ${failInfo.failedStep}`,
        });
        studioBus.emit('bot:progress', {
          botId: 'github-heal',
          status: 'error',
          task: 'Needs manual check',
          progress: 100,
        });
        callbacks.onLogMessage(
          `GitHub Actions build failed after ${job.maxHealRounds} auto-heal rounds at "${failInfo.failedStep}". Open the Actions link to inspect the full log.`
        );
        return;
      }

      lastCheckedFailedRunId = apkRun.id;
      const nextRound = job.healRound + 1;

      emitJob({
        githubRunId: apkRun.id,
        runHtmlUrl: apkRun.html_url,
        status: 'healing',
        healRound: nextRound,
        statusMessage: `Failure detected in #${apkRun.id} — downloading failing job log (Auto-Heal ${nextRound}/${job.maxHealRounds})...`,
      });
      studioBus.emit('bot:progress', {
        botId: 'github-heal',
        status: 'active',
        task: `Self-Heal R${nextRound}/${job.maxHealRounds}: Reading log`,
        progress: 45,
      });

      // Step 1: Download failing job log
      const failInfo = await fetchFailingJobLog(job.repoOwner, job.repoName, apkRun.id, pat);

      // Step 2: Check Studio Supabase error_memory FIRST
      const memoryMatch = await searchErrorMemory(
        failInfo.logExcerpt,
        effectiveEngine,
        secrets.studioSupabase
      );

      studioBus.emit('bot:progress', {
        botId: 'github-heal',
        status: 'active',
        task: `Self-Heal R${nextRound}: Patching via AI`,
        progress: 65,
      });

      // Step 3: Send exact error log + failing project files + error_memory hint to connected LLM
      const world = callbacks.getWorldState();
      const fileInventory = world.generatedFiles
        .slice(0, 14)
        .map((f: GeneratedFile) => `--- FILE: ${f.path} ---\n${f.content.slice(0, 3500)}`)
        .join('\n\n');

      const healSystemPrompt = `You are JARVIS GitHub Actions Self-Healer for Sarfealam Auto-Studio.
Analyze the EXACT failing GitHub Actions CI log and repair the missing or broken project/workflow file(s).
STRICT RULES:
- NEVER add "|| echo" or mask build errors. Every APK build must genuinely compile and produce a real .apk file.
- Return ONLY strict JSON (no markdown fences) with schema:
{
  "diagnosis": "1-sentence root cause",
  "summary": "1-sentence fix description",
  "patches": [
    { "path": "relative/path/to/file", "content": "complete corrected file content" }
  ]
}`;

      const healUserPrompt = `TARGET ENGINE: ${effectiveEngine}
REPOSITORY: ${job.repoFullName}
WORKFLOW FILE: .github/workflows/${targetWorkflowFile}
FAILED JOB: ${failInfo.jobName}
FAILED STEP: ${failInfo.failedStep}

${
  memoryMatch
    ? `STUDIO ERROR MEMORY HINT (previous verified fix for similar failure):
Diagnosis: ${memoryMatch.diagnosis}
Fix Summary: ${memoryMatch.fixSummary}
Patched Path: ${memoryMatch.patchedPath}
Snippet:
${memoryMatch.patchedContentSnippet.slice(0, 1200)}
`
    : 'STUDIO ERROR MEMORY: No prior matching fix found.'
}

EXACT FAILING LOG EXCERPT:
${failInfo.logExcerpt}

CURRENT PROJECT FILES:
${fileInventory || '(Minimal project files)'}`;

      const llmRes = await callActiveLLM(healSystemPrompt, healUserPrompt, secrets, {
        temperature: 0.2,
        jsonMode: true,
      });

      const parsedPatch = llmRes.ok ? parseHealJson(llmRes.text) : null;
      if (!parsedPatch) {
        emitJob({
          status: 'failed',
          lastErrorLog: failInfo.logExcerpt.slice(0, 600),
          statusMessage: `Auto-Heal R${nextRound} could not generate valid patch (${llmRes.error || 'invalid JSON'}).`,
        });
        studioBus.emit('bot:progress', {
          botId: 'github-heal',
          status: 'error',
          task: 'Auto-heal patch error',
          progress: 100,
        });
        callbacks.onLogMessage(
          `Auto-Heal round ${nextRound} failed to generate a code patch: ${llmRes.error || 'LLM response could not be parsed'}.`
        );
        return;
      }

      // Step 4: Push healed files via ONE atomic Git Trees commit
      studioBus.emit('bot:progress', {
        botId: 'github-heal',
        status: 'active',
        task: `Self-Heal R${nextRound}: Atomic commit`,
        progress: 82,
      });

      const commitRes = await pushAtomicGitTreeCommit({
        owner: job.repoOwner,
        repoName: job.repoName,
        pat,
        files: parsedPatch.patches,
        commitMessage: `fix(self-heal R${nextRound}): ${parsedPatch.summary.slice(0, 64)}`,
      });

      if (!commitRes.ok) {
        emitJob({
          status: 'failed',
          lastErrorLog: commitRes.error,
          statusMessage: `Auto-Heal commit failed: ${commitRes.error}`,
        });
        return;
      }

      callbacks.onFilesPatched(parsedPatch.patches);
      await retriggerWorkflowIfNeeded(job.repoOwner, job.repoName, targetWorkflowFile, pat);

      // Hold record to save to Studio Supabase error_memory once the re-run succeeds
      const primaryPatch = parsedPatch.patches[0];
      lastPendingHealFix = {
        id: `err_mem_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        engine: effectiveEngine,
        errorSignature: `${failInfo.failedStep} :: ${failInfo.logExcerpt.slice(0, 220)}`,
        diagnosis: parsedPatch.diagnosis,
        fixSummary: parsedPatch.summary,
        patchedPath: primaryPatch.path,
        patchedContentSnippet: primaryPatch.content.slice(0, 1800),
        createdAt: Date.now(),
      };

      emitJob({
        commitSha: commitRes.commitSha,
        status: 'queued',
        lastErrorLog: failInfo.logExcerpt.slice(0, 500),
        lastHealSummary: `R${nextRound}: ${parsedPatch.summary}`,
        statusMessage: `Auto-Heal R${nextRound}/${job.maxHealRounds} pushed (${parsedPatch.patches.map((p) => p.path).join(', ')}). Waiting for re-run...`,
      });

      callbacks.onLogMessage(
        `GitHub Heal Round ${nextRound}/${job.maxHealRounds}: ${parsedPatch.diagnosis} — Patched ${parsedPatch.patches.map((p) => p.path).join(', ')} in 1 atomic commit and re-triggered Actions.`,
        `${llmRes.provider}/${llmRes.model}`
      );

      if (!(await sleepInterruptible(POLL_INTERVAL_MS, callbacks.isAborted, callbacks.isPaused))) return;
      continue;
    }

    // Cancelled / timed_out / skipped
    emitJob({
      githubRunId: apkRun.id,
      runHtmlUrl: apkRun.html_url,
      status: 'failed',
      statusMessage: `Workflow ended with conclusion: ${apkRun.conclusion || 'unknown'}`,
    });
    return;
  }
}
