import { useState } from 'react';
import {
  Bot,
  Download,
  ExternalLink,
  FolderArchive,
  GitBranch,
  Globe,
  Loader2,
  Lock,
  Plus,
  Rocket,
  ShieldCheck,
  SlidersHorizontal,
  Trash2,
  X,
} from 'lucide-react';
import { resolveEffectiveEngine, sanitizeRepoName } from '../services/githubExporter';
import type { AppsRemoteConfig, WorldState } from '../types/studio';

interface AdminPanelProps {
  world: WorldState;
  hasGithubPat: boolean;
  hasAppsSupabase: boolean;
  onSaveRule: (rule: string) => Promise<void>;
  onDeleteRule: (id: string) => void;
  onSpawnSubBot: (name: string, role: string) => void;
  onRemoveSubBot: (id: string) => void;
  onLearnApiSkill: (url: string, skillName?: string) => Promise<string>;
  onDeleteSkill: (id: string) => void;
  onPublishGitHubApk: (repoName?: string) => Promise<string>;
  onDownloadZip: (repoName?: string) => Promise<string>;
  onUpdateAppsRemoteConfig: (
    payload: AppsRemoteConfig
  ) => Promise<{ ok: boolean; httpStatus: number; message: string }>;
  onOpenSecrets: () => void;
  onClose: () => void;
}

function isSafeHttpsUrl(url?: string): boolean {
  return Boolean(url && /^https:\/\//i.test(url));
}

export function AdminPanel({
  world,
  hasGithubPat,
  hasAppsSupabase,
  onSaveRule,
  onDeleteRule,
  onSpawnSubBot,
  onRemoveSubBot,
  onLearnApiSkill,
  onDeleteSkill,
  onPublishGitHubApk,
  onDownloadZip,
  onUpdateAppsRemoteConfig,
  onOpenSecrets,
  onClose,
}: AdminPanelProps) {
  const [ruleInput, setRuleInput] = useState('');
  const [botName, setBotName] = useState('');
  const [botRole, setBotRole] = useState('');
  const [apiUrl, setApiUrl] = useState('');
  const [apiName, setApiName] = useState('');
  const [learningApi, setLearningApi] = useState(false);
  const [apiNotice, setApiNotice] = useState<string | null>(null);
  const [savingRule, setSavingRule] = useState(false);

  // Phase 4: Atomic GitHub Export & ZIP state
  const [customRepo, setCustomRepo] = useState('');
  const [pushingGithub, setPushingGithub] = useState(false);
  const [zipping, setZipping] = useState(false);
  const [exportNotice, setExportNotice] = useState<string | null>(null);

  // Phase 4: Isolated Apps Supabase Live Remote Controls
  const [bannerText, setBannerText] = useState('Festival Offer: Flat 20% OFF live now!');
  const [discountPercent, setDiscountPercent] = useState(15);
  const [gameSpeed, setGameSpeed] = useState(1.0);
  const [difficulty, setDifficulty] = useState<'easy' | 'normal' | 'hard'>('normal');
  const [pushingRemote, setPushingRemote] = useState(false);
  const [remoteNotice, setRemoteNotice] = useState<string | null>(null);

  async function handleRuleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!ruleInput.trim() || savingRule) return;
    setSavingRule(true);
    await onSaveRule(ruleInput.trim());
    setRuleInput('');
    setSavingRule(false);
  }

  function handleSpawnSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!botName.trim()) return;
    onSpawnSubBot(botName.trim(), botRole.trim() || 'Specialist automation');
    setBotName('');
    setBotRole('');
  }

  async function handleApiSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!apiUrl.trim() || learningApi) return;
    setLearningApi(true);
    setApiNotice(null);
    try {
      const msg = await onLearnApiSkill(apiUrl.trim(), apiName.trim() || undefined);
      setApiNotice(msg);
      setApiUrl('');
      setApiName('');
    } finally {
      setLearningApi(false);
    }
  }

  async function handleAtomicPush() {
    if (pushingGithub) return;
    setPushingGithub(true);
    setExportNotice(null);
    try {
      const msg = await onPublishGitHubApk(customRepo.trim() || undefined);
      setExportNotice(msg);
    } finally {
      setPushingGithub(false);
    }
  }

  async function handleDownloadZip() {
    if (zipping) return;
    setZipping(true);
    setExportNotice(null);
    try {
      const msg = await onDownloadZip(customRepo.trim() || undefined);
      setExportNotice(msg);
    } finally {
      setZipping(false);
    }
  }

  async function handlePushRemoteConfig(e: React.FormEvent) {
    e.preventDefault();
    if (pushingRemote) return;
    setPushingRemote(true);
    setRemoteNotice(null);
    try {
      const slug =
        world.activeJob?.repoName ||
        sanitizeRepoName(customRepo.trim() || world.activePrompt || 'studio-app');
      const res = await onUpdateAppsRemoteConfig({
        appSlug: slug,
        appName: (world.activePrompt || slug).slice(0, 48),
        engine: resolveEffectiveEngine(world.selectedEngine),
        versionName: '1.0.0',
        bannerText: bannerText.trim(),
        discountPercent,
        gameSpeed,
        difficulty,
        updatedAt: Date.now(),
      });
      setRemoteNotice(res.message);
    } finally {
      setPushingRemote(false);
    }
  }

  const job = world.activeJob;
  const links = world.releaseLinks;

  return (
    <section
      aria-label="Admin Releases, Remote Config, Rules and World State Panel"
      className="rounded-2xl border border-emerald-400/30 bg-[#070C1B]/95 p-4 sm:p-5 space-y-5"
    >
      <div className="flex items-center justify-between gap-3 border-b border-white/[0.08] pb-3">
        <div className="flex items-center gap-2">
          <ShieldCheck className="h-5 w-5 text-emerald-300" />
          <div>
            <h2 className="font-display text-base font-semibold text-slate-100">
              Admin · Cloud APK Releases, Remote Config &amp; Rules
            </h2>
            <p className="text-xs text-slate-400">
              1-Commit Atomic GitHub Exporter, Self-Healing Actions Loop &amp; Isolated Dual Supabase
            </p>
          </div>
        </div>
        <button
          type="button"
          onClick={onClose}
          aria-label="Close Admin Panel"
          className="flex h-9 w-9 items-center justify-center rounded-lg border border-white/10 bg-white/[0.04] text-slate-300 hover:text-white cursor-pointer"
        >
          <X className="h-4 w-4" />
        </button>
      </div>

      {/* PHASE 4: ATOMIC 1-COMMIT GITHUB EXPORTER, SELF-HEAL MONITOR & PUBLIC RELEASE LINKS */}
      <div className="rounded-xl border border-cyan-400/25 bg-[#0A1328]/90 p-3.5 sm:p-4 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Rocket className="h-4 w-4 text-cyan-300" />
            <h3 className="font-display text-sm font-semibold text-slate-100">
              1-Commit GitHub APK Builder &amp; Public Links
            </h3>
          </div>
          <span className="font-mono text-[11px] text-slate-400">
            Engine: {resolveEffectiveEngine(world.selectedEngine)} · {world.generatedFiles.length} files
          </span>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <input
            type="text"
            value={customRepo}
            onChange={(e) => setCustomRepo(e.target.value)}
            placeholder={`Repo name (auto: ${sanitizeRepoName(world.activePrompt || 'studio-app')})`}
            className="h-10 min-w-[200px] flex-1 rounded-lg border border-white/10 bg-[#050914] px-3 font-mono text-xs text-slate-100 placeholder:text-slate-600 focus:border-cyan-400/50 focus:outline-none"
          />
          <button
            type="button"
            disabled={pushingGithub}
            onClick={handleAtomicPush}
            className="inline-flex h-10 items-center gap-1.5 rounded-lg bg-emerald-500 px-3.5 text-xs font-semibold text-slate-950 hover:bg-emerald-400 disabled:opacity-50 whitespace-nowrap cursor-pointer"
          >
            {pushingGithub ? (
              <Loader2 className="h-3.5 w-3.5 animate-spin" />
            ) : (
              <GitBranch className="h-3.5 w-3.5" />
            )}
            <span>1-Commit Push &amp; Build APK</span>
          </button>
          <button
            type="button"
            disabled={zipping}
            onClick={handleDownloadZip}
            className="inline-flex h-10 items-center gap-1.5 rounded-lg border border-cyan-400/40 bg-cyan-500/15 px-3 text-xs font-semibold text-cyan-100 hover:bg-cyan-500/25 disabled:opacity-50 whitespace-nowrap cursor-pointer"
          >
            {zipping ? (
              <Loader2 className="h-3.5 w-3.5 animate-spin" />
            ) : (
              <FolderArchive className="h-3.5 w-3.5" />
            )}
            <span>Download Local ZIP</span>
          </button>
        </div>

        {!hasGithubPat && (
          <div className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-amber-400/30 bg-amber-500/10 px-3 py-2 text-xs text-amber-200">
            <span>Add your GitHub PAT (repo + workflow scopes) in Secrets to build APKs in GitHub Actions.</span>
            <button
              type="button"
              onClick={onOpenSecrets}
              className="font-semibold text-amber-100 underline hover:text-white cursor-pointer whitespace-nowrap"
            >
              Open Secrets →
            </button>
          </div>
        )}

        {exportNotice && (
          <p className="text-xs font-mono text-cyan-200 leading-relaxed">{exportNotice}</p>
        )}

        {/* Active Self-Healing Actions Monitor */}
        {job && (
          <div className="rounded-lg border border-white/[0.08] bg-[#050914] p-3 space-y-1.5 text-xs">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2 font-mono">
                <span className="font-semibold text-slate-100">{job.repoFullName}</span>
                <span className="text-slate-600" aria-hidden="true">·</span>
                <span
                  className={
                    job.status === 'completed'
                      ? 'text-emerald-300 font-semibold'
                      : job.status === 'failed'
                      ? 'text-rose-300 font-semibold'
                      : 'text-amber-300 font-semibold'
                  }
                >
                  {job.status.toUpperCase()}
                </span>
                <span className="text-slate-600" aria-hidden="true">·</span>
                <span className="tabular-nums text-slate-400">
                  Heal {job.healRound}/{job.maxHealRounds}
                </span>
              </div>
              {job.commitSha && (
                <span className="font-mono text-[11px] text-slate-500">
                  SHA {job.commitSha.slice(0, 7)}
                </span>
              )}
            </div>
            <p className="text-slate-300">{job.statusMessage}</p>
            {job.lastHealSummary && (
              <p className="font-mono text-[11px] text-violet-300">
                Last Self-Heal: {job.lastHealSummary}
              </p>
            )}
          </div>
        )}

        {/* Verified Public APK Download, Live Web Test & PIN-Locked Owner Admin Links */}
        {links && (
          <div className="flex flex-wrap items-center gap-2 pt-1">
            {isSafeHttpsUrl(links.apkDownloadUrl) ? (
              <a
                href={links.apkDownloadUrl}
                target="_blank"
                rel="noreferrer"
                className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg bg-emerald-500 px-3 text-xs font-semibold text-slate-950 hover:bg-emerald-400 whitespace-nowrap"
              >
                <Download className="h-3.5 w-3.5" />
                <span>Public APK Download ({links.apkFileName || 'app.apk'})</span>
              </a>
            ) : isSafeHttpsUrl(links.releasesUrl) ? (
              <a
                href={links.releasesUrl}
                target="_blank"
                rel="noreferrer"
                className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg border border-emerald-400/40 bg-emerald-500/15 px-3 text-xs font-semibold text-emerald-200 hover:bg-emerald-500/25 whitespace-nowrap"
              >
                <Download className="h-3.5 w-3.5" />
                <span>GitHub Releases (APK)</span>
              </a>
            ) : null}

            {isSafeHttpsUrl(links.liveTestUrl) && (
              <a
                href={links.liveTestUrl}
                target="_blank"
                rel="noreferrer"
                className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg border border-cyan-400/40 bg-cyan-500/15 px-3 text-xs font-semibold text-cyan-100 hover:bg-cyan-500/25 whitespace-nowrap"
              >
                <ExternalLink className="h-3.5 w-3.5" />
                <span>Live Web Test</span>
              </a>
            )}

            {isSafeHttpsUrl(links.adminPanelUrl) && (
              <a
                href={links.adminPanelUrl}
                target="_blank"
                rel="noreferrer"
                className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg border border-violet-400/40 bg-violet-500/18 px-3 text-xs font-semibold text-violet-100 hover:bg-violet-500/28 whitespace-nowrap"
              >
                <Lock className="h-3.5 w-3.5" />
                <span>PIN-Locked Owner Admin Web</span>
              </a>
            )}

            {isSafeHttpsUrl(links.actionsUrl) && (
              <a
                href={links.actionsUrl}
                target="_blank"
                rel="noreferrer"
                className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg border border-white/12 bg-white/[0.04] px-3 text-xs font-medium text-slate-200 hover:border-amber-400/40 whitespace-nowrap"
              >
                <ExternalLink className="h-3.5 w-3.5" />
                <span>GitHub Actions</span>
              </a>
            )}
          </div>
        )}
      </div>

      {/* PHASE 4: STRICTLY ISOLATED APPS SUPABASE LIVE REMOTE CONTROLS */}
      <div className="border-t border-white/[0.08] pt-4">
        <div className="flex flex-wrap items-center justify-between gap-2 mb-2.5">
          <div className="flex items-center gap-2">
            <SlidersHorizontal className="h-4 w-4 text-violet-300" />
            <h3 className="font-display text-sm font-semibold text-slate-100">
              Live Exported APK Remote Config (Apps Supabase)
            </h3>
          </div>
          {!hasAppsSupabase && (
            <button
              type="button"
              onClick={onOpenSecrets}
              className="text-xs text-cyan-300 hover:text-cyan-200 underline cursor-pointer"
            >
              Configure Apps Supabase in Secrets
            </button>
          )}
        </div>

        <form onSubmit={handlePushRemoteConfig} className="grid grid-cols-1 sm:grid-cols-4 gap-2">
          <input
            type="text"
            value={bannerText}
            onChange={(e) => setBannerText(e.target.value)}
            placeholder="Live remote banner text..."
            className="h-10 sm:col-span-2 rounded-lg border border-white/10 bg-[#050914] px-3 text-xs text-slate-100 placeholder:text-slate-600 focus:border-violet-400/50 focus:outline-none"
          />
          <div className="grid grid-cols-2 gap-2">
            <input
              type="number"
              min={0}
              max={95}
              value={discountPercent}
              onChange={(e) => setDiscountPercent(Number(e.target.value) || 0)}
              title="Discount %"
              aria-label="Discount percent"
              className="h-10 rounded-lg border border-white/10 bg-[#050914] px-2.5 font-mono text-xs text-slate-100 focus:border-violet-400/50 focus:outline-none"
            />
            <input
              type="number"
              min={0.25}
              max={3}
              step={0.05}
              value={gameSpeed}
              onChange={(e) => setGameSpeed(Number(e.target.value) || 1)}
              title="Game speed multiplier"
              aria-label="Game speed multiplier"
              className="h-10 rounded-lg border border-white/10 bg-[#050914] px-2.5 font-mono text-xs text-slate-100 focus:border-violet-400/50 focus:outline-none"
            />
          </div>
          <div className="flex items-center gap-2">
            <select
              value={difficulty}
              onChange={(e) => setDifficulty(e.target.value as 'easy' | 'normal' | 'hard')}
              aria-label="Difficulty"
              className="h-10 flex-1 rounded-lg border border-white/10 bg-[#050914] px-2.5 text-xs text-slate-100 focus:border-violet-400/50 focus:outline-none"
            >
              <option value="easy">Easy</option>
              <option value="normal">Normal</option>
              <option value="hard">Hard</option>
            </select>
            <button
              type="submit"
              disabled={pushingRemote}
              className="inline-flex h-10 items-center justify-center rounded-lg border border-violet-400/45 bg-violet-500/20 px-3 text-xs font-semibold text-violet-100 hover:bg-violet-500/30 disabled:opacity-50 whitespace-nowrap cursor-pointer"
            >
              {pushingRemote ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : 'Push Live'}
            </button>
          </div>
        </form>
        {remoteNotice && (
          <p className="mt-2 text-xs font-mono text-violet-200">{remoteNotice}</p>
        )}
      </div>

      {/* Universal API Connector & Dynamic Skills */}
      <div>
        <div className="flex items-center gap-2 mb-2">
          <Globe className="h-4 w-4 text-cyan-300" />
          <h3 className="font-display text-sm font-semibold text-slate-100">
            Dynamic API Skills ({world.dynamicSkills.length})
          </h3>
        </div>
        <form onSubmit={handleApiSubmit} className="grid grid-cols-1 sm:grid-cols-4 gap-2 mb-2.5">
          <input
            type="url"
            value={apiUrl}
            onChange={(e) => setApiUrl(e.target.value)}
            placeholder="https://api.example.com/data.json"
            className="h-10 sm:col-span-2 rounded-lg border border-white/10 bg-[#050914] px-3 font-mono text-xs text-slate-100 placeholder:text-slate-600 focus:border-cyan-400/50 focus:outline-none"
          />
          <input
            type="text"
            value={apiName}
            onChange={(e) => setApiName(e.target.value)}
            placeholder="Skill name (optional)"
            className="h-10 rounded-lg border border-white/10 bg-[#050914] px-3 text-xs text-slate-100 placeholder:text-slate-600 focus:border-cyan-400/50 focus:outline-none"
          />
          <button
            type="submit"
            disabled={!apiUrl.trim() || learningApi}
            className="inline-flex h-10 items-center justify-center gap-1.5 rounded-lg border border-cyan-400/45 bg-cyan-500/18 px-3 text-xs font-semibold text-cyan-100 hover:bg-cyan-500/28 disabled:opacity-45 cursor-pointer"
          >
            {learningApi ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Plus className="h-3.5 w-3.5" />}
            <span>Fetch & Learn</span>
          </button>
        </form>

        {apiNotice && (
          <p className="mb-2.5 text-xs font-mono text-cyan-200">{apiNotice}</p>
        )}

        {world.dynamicSkills.length === 0 ? (
          <p className="text-xs text-slate-500">
            No API skills learned yet. Connect any open JSON endpoint above or ask JARVIS to fetch an API URL.
          </p>
        ) : (
          <div className="divide-y divide-white/[0.06] rounded-xl border border-white/[0.08] bg-[#0B1225]/80">
            {world.dynamicSkills.map((sk) => (
              <div key={sk.id} className="flex items-start justify-between gap-3 px-3 py-2.5 text-xs">
                <div className="min-w-0">
                  <div className="font-semibold text-slate-100">
                    {sk.name}{' '}
                    <span className="font-mono text-[11px] font-normal text-emerald-300">
                      HTTP {sk.httpStatus}
                    </span>
                  </div>
                  <div className="font-mono text-[11px] text-cyan-300/80 truncate">{sk.url}</div>
                  {sk.sampleKeys.length > 0 && (
                    <div className="mt-0.5 text-[11px] text-slate-400">
                      Keys: {sk.sampleKeys.join(', ')}
                    </div>
                  )}
                </div>
                <button
                  type="button"
                  onClick={() => onDeleteSkill(sk.id)}
                  aria-label={`Delete ${sk.name}`}
                  className="p-1.5 text-slate-400 hover:text-rose-300 cursor-pointer shrink-0"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Permanent User Rules */}
      <div className="border-t border-white/[0.08] pt-4">
        <h3 className="font-display text-sm font-semibold text-slate-100 mb-2">
          Permanent JARVIS Rules ({world.userRules.length})
        </h3>
        <form onSubmit={handleRuleSubmit} className="flex gap-2 mb-3">
          <input
            type="text"
            value={ruleInput}
            onChange={(e) => setRuleInput(e.target.value)}
            placeholder="e.g. Always target 60fps mobile WebGL with dark HUD..."
            className="h-10 flex-1 rounded-lg border border-white/10 bg-[#050914] px-3 text-xs text-slate-100 placeholder:text-slate-600 focus:border-emerald-400/50 focus:outline-none"
          />
          <button
            type="submit"
            disabled={!ruleInput.trim() || savingRule}
            className="inline-flex h-10 items-center gap-1.5 rounded-lg bg-emerald-500 px-3.5 text-xs font-semibold text-slate-950 hover:bg-emerald-400 disabled:opacity-45 cursor-pointer whitespace-nowrap"
          >
            <Plus className="h-3.5 w-3.5" />
            <span>Save Rule</span>
          </button>
        </form>

        {world.userRules.length === 0 ? (
          <p className="text-xs text-slate-500">
            No permanent rules saved yet. Add one above or tell JARVIS “Save rule: ...”.
          </p>
        ) : (
          <div className="divide-y divide-white/[0.06] rounded-xl border border-white/[0.08] bg-[#0B1225]/80">
            {world.userRules.map((r) => (
              <div key={r.id} className="flex items-center justify-between gap-3 px-3 py-2.5 text-xs">
                <div className="min-w-0">
                  <p className="text-slate-200">{r.rule}</p>
                  <p className="mt-0.5 text-[11px] text-slate-500 font-mono">
                    {r.syncedToSupabase ? 'Local + Studio Supabase' : 'Local Storage'}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => onDeleteRule(r.id)}
                  aria-label="Delete rule"
                  className="p-1.5 text-slate-400 hover:text-rose-300 cursor-pointer"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Spawn Specialist Sub-Bot */}
      <div className="border-t border-white/[0.08] pt-4">
        <div className="flex items-center gap-2 mb-2">
          <Bot className="h-4 w-4 text-violet-300" />
          <h3 className="font-display text-sm font-semibold text-slate-100">
            Dynamic Specialist Sub-Bots ({world.spawnedSubBots.length})
          </h3>
        </div>
        <form onSubmit={handleSpawnSubmit} className="grid grid-cols-1 sm:grid-cols-3 gap-2 mb-3">
          <input
            type="text"
            value={botName}
            onChange={(e) => setBotName(e.target.value)}
            placeholder="Bot name (e.g. Shader Synth)"
            className="h-10 rounded-lg border border-white/10 bg-[#050914] px-3 text-xs text-slate-100 placeholder:text-slate-600 focus:border-violet-400/50 focus:outline-none"
          />
          <input
            type="text"
            value={botRole}
            onChange={(e) => setBotRole(e.target.value)}
            placeholder="Role (e.g. PBR lighting QA)"
            className="h-10 rounded-lg border border-white/10 bg-[#050914] px-3 text-xs text-slate-100 placeholder:text-slate-600 focus:border-violet-400/50 focus:outline-none"
          />
          <button
            type="submit"
            disabled={!botName.trim()}
            className="inline-flex h-10 items-center justify-center gap-1.5 rounded-lg border border-violet-400/40 bg-violet-500/20 px-3 text-xs font-semibold text-violet-100 hover:bg-violet-500/30 disabled:opacity-45 cursor-pointer"
          >
            <Plus className="h-3.5 w-3.5" />
            <span>Spawn Bot</span>
          </button>
        </form>

        {world.spawnedSubBots.length > 0 && (
          <div className="flex flex-wrap gap-2">
            {world.spawnedSubBots.map((sb) => (
              <div
                key={sb.id}
                className="inline-flex items-center gap-2 rounded-lg border border-violet-400/25 bg-[#0B1225] px-2.5 py-1.5 text-xs"
              >
                <span className="font-medium text-slate-100">{sb.name}</span>
                <span className="text-slate-500">·</span>
                <span className="text-slate-400">{sb.role}</span>
                <button
                  type="button"
                  onClick={() => onRemoveSubBot(sb.id)}
                  aria-label={`Remove ${sb.name}`}
                  className="text-slate-400 hover:text-rose-300 cursor-pointer"
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Live World State Snapshot */}
      <div className="border-t border-white/[0.08] pt-4">
        <h3 className="font-display text-sm font-semibold text-slate-100 mb-2">
          Shared World State Snapshot
        </h3>
        <pre className="max-h-44 overflow-auto rounded-xl border border-white/[0.07] bg-[#040711] p-3 font-mono text-[11px] text-cyan-200/90">
          {JSON.stringify(
            {
              activePrompt: world.activePrompt,
              selectedEngine: world.selectedEngine,
              language: world.language,
              mode: world.mode,
              paused: world.paused,
              currentStage: world.currentStage,
              stageLabel: world.stageLabel,
              candidateAssets: world.candidateAssets.length,
              selectedAssets: world.selectedAssets.map((a) => ({ name: a.name, rawUrl: a.rawUrl })),
              dynamicSkills: world.dynamicSkills.map((s) => s.name),
              visionAnalysis: world.visionAnalysis?.summary ?? null,
              generatedMediaCount: world.generatedMedia.length,
              generatedFiles: world.generatedFiles.map((f) => f.path),
            },
            null,
            2
          )}
        </pre>
      </div>
    </section>
  );
}
