import { callActiveLLM, resolveActiveProvider } from './aiRouter';
import { studioBus } from './eventBus';
import type {
  CodeGenStageState,
  EngineType,
  GeneratedFile,
  SecretsConfig,
  StudioAssetItem,
  WorldState,
} from '../types/studio';

export interface FiveStageGenCallbacks {
  isPaused: () => boolean;
  isAborted: () => boolean;
  onStageProgress: (stage: CodeGenStageState) => void;
}

export interface FiveStageGenResult {
  ok: boolean;
  previewHtml: string;
  files: GeneratedFile[];
  architectureSummary: string;
  providerUsed: string;
  error?: string;
}

export interface HotPatchResult {
  ok: boolean;
  previewHtml: string;
  files: GeneratedFile[];
  summary: string;
  providerUsed?: string;
  error?: string;
}

interface Stage1ArchitecturePlan {
  projectKind: '3d_game' | 'commercial_app' | 'hybrid';
  title: string;
  summary: string;
  assetBindings: Array<{
    role: string;
    name: string;
    rawUrl: string;
    category: string;
    pbrMaps?: StudioAssetItem['pbrMaps'];
  }>;
  coreMechanics: string[];
  uiControls: string[];
  audioBindings: Record<string, string>;
  engineFilesPlan: string[];
}

/**
 * Runtime error & readiness bridge injected cleanly into every generated previewHtml <head>.
 * Reports any uncaught iframe error or unhandled promise rejection directly back to Vision QA!
 */
const RUNTIME_QA_BRIDGE_SCRIPT = `<script>
(function(){
  if (window.__SARFEALAM_QA_BRIDGE__) return;
  window.__SARFEALAM_QA_BRIDGE__ = true;
  function send(type, payload) {
    try { window.parent.postMessage({ type: type, payload: payload }, '*'); } catch (e) {}
  }
  window.addEventListener('error', function(ev) {
    send('SARFEALAM_PREVIEW_ERROR', {
      message: (ev && ev.message) || 'Runtime error in preview',
      source: (ev && ev.filename) || 'preview',
      line: (ev && ev.lineno) || 0
    });
  });
  window.addEventListener('unhandledrejection', function(ev) {
    var reason = ev && ev.reason;
    send('SARFEALAM_PREVIEW_ERROR', {
      message: (reason && reason.message) ? reason.message : String(reason || 'Unhandled promise rejection'),
      source: 'promise',
      line: 0
    });
  });
  window.addEventListener('load', function() {
    send('SARFEALAM_PREVIEW_READY', { title: document.title || 'Preview Ready' });
  });
})();
</script>`;

export function injectRuntimeQaBridge(html: string): string {
  const cleaned = html
    .replace(/^```(?:html)?\s*/i, '')
    .replace(/\s*```$/i, '')
    .trim();

  if (cleaned.includes('__SARFEALAM_QA_BRIDGE__')) {
    return cleaned;
  }
  if (/<head[^>]*>/i.test(cleaned)) {
    return cleaned.replace(/<head([^>]*)>/i, `<head$1>\n${RUNTIME_QA_BRIDGE_SCRIPT}`);
  }
  if (/<html[^>]*>/i.test(cleaned)) {
    return cleaned.replace(/<html([^>]*)>/i, `<html$1>\n<head>${RUNTIME_QA_BRIDGE_SCRIPT}</head>`);
  }
  return `<!doctype html><html><head><meta charset="utf-8" />${RUNTIME_QA_BRIDGE_SCRIPT}</head><body>${cleaned}</body></html>`;
}

function stripCodeFences(raw: string): string {
  return raw
    .replace(/^```(?:json|html|typescript|ts|gdscript|dart|csharp|yaml)?\s*/i, '')
    .replace(/\s*```$/i, '')
    .trim();
}

function safeParseJson<T>(raw: string): T | null {
  const cleaned = stripCodeFences(raw);
  try {
    return JSON.parse(cleaned) as T;
  } catch {
    // Try extracting outermost JSON object if LLM wrapped with brief prose
    const first = cleaned.indexOf('{');
    const last = cleaned.lastIndexOf('}');
    if (first !== -1 && last > first) {
      try {
        return JSON.parse(cleaned.slice(first, last + 1)) as T;
      } catch {
        return null;
      }
    }
    return null;
  }
}

function serializeVerifiedAssets(assets: StudioAssetItem[]): string {
  if (assets.length === 0) {
    return 'No external vault assets were pre-selected; synthesize procedural Web Audio / canvas / SVG assets cleanly without 404 URLs.';
  }
  return JSON.stringify(
    assets.map((a) => ({
      id: a.id,
      name: a.name,
      category: a.category,
      format: a.format,
      source: a.source,
      rawUrl: a.rawUrl,
      ...(a.thumbUrl ? { thumbUrl: a.thumbUrl } : {}),
      ...(a.pbrMaps ? { pbrMaps: a.pbrMaps } : {}),
    })),
    null,
    2
  );
}

function describeEngineDeliverables(engine: EngineType): string {
  switch (engine) {
    case 'Godot 4':
      return 'Generate clean Godot 4 export artifacts: "project.godot", "scripts/Main.gd" (GDScript 4 with vehicle/character/app logic & asset manifest), "export_presets.cfg", and "assets_manifest.json".';
    case 'Flutter':
      return 'Generate clean Flutter export artifacts: "pubspec.yaml", "lib/main.dart" (complete Material 3 dark-theme interactive Flutter app matching the prompt & assets), and "lib/services/apps_supabase_config.dart".';
    case 'Unity':
      return 'Generate clean modular Unity C# scripts: "Assets/Scripts/VehicleController.cs", "Assets/Scripts/DoorTrigger.cs", "Assets/Scripts/CharacterController.cs", and "Assets/Resources/StudioAssets.json".';
    case 'Capacitor 3D/App':
    case 'Auto':
    default:
      return 'Generate clean Capacitor 6 + Vite export artifacts: "capacitor.config.json" (with CapacitorHttp enabled), "package.json", "index.html", "src/main.ts", and "src/assets.manifest.json".';
  }
}

async function waitForResumeOrAbort(callbacks: FiveStageGenCallbacks, stageNum: number, title: string): Promise<boolean> {
  while (callbacks.isPaused()) {
    if (callbacks.isAborted()) return false;
    studioBus.emit('bot:progress', {
      botId: 'code-bot',
      status: 'paused',
      task: `Paused at Codegen ${stageNum}/5 · ${title}`,
      progress: Math.round(((stageNum - 1) / 5) * 100),
    });
    await new Promise((r) => setTimeout(r, 180));
  }
  return !callbacks.isAborted();
}

function emitCodeStage(
  callbacks: FiveStageGenCallbacks,
  stage: number,
  title: string,
  detail: string,
  completedStages: number[]
) {
  callbacks.onStageProgress({ stage, title, detail, completedStages });
  studioBus.emit('bot:progress', {
    botId: 'code-bot',
    status: 'active',
    task: `${stage}/5 ${title}`,
    progress: Math.min(95, stage * 19),
  });
}

/**
 * ZERO-SHORTCUT 5-STAGE LIVE CODE GENERATOR
 *
 * Strictly zero hardcoded 3-car presets, zero fake Kirana cards, zero keyword-regex classifiers.
 * Uses the user's connected LLM across 5 cooperative stages with Pause/Resume checks between every stage.
 */
export async function runFiveStageCodeGenerator(
  state: WorldState,
  secrets: SecretsConfig,
  callbacks: FiveStageGenCallbacks
): Promise<FiveStageGenResult> {
  const active = resolveActiveProvider(secrets);
  if (!active) {
    return {
      ok: false,
      previewHtml: '',
      files: [],
      architectureSummary: '',
      providerUsed: 'none',
      error:
        'Zero-Shortcut Code Generator requires an active AI provider key (Gemini, Groq, NVIDIA NIM, OpenRouter, or Cohere). Open the Secrets panel, save & test any key, then run Design / Build.',
    };
  }

  const assets = state.selectedAssets.length > 0 ? state.selectedAssets : state.candidateAssets;
  const assetsJson = serializeVerifiedAssets(assets);
  const userRulesBlock =
    state.userRules.length > 0
      ? state.userRules.map((r, i) => `${i + 1}. ${r.rule}`).join('\n')
      : 'None';
  const visionBlock = state.visionAnalysis
    ? `Camera Vision Eye Spec: ${state.visionAnalysis.summary}\nDetailed Spec: ${state.visionAnalysis.buildSpec}`
    : 'None';
  const appsSupabaseBlock = secrets.appsSupabase.url
    ? `Apps Supabase URL: ${secrets.appsSupabase.url} (table: apps_config, anonKey injected via window.APPS_SUPABASE_CONFIG)`
    : 'Apps Supabase not configured yet (provide clean optional remote config hook reading window.APPS_SUPABASE_CONFIG).';

  const completedStages: number[] = [];

  try {
    // =========================================================================
    // STAGE 1: Architecture & Asset Binding (LLM decides projectKind & bindings)
    // =========================================================================
    if (!(await waitForResumeOrAbort(callbacks, 1, 'Architecture & Asset Binding'))) {
      return { ok: false, previewHtml: '', files: [], architectureSummary: '', providerUsed: active.provider, error: 'Cancelled' };
    }
    emitCodeStage(callbacks, 1, 'Architecture & Asset Binding', 'Designing architecture & binding verified asset URLs...', completedStages);

    const stage1System = `You are Stage 1 Architect inside Sarfealam Auto-Studio.
NEVER use generic placeholder presets or fake sample stores. Tailor 100% to the user's exact prompt and bind the exact verified asset rawUrls provided.
Return ONLY valid JSON matching:
{
  "projectKind": "3d_game" | "commercial_app" | "hybrid",
  "title": "Project Title",
  "summary": "2-sentence architecture plan",
  "assetBindings": [{ "role": "hero_vehicle|character|world|pbr_ground|hdri_sky|sfx_horn|sfx_engine|hero_photo|ui_icon|custom", "name": "...", "rawUrl": "exact URL from input", "category": "..." }],
  "coreMechanics": ["..."],
  "uiControls": ["..."],
  "audioBindings": { "engine_idle": "url or synth", "horn": "url or synth", "gear_shift": "url or synth", "brake": "url or synth", "door_open": "url or synth", "footstep": "url or synth", "app_action": "url or synth" },
  "engineFilesPlan": ["list of files for target engine"]
}`;

    const stage1Prompt = `USER PROMPT: ${state.activePrompt}
TARGET ENGINE: ${state.selectedEngine}
${visionBlock}
USER PERMANENT RULES:
${userRulesBlock}
APPS SUPABASE:
${appsSupabaseBlock}
VERIFIED SELECTED ASSETS (USE THESE EXACT rawUrl VALUES):
${assetsJson}`;

    const stage1Res = await callActiveLLM(stage1System, stage1Prompt, secrets, {
      jsonMode: true,
      temperature: 0.2,
    });
    if (!stage1Res.ok) {
      throw new Error(`Stage 1 Architecture failed: ${stage1Res.error}`);
    }

    const plan: Stage1ArchitecturePlan = safeParseJson<Stage1ArchitecturePlan>(stage1Res.text) ?? {
      projectKind: 'commercial_app',
      title: state.activePrompt.slice(0, 60) || 'Sarfealam Studio Build',
      summary: stage1Res.text.slice(0, 220),
      assetBindings: assets.map((a) => ({
        role: a.category,
        name: a.name,
        rawUrl: a.rawUrl,
        category: a.category,
        pbrMaps: a.pbrMaps,
      })),
      coreMechanics: ['Interactive core runtime'],
      uiControls: ['Touch-first responsive controls'],
      audioBindings: {},
      engineFilesPlan: [],
    };
    completedStages.push(1);

    // =========================================================================
    // STAGE 2: World / UI Shell
    // =========================================================================
    if (!(await waitForResumeOrAbort(callbacks, 2, 'World / UI Shell'))) {
      return { ok: false, previewHtml: '', files: [], architectureSummary: plan.summary, providerUsed: stage1Res.provider, error: 'Cancelled' };
    }
    emitCodeStage(callbacks, 2, 'World / UI Shell', `Constructing ${plan.projectKind} viewport & layout shell...`, completedStages);

    const is3D = plan.projectKind === '3d_game' || plan.projectKind === 'hybrid';

    const stage2System = `You are Stage 2 World & UI Shell Engineer in Sarfealam Auto-Studio.
Output ONLY a clean JSON object: { "headMarkup": "<style>...</style> and importmap if 3D", "bodyMarkup": "complete HTML structure inside <body> without <script> logic" }.
${
  is3D
    ? `FOR 3D GAMES:
- Include exact ES module importmap in headMarkup:
  <script type="importmap">{"imports":{"three":"https://unpkg.com/three@0.168.0/build/three.module.js","three/addons/":"https://unpkg.com/three@0.168.0/examples/jsm/"}}</script>
- Fullscreen <canvas id="gameCanvas"> occupying 100vw x 100vh with clean HUD overlay (NEVER use backdrop-filter over WebGL canvas):
  - Top HUD: Speedometer (km/h), RPM bar, Gear indicator (R/N/1/2/3), active mode (DRIVING / ON FOOT), AI traffic & NPC counter, Camera toggle.
  - Bottom-Left: Interactive touch-drag rotating Steering Wheel SVG (#steeringWheel) + on-foot virtual joystick when character exits vehicle.
  - Bottom-Center: Compact Gearbox buttons (R, N, 1, 2, 3) + Door/Gate Open & Character Enter/Exit button (#doorExitBtn) + Horn button (#hornBtn).
  - Bottom-Right: Touch-hold Gas (#gasBtn) and Brake (#brakeBtn) pedals.`
    : `FOR COMMERCIAL APPS:
- Build a sleek dark-obsidian glassmorphic mobile-first app shell tailored strictly to "${state.activePrompt}" (inspired by modern Dream11 fantasy scorecards/contests or PhonePe instant UPI/wallet/ledger polish where relevant to the prompt, NEVER fake unrelated demo stores).
- Bind the exact Wikimedia/Gemini image URLs into <img> tags with referrerpolicy="no-referrer" and crisp inline SVG icons.
- Include working tab navigation, live interactive modals/sheets (e.g., cart/UPI QR/contest picker/ledger), and clean typography.`
}`;

    const stage2Res = await callActiveLLM(
      stage2System,
      `ARCHITECTURE PLAN:\n${JSON.stringify(plan, null, 2)}\nVERIFIED ASSETS:\n${assetsJson}`,
      secrets,
      { jsonMode: true, temperature: 0.2 }
    );
    if (!stage2Res.ok) {
      throw new Error(`Stage 2 World/UI Shell failed: ${stage2Res.error}`);
    }
    const shell = safeParseJson<{ headMarkup: string; bodyMarkup: string }>(stage2Res.text) ?? {
      headMarkup: '',
      bodyMarkup: '',
    };
    completedStages.push(2);

    // =========================================================================
    // STAGE 3: Core Physics / App Logic
    // =========================================================================
    if (!(await waitForResumeOrAbort(callbacks, 3, 'Core Physics / App Logic'))) {
      return { ok: false, previewHtml: '', files: [], architectureSummary: plan.summary, providerUsed: stage1Res.provider, error: 'Cancelled' };
    }
    emitCodeStage(callbacks, 3, 'Core Physics / App Logic', is3D ? 'Building Three.js GLB loader, physics & AI traffic...' : 'Building interactive state, math & Apps Supabase hooks...', completedStages);

    const stage3System = `You are Stage 3 Core Physics & Application Logic Engineer in Sarfealam Auto-Studio.
Output ONLY a JSON object: { "coreScript": "complete JavaScript/ES Module code (without <script> tags)" }.
${
  is3D
    ? `PRO 3D GAME RUNTIME REQUIREMENTS (NON-NEGOTIABLE):
- Use ES module imports from "three", "three/addons/loaders/GLTFLoader.js", "three/addons/loaders/DRACOLoader.js", "three/addons/loaders/RGBELoader.js", and "three/addons/environments/RoomEnvironment.js".
- Configure WebGLRenderer with outputColorSpace = THREE.SRGBColorSpace, toneMapping = THREE.ACESFilmicToneMapping, toneMappingExposure = 1.1, shadowMap.enabled = true, shadowMap.type = THREE.PCFSoftShadowMap.
- Set DRACOLoader decoder path to "https://www.gstatic.com/draco/versioned/decoders/1.5.6/" and attach to GLTFLoader.
- Load user's exact selected .glb URLs (vehicle, character, world props), PBR .jpg Diffuse/Normal/Roughness textures via TextureLoader (SRGBColorSpace for diffuse), and .hdr sky via RGBELoader + PMREMGenerator (with RoomEnvironment fallback).
- If any specific .glb URL fails to load or none was selected for a slot, build a detailed composite multi-part THREE.Group procedural fallback (chassis, cabin, 4 rotating wheels, headlights, hinged door pivot, articulated character rig) so the scene ALWAYS plays cleanly with zero crashes.
- Use THREE.AnimationMixer for any loaded gltf.animations.
- Implement smooth vehicle kinematics (steering angle with spring return, gear ratios R/N/1/2/3, acceleration, braking, friction, wheel spin, camera chase damping).
- Implement Door/Gate Open animation + Character Enter/Exit: stop vehicle -> swing door open -> spawn/show character outside vehicle -> switch camera & controls to walking around the 3D road/village -> allow re-entering vehicle!
- Implement LIVING WORLD AI: autonomous AI traffic vehicles cruising along road lanes with distance-based collision avoidance + walking village/city NPCs strolling along roadside paths.`
    : `COMMERCIAL APP LOGIC REQUIREMENTS (NON-NEGOTIABLE):
- Pure vanilla JS (no broken external imports) implementing 100% live interactive state tailored to "${state.activePrompt}".
- Real live calculations (cart totals / UPI payment modal with dynamic QR SVG / contest & team builder / wallet & ledger history — matching the user's exact request).
- Include live Apps Supabase remote config loader reading from window.APPS_SUPABASE_CONFIG (configured with: ${secrets.appsSupabase.url || 'optional'}) using fetch() gracefully without failing offline.
- Expose clean action hooks for Stage 4 audio SFX and polish.`
}`;

    const stage3Res = await callActiveLLM(
      stage3System,
      `ARCHITECTURE PLAN:\n${JSON.stringify(plan, null, 2)}\nSTAGE 2 BODY MARKUP (MATCH ALL ELEMENT IDs):\n${shell.bodyMarkup.slice(0, 6500)}\nVERIFIED ASSETS:\n${assetsJson}`,
      secrets,
      { jsonMode: true, temperature: 0.2 }
    );
    if (!stage3Res.ok) {
      throw new Error(`Stage 3 Core Logic failed: ${stage3Res.error}`);
    }
    const coreObj = safeParseJson<{ coreScript: string }>(stage3Res.text);
    const coreScript = coreObj?.coreScript || stripCodeFences(stage3Res.text);
    completedStages.push(3);

    // =========================================================================
    // STAGE 4: Controls, Audio SFX & Final Playable HTML5 Assembly
    // =========================================================================
    if (!(await waitForResumeOrAbort(callbacks, 4, 'Controls, Audio SFX & Polish'))) {
      return { ok: false, previewHtml: '', files: [], architectureSummary: plan.summary, providerUsed: stage1Res.provider, error: 'Cancelled' };
    }
    emitCodeStage(callbacks, 4, 'Controls, Audio SFX & Polish', 'Wiring touch controls, Web Audio/.wav SFX & assembling playable HTML5...', completedStages);

    const stage4System = `You are Stage 4 Polish, Touch Controls & Audio SFX Integrator in Sarfealam Auto-Studio.
Merge the Stage 2 Shell and Stage 3 Core Logic into ONE COMPLETE, SELF-CONTAINED, ZERO-ERROR playable HTML5 document (<!doctype html>...</html>).
REQUIREMENTS:
1. Ensure EVERY button, touch pointer event (pointerdown/pointermove/pointerup with touch-action: none), and keyboard shortcut (WASD/Arrows, Space brake, H horn, E door/exit, 1/2/3/N/R gears) works seamlessly on BOTH Android touchscreen and desktop mouse/keyboard.
2. Wire Web Audio API + <audio> playback of the user's exact selected .wav SFX URLs from VERIFIED ASSETS (engine_idle, horn, gear_shift, brake, door_open, footstep, or app_audio payment/action tones), with automatic Web Audio unlock on first pointer gesture and clean procedural Web Audio oscillator backup if a specific .wav isn't present or fails to decode.
3. Inject window.APPS_SUPABASE_CONFIG = ${JSON.stringify({ url: secrets.appsSupabase.url, anonKey: secrets.appsSupabase.anonKey })}; cleanly inside <head>.
4. Verify zero syntax errors, zero undefined DOM IDs, zero truncated functions.
Return ONLY the complete raw HTML document starting with <!doctype html> and ending with </html>. Do NOT wrap in JSON.`;

    const stage4Res = await callActiveLLM(
      stage4System,
      `USER PROMPT: ${state.activePrompt}
PROJECT KIND: ${plan.projectKind}
VERIFIED ASSETS:\n${assetsJson}
STAGE 2 HEAD:\n${shell.headMarkup.slice(0, 4000)}
STAGE 2 BODY:\n${shell.bodyMarkup.slice(0, 5000)}
STAGE 3 CORE SCRIPT:\n${coreScript.slice(0, 12000)}`,
      secrets,
      { jsonMode: false, temperature: 0.15 }
    );
    if (!stage4Res.ok) {
      throw new Error(`Stage 4 Polish & Assembly failed: ${stage4Res.error}`);
    }

    let finalHtml = stripCodeFences(stage4Res.text);
    // Ensure valid complete HTML document
    if (!/<html/i.test(finalHtml)) {
      const scriptTag = is3D
        ? `<script type="module">\n${coreScript}\n</script>`
        : `<script>\n${coreScript}\n</script>`;
      finalHtml = `<!doctype html><html lang="en"><head><meta charset="utf-8" /><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no" /><title>${plan.title}</title>${shell.headMarkup}</head><body>${shell.bodyMarkup}${scriptTag}</body></html>`;
    }
    finalHtml = injectRuntimeQaBridge(finalHtml);
    completedStages.push(4);

    // =========================================================================
    // STAGE 5: Final Self-Check & Multi-File Engine Packaging
    // =========================================================================
    if (!(await waitForResumeOrAbort(callbacks, 5, 'Final Self-Check & Multi-File Packaging'))) {
      return { ok: false, previewHtml: finalHtml, files: [], architectureSummary: plan.summary, providerUsed: stage1Res.provider, error: 'Cancelled' };
    }
    emitCodeStage(callbacks, 5, 'Final Self-Check & Multi-File Packaging', `Packaging ${state.selectedEngine} export files & self-checking...`, completedStages);

    const stage5System = `You are Stage 5 Engine Packager in Sarfealam Auto-Studio.
Target engine: ${state.selectedEngine}.
${describeEngineDeliverables(state.selectedEngine)}
Bind the EXACT verified asset rawUrls from VERIFIED ASSETS into the engine code and manifest.
Return ONLY valid JSON:
{
  "files": [
    { "path": "relative/path", "language": "typescript|json|gdscript|dart|csharp|yaml|html", "content": "complete production file contents" }
  ]
}`;

    const stage5Res = await callActiveLLM(
      stage5System,
      `USER PROMPT: ${state.activePrompt}
ARCHITECTURE SUMMARY: ${plan.summary}
PROJECT KIND: ${plan.projectKind}
TARGET ENGINE: ${state.selectedEngine}
VERIFIED ASSETS:\n${assetsJson}
APPS SUPABASE URL: ${secrets.appsSupabase.url || 'unconfigured'}`,
      secrets,
      { jsonMode: true, temperature: 0.15 }
    );

    const now = Date.now();
    const parsedPack = stage5Res.ok
      ? safeParseJson<{ files?: Array<{ path: string; language?: string; content: string }> }>(stage5Res.text)
      : null;

    const packagedFiles: GeneratedFile[] = Array.isArray(parsedPack?.files)
      ? parsedPack.files
          .filter((f) => typeof f?.path === 'string' && typeof f?.content === 'string')
          .map((f) => ({
            path: f.path,
            language: f.language || 'text',
            content: f.content,
            updatedAt: now,
          }))
      : [];

    // Always include playable index.html and studio.manifest.json in multi-file export
    if (!packagedFiles.some((f) => f.path === 'index.html')) {
      packagedFiles.unshift({
        path: 'index.html',
        language: 'html',
        content: finalHtml,
        updatedAt: now,
      });
    }
    if (!packagedFiles.some((f) => f.path.endsWith('manifest.json'))) {
      packagedFiles.push({
        path: 'studio.manifest.json',
        language: 'json',
        content: JSON.stringify(
          {
            title: plan.title,
            prompt: state.activePrompt,
            projectKind: plan.projectKind,
            engine: state.selectedEngine,
            provider: `${stage1Res.provider}/${stage1Res.model}`,
            capacitorHttp: true,
            selectedAssets: assets.map((a) => ({
              id: a.id,
              name: a.name,
              category: a.category,
              rawUrl: a.rawUrl,
              ...(a.pbrMaps ? { pbrMaps: a.pbrMaps } : {}),
            })),
            generatedAt: new Date(now).toISOString(),
          },
          null,
          2
        ),
        updatedAt: now,
      });
    }

    completedStages.push(5);
    callbacks.onStageProgress({
      stage: 5,
      title: 'Final Self-Check & Multi-File Packaging',
      detail: `Completed all 5 stages (${packagedFiles.length} export files packaged).`,
      completedStages,
    });
    studioBus.emit('bot:progress', {
      botId: 'code-bot',
      status: 'done',
      task: `${packagedFiles.length} files live (${stage1Res.provider})`,
      progress: 100,
    });

    return {
      ok: true,
      previewHtml: finalHtml,
      files: packagedFiles,
      architectureSummary: plan.summary,
      providerUsed: `${stage1Res.provider}/${stage1Res.model}`,
    };
  } catch (err) {
    const msg = err instanceof Error ? err.message : '5-Stage Code Generator failed.';
    studioBus.emit('bot:progress', {
      botId: 'code-bot',
      status: 'error',
      task: 'Codegen error',
      progress: 0,
    });
    return {
      ok: false,
      previewHtml: '',
      files: [],
      architectureSummary: '',
      providerUsed: active.provider,
      error: msg,
    };
  }
}

/**
 * LIVE HOT-PATCH ENGINE: patch_live_code(instruction)
 * Applies targeted voice/text tweaks (e.g., "change truck color", "make headlights brighter",
 * "add discount banner", or fixing a Vision QA runtime error) without resetting the whole project.
 */
export async function patchLiveCodeWithLLM(
  instruction: string,
  currentPreviewHtml: string,
  currentFiles: GeneratedFile[],
  state: WorldState,
  secrets: SecretsConfig
): Promise<HotPatchResult> {
  const active = resolveActiveProvider(secrets);
  if (!active) {
    return {
      ok: false,
      previewHtml: currentPreviewHtml,
      files: currentFiles,
      summary: '',
      error: 'Add an AI provider key in Secrets Vault to run live code hot-patching.',
    };
  }

  if (!currentPreviewHtml.trim()) {
    return {
      ok: false,
      previewHtml: '',
      files: currentFiles,
      summary: '',
      error: 'No live preview code exists yet to patch. Run a build first.',
    };
  }

  studioBus.emit('bot:progress', {
    botId: 'code-bot',
    status: 'active',
    task: `Hot-patching: ${instruction.slice(0, 28)}`,
    progress: 50,
  });

  const patchSystem = `You are JARVIS Live Hot-Patch Engineer inside Sarfealam Auto-Studio.
Modify the existing playable HTML5 document to apply ONLY the user's requested tweak while preserving ALL existing Three.js loaders, controls, audio SFX, verified asset URLs, and interactive state.
Return ONLY the complete updated HTML document starting with <!doctype html> and ending with </html> (no markdown fences, no commentary).`;

  const patchPrompt = `PATCH INSTRUCTION: ${instruction}
PROJECT PROMPT: ${state.activePrompt}
TARGET ENGINE: ${state.selectedEngine}
RECENT RUNTIME ERRORS (if any): ${state.runtimeErrors.slice(0, 3).map((e) => e.message).join(' | ') || 'None'}

CURRENT PLAYABLE HTML:
${currentPreviewHtml}`;

  const res = await callActiveLLM(patchSystem, patchPrompt, secrets, {
    jsonMode: false,
    temperature: 0.15,
  });

  if (!res.ok) {
    studioBus.emit('bot:progress', {
      botId: 'code-bot',
      status: 'error',
      task: 'Hot-patch failed',
      progress: 0,
    });
    return {
      ok: false,
      previewHtml: currentPreviewHtml,
      files: currentFiles,
      summary: '',
      error: res.error || 'Hot-patch request failed.',
    };
  }

  const patchedRaw = stripCodeFences(res.text);
  if (!/<html|<!doctype/i.test(patchedRaw)) {
    studioBus.emit('bot:progress', {
      botId: 'code-bot',
      status: 'error',
      task: 'Invalid HTML patch',
      progress: 0,
    });
    return {
      ok: false,
      previewHtml: currentPreviewHtml,
      files: currentFiles,
      summary: '',
      error: 'Provider returned an incomplete HTML patch; previous build kept intact.',
    };
  }

  const patchedHtml = injectRuntimeQaBridge(patchedRaw);
  const now = Date.now();
  const nextFiles = currentFiles.some((f) => f.path === 'index.html')
    ? currentFiles.map((f) =>
        f.path === 'index.html' ? { ...f, content: patchedHtml, updatedAt: now } : f
      )
    : [{ path: 'index.html', language: 'html', content: patchedHtml, updatedAt: now }, ...currentFiles];

  studioBus.emit('bot:progress', {
    botId: 'code-bot',
    status: 'done',
    task: 'Hot-patch applied live',
    progress: 100,
  });

  return {
    ok: true,
    previewHtml: patchedHtml,
    files: nextFiles,
    summary: `Applied live hot-patch ("${instruction}") via ${res.provider}/${res.model}. Rollback checkpoint saved in Vault.`,
    providerUsed: `${res.provider}/${res.model}`,
  };
}
