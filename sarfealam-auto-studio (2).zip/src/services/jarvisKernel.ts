import { routeJarvisCommand, type ToolCallRequest } from './aiRouter';
import {
  fetchAnyApiAndLearnSkill,
  findReplacementAsset,
  huntProjectAssets,
  resolvePolyHavenAsset,
} from './assetHunter';
import {
  patchLiveCodeWithLLM,
  runFiveStageCodeGenerator,
} from './codeGenerator';
import { studioBus } from './eventBus';
import {
  downloadLocalProjectZip,
  exportProjectAtomicallyToGitHub,
  mergeFilesIntoGeneratedList,
  resolveEffectiveEngine,
} from './githubExporter';
import { runSelfHealingActionsLoop } from './githubSelfHealer';
import {
  buildInteractiveCutsceneFallback,
  generateImageWithGemini,
} from './mediaGenService';
import {
  clearWorldStateStorage,
  loadCheckpoints,
  loadDynamicSkills,
  loadSecrets,
  loadWorldState,
  saveCheckpoints,
  saveDynamicSkills,
  saveSecrets,
  saveWorldState,
  syncRuleToStudioSupabase,
  syncWorldStateToStudioSupabase,
} from './storageService';
import {
  loadActiveJobFromStudioSupabase,
  loadLocalActiveJob,
  persistActiveJobToStudioSupabase,
  saveLocalActiveJob,
  upsertAppsRemoteConfig,
} from './supabaseClient';
import { analyzeFrameWithGeminiVision } from './visionService';
import { voiceEngine } from './voiceEngine';
import type {
  ActiveBuildJob,
  ActuatorExecutionRecord,
  AppsRemoteConfig,
  ChatMessage,
  DisplayViewMode,
  EngineType,
  LanguageCode,
  PanelType,
  ReleaseLinks,
  RollbackCheckpoint,
  RuntimeErrorEvent,
  SatelliteBotId,
  SatelliteBotState,
  SecretsConfig,
  StudioAssetItem,
  StudioMode,
  SubBotState,
  UserRule,
  WorldState,
} from '../types/studio';

export const PIPELINE_STAGES = [
  { stage: 1, label: 'Blueprint', bot: 'code-bot' as SatelliteBotId },
  { stage: 2, label: 'Assets', bot: 'asset-hunter' as SatelliteBotId },
  { stage: 3, label: 'Codegen', bot: 'code-bot' as SatelliteBotId },
  { stage: 4, label: 'Vision QA', bot: 'vision-qa' as SatelliteBotId },
  { stage: 5, label: 'APK Build', bot: 'github-heal' as SatelliteBotId },
] as const;

function createInitialBots(): Record<SatelliteBotId, SatelliteBotState> {
  return {
    'asset-hunter': {
      id: 'asset-hunter',
      name: 'Asset Hunter',
      role: '3D Vault & Web Media',
      status: 'idle',
      currentTask: 'Vault standby',
      progress: 0,
      telemetryBars: [18, 28, 22, 34, 24, 19, 30, 21],
      accent: 'cyan',
    },
    'code-bot': {
      id: 'code-bot',
      name: 'Code Bot',
      role: '5-Stage Live Codegen',
      status: 'idle',
      currentTask: 'Kernel ready',
      progress: 0,
      telemetryBars: [22, 32, 26, 20, 35, 29, 18, 25],
      accent: 'violet',
    },
    'vision-qa': {
      id: 'vision-qa',
      name: 'Vision QA',
      role: 'Camera Eye & Runtime QA',
      status: 'idle',
      currentTask: 'Display A clear',
      progress: 0,
      telemetryBars: [15, 24, 30, 22, 18, 27, 23, 19],
      accent: 'emerald',
    },
    'github-heal': {
      id: 'github-heal',
      name: 'GitHub Heal',
      role: 'CI Workflow & APK',
      status: 'idle',
      currentTask: 'Workflow standby',
      progress: 0,
      telemetryBars: [20, 18, 28, 25, 31, 22, 26, 17],
      accent: 'amber',
    },
  };
}

function createDefaultWorldState(): WorldState {
  return {
    activePrompt: '',
    selectedEngine: 'Auto',
    language: 'en',
    mode: 'jarvis',
    paused: false,
    currentStage: 0,
    stageLabel: 'Ready',
    stageStepIndex: 0,
    fullscreen: false,
    generatedFiles: [],
    runningBots: createInitialBots(),
    spawnedSubBots: [],
    userRules: [],
    activePanel: 'none',
    chatHistory: [
      {
        id: 'welcome_jarvis',
        role: 'jarvis',
        text: 'Namaste Sir, JARVIS is online and ready. Speak a command, fetch 3D/web assets, show me a photo via Camera Vision Eye, or launch a Zero-Shortcut 5-stage build.',
        timestamp: Date.now(),
      },
    ],
    previewHtml: null,
    capturedSnapshot: null,
    candidateAssets: [],
    assetBackupPool: [],
    selectedAssets: [],
    assetsConfirmed: false,
    dynamicSkills: loadDynamicSkills(),
    visionAnalysis: null,
    generatedMedia: [],
    activeDisplayView: 'auto',
    checkpoints: loadCheckpoints(),
    runtimeErrors: [],
    codeGenProgress: null,
    activeJob: loadLocalActiveJob(),
    releaseLinks: null,
    lastUpdated: Date.now(),
  };
}

class JarvisKernel {
  private state: WorldState;
  private secrets: SecretsConfig;
  private pipelineRunning = false;
  private pipelineAbortToken = 0;
  private githubMonitorToken = 0;
  private telemetryTimer: ReturnType<typeof setInterval> | null = null;

  constructor() {
    this.secrets = loadSecrets();
    const persisted = loadWorldState();
    const base = createDefaultWorldState();
    const localJob = loadLocalActiveJob();

    this.state = persisted
      ? {
          ...base,
          ...persisted,
          runningBots: {
            ...base.runningBots,
            ...(persisted.runningBots ?? {}),
          },
          generatedFiles: Array.isArray(persisted.generatedFiles) ? persisted.generatedFiles : [],
          spawnedSubBots: Array.isArray(persisted.spawnedSubBots) ? persisted.spawnedSubBots : [],
          userRules: Array.isArray(persisted.userRules) ? persisted.userRules : [],
          candidateAssets: Array.isArray(persisted.candidateAssets) ? persisted.candidateAssets : [],
          assetBackupPool: Array.isArray(persisted.assetBackupPool) ? persisted.assetBackupPool : [],
          selectedAssets: Array.isArray(persisted.selectedAssets) ? persisted.selectedAssets : [],
          dynamicSkills: loadDynamicSkills(),
          generatedMedia: Array.isArray(persisted.generatedMedia) ? persisted.generatedMedia : [],
          checkpoints: loadCheckpoints(),
          runtimeErrors: [],
          codeGenProgress: null,
          activeJob: persisted.activeJob ?? localJob ?? null,
          releaseLinks: persisted.releaseLinks ?? null,
          chatHistory:
            Array.isArray(persisted.chatHistory) && persisted.chatHistory.length > 0
              ? persisted.chatHistory
              : base.chatHistory,
        }
      : base;

    voiceEngine.configure({
      getContext: () => ({ state: this.state, secrets: this.secrets }),
      onUserUtterance: async (spokenText) => {
        return await this.processUserCommand(spokenText, true);
      },
      onLiveToolCall: async (name, args) => {
        const record = await this.executeActuator(name, args);
        return record.result;
      },
    });

    // Listen for live bot progress events (Asset Hunter, Code Bot, Vision QA, GitHub Heal)
    studioBus.on('bot:progress', ({ botId, status, task, progress }) => {
      this.setBotState(botId, {
        status,
        currentTask: task,
        progress,
      });
    });

    // Listen for Gemini Live output transcriptions
    studioBus.on('voice:user_speech', ({ text, source }) => {
      if (source === 'gemini-live') {
        this.appendChat({
          id: `live_out_${Date.now()}`,
          role: 'jarvis',
          text,
          timestamp: Date.now(),
          provider: 'gemini-live',
        });
      }
    });

    this.startTelemetryLoop();
    // Phase 4 Auto-Resume: hydrate active job from Studio Supabase / localStorage and resume polling
    this.hydrateAndAutoResumeActiveJob().catch(() => {});
  }

  getState(): WorldState {
    return this.state;
  }

  getSecrets(): SecretsConfig {
    return this.secrets;
  }

  updateSecrets(next: SecretsConfig): void {
    this.secrets = next;
    saveSecrets(next);
    studioBus.emit('secrets:updated', this.secrets);
  }

  private commit(partial: Partial<WorldState>, syncCloud = false): void {
    this.state = {
      ...this.state,
      ...partial,
      lastUpdated: Date.now(),
    };
    saveWorldState(this.state);
    studioBus.emit('world:updated', this.state);

    if (syncCloud && this.secrets.studioSupabase.url && this.secrets.studioSupabase.anonKey) {
      syncWorldStateToStudioSupabase(this.state, this.secrets.studioSupabase).catch(() => {});
    }
  }

  private appendChat(msg: ChatMessage): void {
    const nextHistory = [...this.state.chatHistory.slice(-79), msg];
    this.commit({ chatHistory: nextHistory });
    studioBus.emit('chat:message', msg);
  }

  private startTelemetryLoop(): void {
    if (this.telemetryTimer) clearInterval(this.telemetryTimer);
    this.telemetryTimer = setInterval(() => {
      const bots = { ...this.state.runningBots };
      let changed = false;

      (Object.keys(bots) as SatelliteBotId[]).forEach((id, idx) => {
        const bot = bots[id];
        const nextBars = bot.telemetryBars.map((val, bIdx) => {
          if (bot.status === 'active') {
            const wave = Math.sin(Date.now() / 220 + idx * 1.4 + bIdx * 0.7) * 28;
            return Math.max(18, Math.min(98, Math.round(58 + wave + (Math.random() - 0.5) * 18)));
          }
          if (bot.status === 'paused') {
            return val;
          }
          if (bot.status === 'done') {
            return Math.max(24, Math.min(48, Math.round(32 + Math.sin(Date.now() / 600 + bIdx) * 8)));
          }
          const idleWave = Math.sin(Date.now() / 900 + idx + bIdx * 0.6) * 6;
          return Math.max(10, Math.min(32, Math.round(18 + idleWave)));
        });
        bots[id] = { ...bot, telemetryBars: nextBars };
        changed = true;
      });

      const subBots: SubBotState[] = this.state.spawnedSubBots.map((sb, idx) => ({
        ...sb,
        telemetryBars:
          sb.status === 'paused'
            ? sb.telemetryBars
            : sb.telemetryBars.map((_, bIdx) => {
                const wave = Math.sin(Date.now() / 260 + idx + bIdx * 0.9) * 24;
                return Math.max(20, Math.min(92, Math.round(52 + wave)));
              }),
      }));

      if (changed) {
        this.state = {
          ...this.state,
          runningBots: bots,
          spawnedSubBots: subBots,
        };
        studioBus.emit('world:updated', this.state);
      }
    }, 280);
  }

  // =========================================================================
  // PHASE 1 + 2 + 3 ROBOT UI ACTUATORS
  // =========================================================================

  openPanel(panel: PanelType): string {
    this.commit({ activePanel: panel });
    return panel === 'none'
      ? 'Closed active panel and returned to main command center.'
      : `Opened ${panel} panel.`;
  }

  setDisplayView(view: DisplayViewMode): void {
    this.commit({ activeDisplayView: view });
  }

  toggleFullscreen(enabled?: boolean): string {
    const next = typeof enabled === 'boolean' ? enabled : !this.state.fullscreen;
    this.commit({ fullscreen: next });
    return next ? 'Display A expanded to fullscreen.' : 'Display A collapsed to standard view.';
  }

  switchLanguage(lang: LanguageCode): string {
    this.commit({ language: lang }, true);
    return lang === 'hi'
      ? 'भाषा हिंदी (hi-IN) में बदल दी गई है।'
      : 'Language switched to English (en-IN).';
  }

  switchMode(mode: StudioMode): string {
    this.commit({ mode }, true);
    return mode === 'jarvis'
      ? 'JARVIS autonomous mode engaged.'
      : 'Manual studio mode engaged.';
  }

  setEngine(engine: EngineType): string {
    this.commit({ selectedEngine: engine }, true);
    return `Build engine set to ${engine}.`;
  }

  pauseWork(): string {
    const bots = { ...this.state.runningBots };
    (Object.keys(bots) as SatelliteBotId[]).forEach((id) => {
      if (bots[id].status === 'active') {
        bots[id] = {
          ...bots[id],
          status: 'paused',
          currentTask: `Paused · ${bots[id].currentTask.replace(/^Paused · /, '')}`,
        };
      }
    });
    const subBots = this.state.spawnedSubBots.map((sb) => ({
      ...sb,
      status: sb.status === 'active' ? ('paused' as const) : sb.status,
    }));

    this.commit({ paused: true, runningBots: bots, spawnedSubBots: subBots }, true);
    voiceEngine.setPausedVisual(true);
    studioBus.emit('pipeline:stage', {
      stage: this.state.currentStage,
      label: this.state.stageLabel,
      paused: true,
    });

    return this.state.language === 'hi'
      ? `कार्य स्टेज ${this.state.currentStage} (${this.state.stageLabel}) पर पॉज़ किया गया है। वॉइस, GitHub और Supabase जुड़े हुए हैं और सभी ${this.state.generatedFiles.length} फाइलें व ${this.state.selectedAssets.length} एसेट्स सुरक्षित हैं।`
      : `Execution paused cleanly at Stage ${this.state.currentStage} (${this.state.stageLabel}). Voice, GitHub, and Supabase remain connected, and all ${this.state.generatedFiles.length} files and ${this.state.selectedAssets.length} locked assets are intact.`;
  }

  inspectWork(speakAloud = false): string {
    const fileNames = this.state.generatedFiles.map((f) => f.path);
    const keptCount = this.state.candidateAssets.filter((a) => a.status === 'kept').length;
    const errCount = this.state.runtimeErrors.length;
    const displayStatus =
      this.state.candidateAssets.length > 0 && !this.state.assetsConfirmed
        ? `Display A is showing ${this.state.candidateAssets.length} candidate assets (${keptCount} marked Keep).`
        : this.state.previewHtml
        ? `Display A is rendering a live playable preview (${errCount === 0 ? 'zero runtime errors' : `${errCount} runtime error(s) detected by Vision QA`}).`
        : 'Display A is in clean workspace standby.';
    const pauseStatus = this.state.paused ? 'currently PAUSED' : this.pipelineRunning ? 'actively RUNNING' : 'IDLE';

    const report =
      this.state.language === 'hi'
        ? `निरीक्षण रिपोर्ट: स्टूडियो ${this.state.selectedEngine} इंजन पर स्टेज ${this.state.currentStage}/5 (${this.state.stageLabel}) में है और स्थिति ${this.state.paused ? 'पॉज़' : 'सक्रिय'} है। ${this.state.selectedAssets.length} लॉक्ड एसेट्स, ${fileNames.length} फाइलें और ${this.state.checkpoints.length} रोलबैक चेकपॉइंट सुरक्षित हैं।`
        : `Inspection report, Sir: Studio is ${pauseStatus} at Stage ${this.state.currentStage} of 5 (${this.state.stageLabel}) using ${this.state.selectedEngine}. ${this.state.selectedAssets.length} confirmed assets, ${fileNames.length} generated file${fileNames.length === 1 ? '' : 's'}${fileNames.length ? ' (' + fileNames.join(', ') + ')' : ''}, and ${this.state.checkpoints.length} rollback checkpoint(s). ${displayStatus}`;

    if (speakAloud) {
      voiceEngine.speak(report).catch(() => {});
    }
    return report;
  }

  resumeWork(): string {
    const bots = { ...this.state.runningBots };
    (Object.keys(bots) as SatelliteBotId[]).forEach((id) => {
      if (bots[id].status === 'paused') {
        bots[id] = {
          ...bots[id],
          status: 'active',
          currentTask: bots[id].currentTask.replace(/^Paused · /, ''),
        };
      }
    });
    const subBots = this.state.spawnedSubBots.map((sb) => ({
      ...sb,
      status: sb.status === 'paused' ? ('active' as const) : sb.status,
    }));

    this.commit({ paused: false, runningBots: bots, spawnedSubBots: subBots }, true);
    voiceEngine.setPausedVisual(false);
    studioBus.emit('pipeline:stage', {
      stage: this.state.currentStage,
      label: this.state.stageLabel,
      paused: false,
    });

    if (!this.pipelineRunning && this.state.currentStage > 0 && this.state.currentStage < 5 && this.state.activePrompt) {
      this.runPipelineFromCursor().catch(() => {});
    }

    return this.state.language === 'hi'
      ? `स्टेज ${this.state.currentStage} (${this.state.stageLabel}) से कार्य फिर से शुरू कर दिया गया है।`
      : `Resumed execution cleanly from Stage ${this.state.currentStage} (${this.state.stageLabel}).`;
  }

  spawnSubBot(name: string, role: string): string {
    const cleanName = name.trim().slice(0, 28) || 'Specialist Bot';
    const cleanRole = role.trim().slice(0, 48) || 'Autonomous subsystem';
    const newBot: SubBotState = {
      id: `sub_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      name: cleanName,
      role: cleanRole,
      status: this.state.paused ? 'paused' : 'active',
      spawnedAt: Date.now(),
      telemetryBars: [35, 62, 48, 74, 56, 68, 42, 60],
    };
    this.commit({ spawnedSubBots: [...this.state.spawnedSubBots, newBot] }, true);
    return `Spawned specialist sub-bot "${cleanName}" for ${cleanRole}.`;
  }

  removeSubBot(id: string): void {
    this.commit(
      {
        spawnedSubBots: this.state.spawnedSubBots.filter((b) => b.id !== id),
      },
      true
    );
  }

  async saveUserRule(ruleText: string): Promise<string> {
    const clean = ruleText.trim();
    if (!clean) return 'Rule text cannot be empty.';

    const rule: UserRule = {
      id: `rule_${Date.now()}`,
      rule: clean,
      createdAt: Date.now(),
      syncedToSupabase: false,
    };

    const synced = await syncRuleToStudioSupabase(rule, this.secrets.studioSupabase);
    rule.syncedToSupabase = synced;

    this.commit({ userRules: [rule, ...this.state.userRules] }, true);
    return synced
      ? `Saved permanent rule to localStorage and Studio Supabase: "${clean}".`
      : `Saved permanent rule to localStorage: "${clean}" (add Studio Supabase keys in Secrets for cloud sync).`;
  }

  deleteUserRule(id: string): void {
    this.commit(
      {
        userRules: this.state.userRules.filter((r) => r.id !== id),
      },
      true
    );
  }

  deleteDynamicSkill(id: string): void {
    const next = this.state.dynamicSkills.filter((s) => s.id !== id);
    saveDynamicSkills(next);
    this.commit({ dynamicSkills: next });
  }

  updateGeneratedFile(path: string, content: string): void {
    const nextFiles = this.state.generatedFiles.map((f) =>
      f.path === path ? { ...f, content, updatedAt: Date.now() } : f
    );
    const previewPatch = path === 'index.html' ? { previewHtml: content } : {};
    this.commit({ generatedFiles: nextFiles, ...previewPatch });
  }

  setCapturedSnapshot(dataUrl: string | null): void {
    this.commit({ capturedSnapshot: dataUrl });
  }

  // =========================================================================
  // PHASE 3: ROLLBACK CHECKPOINTS, LIVE HOT-PATCH & RUNTIME VISION QA BRIDGE
  // =========================================================================

  saveRollbackCheckpoint(label: string): void {
    if (!this.state.previewHtml) return;
    const cp: RollbackCheckpoint = {
      id: `cp_${Date.now()}_${Math.random().toString(36).slice(2, 5)}`,
      label: label.slice(0, 72),
      engine: this.state.selectedEngine,
      prompt: this.state.activePrompt,
      previewHtml: this.state.previewHtml,
      generatedFiles: structuredClone(this.state.generatedFiles),
      createdAt: Date.now(),
    };
    const next = [cp, ...this.state.checkpoints].slice(0, 12);
    saveCheckpoints(next);
    this.commit({ checkpoints: next });
  }

  restoreCheckpoint(checkpointId: string): string {
    const cp = this.state.checkpoints.find((c) => c.id === checkpointId);
    if (!cp) return 'Checkpoint not found.';

    this.commit({
      previewHtml: cp.previewHtml,
      generatedFiles: structuredClone(cp.generatedFiles),
      selectedEngine: cp.engine,
      activePrompt: cp.prompt,
      runtimeErrors: [],
      activeDisplayView: 'preview',
      activePanel: 'none',
    });

    studioBus.emit('bot:progress', {
      botId: 'vision-qa',
      status: 'done',
      task: `Restored: ${cp.label.slice(0, 22)}`,
      progress: 100,
    });

    return `Restored Rollback Checkpoint "${cp.label}" (${cp.generatedFiles.length} files) instantly into Display A.`;
  }

  deleteCheckpoint(checkpointId: string): void {
    const next = this.state.checkpoints.filter((c) => c.id !== checkpointId);
    saveCheckpoints(next);
    this.commit({ checkpoints: next });
  }

  reportPreviewRuntimeError(payload: { message: string; source?: string; line?: number }): void {
    const errEvent: RuntimeErrorEvent = {
      id: `err_${Date.now()}_${Math.random().toString(36).slice(2, 5)}`,
      message: String(payload.message || 'Runtime preview error').slice(0, 240),
      source: payload.source,
      line: payload.line,
      timestamp: Date.now(),
    };

    // Deduplicate rapid identical errors within 2s
    const latest = this.state.runtimeErrors[0];
    if (latest && latest.message === errEvent.message && Date.now() - latest.timestamp < 2000) {
      return;
    }

    const nextErrors = [errEvent, ...this.state.runtimeErrors].slice(0, 12);
    this.commit({ runtimeErrors: nextErrors });
    studioBus.emit('bot:progress', {
      botId: 'vision-qa',
      status: 'error',
      task: `QA Err: ${errEvent.message.slice(0, 26)}`,
      progress: 100,
    });
  }

  reportPreviewReady(): void {
    if (this.state.runtimeErrors.length === 0) {
      studioBus.emit('bot:progress', {
        botId: 'vision-qa',
        status: 'done',
        task: 'Live Preview OK (0 errors)',
        progress: 100,
      });
    }
  }

  clearRuntimeErrors(): void {
    this.commit({ runtimeErrors: [] });
    studioBus.emit('bot:progress', {
      botId: 'vision-qa',
      status: 'done',
      task: 'QA clear',
      progress: 100,
    });
  }

  async patchLiveCode(instruction: string): Promise<string> {
    const clean = instruction.trim();
    if (!clean) return 'Provide a tweak instruction to hot-patch the live code.';

    if (!this.state.previewHtml) {
      return 'No live preview is loaded yet to patch, Sir. Confirm assets or run a 5-stage build first.';
    }

    // Auto-save a 1-second Rollback Checkpoint BEFORE patching!
    this.saveRollbackCheckpoint(`Before patch: ${clean}`);

    const res = await patchLiveCodeWithLLM(
      clean,
      this.state.previewHtml,
      this.state.generatedFiles,
      this.state,
      this.secrets
    );

    if (!res.ok) {
      return res.error || 'Live hot-patch failed.';
    }

    this.commit(
      {
        previewHtml: res.previewHtml,
        generatedFiles: res.files,
        runtimeErrors: [],
        activeDisplayView: 'preview',
      },
      true
    );

    return res.summary;
  }

  // =========================================================================
  // PHASE 4: ATOMIC 1-COMMIT GITHUB EXPORT, SELF-HEAL LOOP, ZIP & DUAL SUPABASE
  // =========================================================================

  private isJobActive(job: ActiveBuildJob | null): job is ActiveBuildJob {
    if (!job) return false;
    return ['pushing', 'queued', 'in_progress', 'healing'].includes(job.status);
  }

  private buildReleaseLinksFromJob(job: ActiveBuildJob): ReleaseLinks {
    const pagesUrl = `https://${job.repoOwner}.github.io/${job.repoName}/`;
    return {
      repoFullName: job.repoFullName,
      repoUrl: `https://github.com/${job.repoFullName}`,
      actionsUrl: job.runHtmlUrl || `https://github.com/${job.repoFullName}/actions`,
      pagesUrl,
      liveTestUrl: `${pagesUrl}play.html`,
      adminPanelUrl: pagesUrl,
      releasesUrl: `https://github.com/${job.repoFullName}/releases/latest`,
      apkDownloadUrl: job.apkDownloadUrl,
      apkFileName: job.apkFileName,
      updatedAt: Date.now(),
    };
  }

  private async hydrateAndAutoResumeActiveJob(): Promise<void> {
    let jobToResume: ActiveBuildJob | null = this.state.activeJob;

    // Check Studio Supabase active_jobs first if configured
    if (this.secrets.studioSupabase.url && this.secrets.studioSupabase.anonKey) {
      const cloudSnap = await loadActiveJobFromStudioSupabase(this.secrets.studioSupabase);
      if (cloudSnap && (!jobToResume || cloudSnap.job.updatedAt >= jobToResume.updatedAt)) {
        jobToResume = cloudSnap.job;
        const restoredPreview =
          this.state.previewHtml ||
          cloudSnap.generatedFiles.find((f) => f.path === 'index.html' || f.path === 'docs/play.html')?.content ||
          null;

        this.commit({
          activePrompt: this.state.activePrompt || cloudSnap.prompt,
          selectedEngine: cloudSnap.selectedEngine || this.state.selectedEngine,
          currentStage: Math.max(this.state.currentStage, cloudSnap.currentStage),
          selectedAssets:
            this.state.selectedAssets.length > 0 ? this.state.selectedAssets : cloudSnap.selectedAssets,
          generatedFiles:
            this.state.generatedFiles.length > 0 ? this.state.generatedFiles : cloudSnap.generatedFiles,
          previewHtml: restoredPreview,
          activeJob: cloudSnap.job,
          releaseLinks: this.buildReleaseLinksFromJob(cloudSnap.job),
        });
      }
    }

    if (this.isJobActive(jobToResume) && this.secrets.githubPat.trim()) {
      this.appendChat({
        id: `auto_resume_${Date.now()}`,
        role: 'jarvis',
        text: `Auto-resumed active GitHub Actions APK build for ${jobToResume.repoFullName} (Status: ${jobToResume.status}, Heal round ${jobToResume.healRound}/${jobToResume.maxHealRounds}).`,
        timestamp: Date.now(),
        provider: 'github-heal',
      });
      this.startMonitoringActiveJob(jobToResume);
    }
  }

  private startMonitoringActiveJob(job: ActiveBuildJob): void {
    this.githubMonitorToken++;
    const monitorToken = this.githubMonitorToken;

    runSelfHealingActionsLoop(job, {
      isPaused: () => this.state.paused,
      isAborted: () => monitorToken !== this.githubMonitorToken,
      getWorldState: () => this.state,
      getSecrets: () => this.secrets,
      onJobUpdated: (updatedJob, linkPatch) => {
        const baseLinks = this.state.releaseLinks || this.buildReleaseLinksFromJob(updatedJob);
        const nextLinks: ReleaseLinks = {
          ...baseLinks,
          ...(linkPatch ?? {}),
          actionsUrl: updatedJob.runHtmlUrl || baseLinks.actionsUrl,
          updatedAt: Date.now(),
        };
        this.commit({
          activeJob: updatedJob,
          releaseLinks: nextLinks,
          stageLabel:
            updatedJob.status === 'completed'
              ? 'APK Ready'
              : updatedJob.status === 'healing'
              ? `Auto-Heal ${updatedJob.healRound}/${updatedJob.maxHealRounds}`
              : updatedJob.status === 'failed'
              ? 'Build Failed'
              : 'APK Building',
        });
      },
      onFilesPatched: (patches) => {
        const merged = mergeFilesIntoGeneratedList(this.state.generatedFiles, patches);
        this.commit({ generatedFiles: merged });
      },
      onLogMessage: (message, provider) => {
        this.appendChat({
          id: `gh_heal_${Date.now()}`,
          role: 'jarvis',
          text: message,
          timestamp: Date.now(),
          provider: provider || 'github-heal',
        });
      },
    }).catch((err) => {
      console.error('[JarvisKernel] GitHub Self-Healer loop error:', err);
    });
  }

  stopGitHubMonitor(): void {
    this.githubMonitorToken++;
  }

  async publishToGitHubAndBuildApk(repoNameOverride?: string): Promise<string> {
    if (this.state.generatedFiles.length === 0 && !this.state.previewHtml) {
      return 'Generate a project first (confirm assets or run the 5-stage build) before pushing to GitHub, Sir.';
    }

    const pushRes = await exportProjectAtomicallyToGitHub(
      this.state,
      this.secrets,
      repoNameOverride
    );

    if (!pushRes.ok || !pushRes.links) {
      return pushRes.error || 'Atomic GitHub push failed.';
    }

    const activeJob: ActiveBuildJob = {
      id: `job_${Date.now()}`,
      prompt: this.state.activePrompt,
      engine: resolveEffectiveEngine(this.state.selectedEngine),
      repoOwner: pushRes.repoOwner,
      repoName: pushRes.repoName,
      repoFullName: pushRes.repoFullName,
      commitSha: pushRes.commitSha,
      status: 'queued',
      healRound: 0,
      maxHealRounds: 3,
      statusMessage: `1-commit atomic push complete (${pushRes.fileCount} files). Polling GitHub Actions every 12s...`,
      startedAt: Date.now(),
      updatedAt: Date.now(),
    };

    this.commit(
      {
        currentStage: 5,
        stageLabel: 'APK Building',
        activeJob,
        releaseLinks: pushRes.links,
      },
      true
    );

    await persistActiveJobToStudioSupabase(activeJob, this.state, this.secrets.studioSupabase);
    this.startMonitoringActiveJob(activeJob);

    return `Atomic 1-commit push succeeded to ${pushRes.repoFullName} (${pushRes.fileCount} files, SHA ${pushRes.commitSha?.slice(0, 7)}). ${pushRes.pagesNote || ''} GitHub Heal is now polling Actions every 12s with up to 3 autonomous self-heal rounds.`;
  }

  async downloadLocalZip(repoNameOverride?: string): Promise<string> {
    const res = await downloadLocalProjectZip(this.state, this.secrets, repoNameOverride);
    if (!res.ok) {
      return `Local ZIP download failed: ${res.error}`;
    }
    return `Downloaded ${res.fileName} (${res.fileCount} files including real APK workflow and Owner Admin docs).`;
  }

  async updateAppsRemoteConfig(
    payload: AppsRemoteConfig
  ): Promise<{ ok: boolean; httpStatus: number; message: string }> {
    return upsertAppsRemoteConfig(payload, this.secrets.appsSupabase);
  }

  // =========================================================================
  // PHASE 2: ASSET HUNTER, ✓ KEEP / ✕ REJECT PICKER, VISION EYE, IMAGE GEN
  // =========================================================================

  async fetchProjectAssets(
    prompt: string,
    mode: 'game_3d' | 'commercial_app' | 'auto' = 'auto'
  ): Promise<string> {
    const cleanPrompt = prompt.trim() || this.state.activePrompt || '3D action vehicle game';
    this.commit({
      activePrompt: cleanPrompt,
      currentStage: Math.max(this.state.currentStage, 2),
      stageLabel: 'Assets',
      assetsConfirmed: false,
      activeDisplayView: 'assets',
    });

    const result = await huntProjectAssets(
      cleanPrompt,
      mode,
      this.secrets.assetVaultRepo,
      () => this.state.paused
    );

    this.commit(
      {
        candidateAssets: result.candidates,
        assetBackupPool: result.backupPool,
        assetsConfirmed: false,
        activeDisplayView: 'assets',
      },
      true
    );

    return this.state.language === 'hi'
      ? `Display A में ${result.candidates.length} एसेट्स लोड हो गए हैं। आप ✓ Keep या ✕ Reject चुनें, फिर Confirm दबाएँ।`
      : `Loaded ${result.candidates.length} candidate assets into Display A (${result.catalogCount} vault items indexed, ${result.wikimediaCount} Wikimedia photos, ${result.iconifyCount} Iconify icons). Tap Keep or Reject, or tell me which ones to keep.`;
  }

  toggleKeepAsset(assetId: string): void {
    const next = this.state.candidateAssets.map((item) =>
      item.id === assetId
        ? { ...item, status: item.status === 'kept' ? ('candidate' as const) : ('kept' as const) }
        : item
    );
    this.commit({ candidateAssets: next, assetsConfirmed: false });
  }

  async rejectAndReplaceAsset(assetId: string, queryHint = ''): Promise<string> {
    const idx = this.state.candidateAssets.findIndex((a) => a.id === assetId);
    if (idx === -1) return 'Asset card not found.';
    const rejected = this.state.candidateAssets[idx];

    const excluded = new Set<string>([
      ...this.state.candidateAssets.map((a) => a.id),
      rejected.id,
    ]);

    const { replacement, remainingBackup } = await findReplacementAsset(
      rejected,
      queryHint,
      this.state.assetBackupPool,
      this.secrets.assetVaultRepo,
      excluded
    );

    const nextCandidates = [...this.state.candidateAssets];
    if (replacement) {
      nextCandidates[idx] = replacement;
      this.commit({
        candidateAssets: nextCandidates,
        assetBackupPool: remainingBackup,
        assetsConfirmed: false,
      });
      return `Replaced "${rejected.name}" with "${replacement.name}" from ${replacement.source}.`;
    } else {
      nextCandidates.splice(idx, 1);
      this.commit({
        candidateAssets: nextCandidates,
        assetBackupPool: remainingBackup,
        assetsConfirmed: false,
      });
      return `Removed "${rejected.name}" (no further alternatives in pool).`;
    }
  }

  addVaultAssetToPicker(item: StudioAssetItem): void {
    const exists = this.state.candidateAssets.some((a) => a.id === item.id);
    const nextCandidates = exists
      ? this.state.candidateAssets.map((a) => (a.id === item.id ? { ...a, status: 'kept' as const } : a))
      : [{ ...item, status: 'kept' as const }, ...this.state.candidateAssets];

    this.commit({
      candidateAssets: nextCandidates,
      assetsConfirmed: false,
      activeDisplayView: 'assets',
      activePanel: 'none',
    });
  }

  async selectAssetsByCommand(args: {
    keep_indices?: string;
    reject_indices?: string;
    replace_query?: string;
    confirm?: boolean;
  }): Promise<string> {
    const notes: string[] = [];

    if (args.replace_query && args.replace_query.trim()) {
      const query = args.replace_query.trim();
      const target =
        this.state.candidateAssets.find((a) =>
          `${a.name} ${a.category} ${a.tags.join(' ')}`.toLowerCase().includes(query.toLowerCase().split(' ')[0])
        ) || this.state.candidateAssets[0];

      if (target) {
        const res = await this.rejectAndReplaceAsset(target.id, query);
        notes.push(res);
      } else {
        const res = await this.fetchProjectAssets(query, 'auto');
        notes.push(res);
      }
    }

    if (args.keep_indices) {
      const indices = args.keep_indices
        .split(/[,\s]+/)
        .map((n) => parseInt(n, 10))
        .filter((n) => !Number.isNaN(n) && n >= 1 && n <= this.state.candidateAssets.length);

      if (indices.length > 0) {
        const next = this.state.candidateAssets.map((item, idx) =>
          indices.includes(idx + 1) ? { ...item, status: 'kept' as const } : item
        );
        this.commit({ candidateAssets: next, activeDisplayView: 'assets' });
        notes.push(`Kept asset #${indices.join(', #')}.`);
      }
    }

    if (args.reject_indices) {
      const indices = args.reject_indices
        .split(/[,\s]+/)
        .map((n) => parseInt(n, 10))
        .filter((n) => !Number.isNaN(n) && n >= 1 && n <= this.state.candidateAssets.length);

      const idsToReject = indices.map((i) => this.state.candidateAssets[i - 1]?.id).filter(Boolean) as string[];
      for (const id of idsToReject) {
        const msg = await this.rejectAndReplaceAsset(id);
        notes.push(msg);
      }
    }

    if (args.confirm) {
      const msg = await this.confirmSelectedAssetsAndDesign();
      notes.push(msg);
    }

    return notes.join(' ') || 'No matching asset selection changes found in Display A.';
  }

  async confirmSelectedAssetsAndDesign(): Promise<string> {
    const kept = this.state.candidateAssets.filter((a) => a.status === 'kept');
    const chosen = kept.length > 0 ? kept : this.state.candidateAssets;

    const verified: StudioAssetItem[] = [];
    for (const item of chosen) {
      const resolved = item.apiFilesUrl ? await resolvePolyHavenAsset(item) : item;
      verified.push({ ...resolved, status: 'kept' });
    }

    this.commit(
      {
        selectedAssets: verified,
        candidateAssets: this.state.candidateAssets.map((a) =>
          verified.some((v) => v.id === a.id) ? { ...a, status: 'kept' as const } : a
        ),
        assetsConfirmed: true,
        currentStage: 3,
        stageLabel: 'Codegen',
        activeDisplayView: 'preview',
      },
      true
    );

    this.pipelineAbortToken++;
    this.runPipelineFromCursor(3).catch((err) => {
      console.error('[JarvisKernel] Design stage error:', err);
    });

    return this.state.language === 'hi'
      ? `${verified.length} वेरिफाइड एसेट्स लॉक हो गए हैं। अब ज़ीरो-शॉर्टकट 5-स्टेज कोड जनरेशन शुरू हो रहा है।`
      : `Locked ${verified.length} verified assets into World State and launched the Zero-Shortcut 5-Stage Code Generator, Sir.`;
  }

  async analyzeCameraFrame(imageDataUrl: string, userHint?: string): Promise<{
    ok: boolean;
    summary: string;
    buildSpec?: string;
    error?: string;
  }> {
    this.commit({ capturedSnapshot: imageDataUrl });
    const res = await analyzeFrameWithGeminiVision(
      imageDataUrl,
      this.secrets,
      this.state.language,
      userHint
    );

    if (!res.ok || !res.record) {
      const errMsg = res.error || 'Vision analysis failed.';
      this.appendChat({
        id: `vision_err_${Date.now()}`,
        role: 'jarvis',
        text: errMsg,
        timestamp: Date.now(),
        provider: 'gemini-vision',
      });
      return { ok: false, summary: errMsg, error: errMsg };
    }

    this.commit({ visionAnalysis: res.record }, true);
    this.appendChat({
      id: `vision_ok_${Date.now()}`,
      role: 'jarvis',
      text: `${res.record.summary}\nSpec attached to World State — say "Build this" or tap Build Matching App/3D.`,
      timestamp: Date.now(),
      provider: `gemini/${res.record.model}`,
    });

    voiceEngine.speak(res.record.summary).catch(() => {});

    return {
      ok: true,
      summary: res.record.summary,
      buildSpec: res.record.buildSpec,
    };
  }

  async generateStudioImage(prompt: string): Promise<string> {
    const cleanPrompt = prompt.trim() || this.state.activePrompt || 'Futuristic dark obsidian studio banner';
    const res = await generateImageWithGemini(cleanPrompt, this.secrets.apiKeys.gemini);

    if (!res.ok || !res.media) {
      return res.error || 'Gemini Image Generation failed.';
    }

    const mediaAsset: StudioAssetItem = {
      id: res.media.id,
      name: cleanPrompt.slice(0, 38),
      category: 'generated_image',
      source: res.media.modelUsed,
      rawUrl: res.media.dataUrl || '',
      thumbUrl: res.media.dataUrl || '',
      format: 'image',
      tags: ['generated', 'gemini', ...cleanPrompt.toLowerCase().split(/\s+/).slice(0, 4)],
      status: 'kept',
    };

    this.commit(
      {
        generatedMedia: [res.media, ...this.state.generatedMedia].slice(0, 12),
        selectedAssets: [mediaAsset, ...this.state.selectedAssets],
        candidateAssets: [mediaAsset, ...this.state.candidateAssets],
        activeDisplayView: 'media',
      },
      true
    );

    return `Generated custom image using ${res.media.modelUsed} and previewed it in Display A. It is also bound for your next build.`;
  }

  generateVideoOrCutscene(prompt: string): string {
    const cleanPrompt = prompt.trim() || this.state.activePrompt || 'Cinematic 3D studio flythrough';
    const cutscene = buildInteractiveCutsceneFallback(cleanPrompt, this.state.selectedEngine);

    this.commit(
      {
        generatedMedia: [cutscene, ...this.state.generatedMedia].slice(0, 12),
        activeDisplayView: 'media',
      },
      true
    );

    return `Direct cloud video generation is unavailable on this API key, Sir. To keep your workflow unblocked, I built an interactive real-time HTML5 3D animated cut-scene for "${cleanPrompt}" inside Display A.`;
  }

  async fetchAnyApi(url: string, skillName?: string, description?: string): Promise<string> {
    const res = await fetchAnyApiAndLearnSkill(url, {
      skillName,
      description,
      studioSupabase: this.secrets.studioSupabase,
    });
    if (res.ok && res.skill) {
      this.commit({ dynamicSkills: loadDynamicSkills() }, true);
    }
    return res.message;
  }

  resetWorkspace(): string {
    this.pipelineAbortToken++;
    this.githubMonitorToken++;
    this.pipelineRunning = false;
    clearWorldStateStorage();
    saveLocalActiveJob(null);
    const fresh = createDefaultWorldState();
    fresh.language = this.state.language;
    fresh.selectedEngine = this.state.selectedEngine;
    fresh.userRules = this.state.userRules;
    fresh.dynamicSkills = loadDynamicSkills();
    fresh.checkpoints = loadCheckpoints();
    fresh.activeJob = null;
    fresh.releaseLinks = null;
    this.state = fresh;
    saveWorldState(this.state);
    voiceEngine.setPausedVisual(false);
    studioBus.emit('world:updated', this.state);
    return 'Workspace reset cleanly. Rollback Checkpoints, Dynamic Skills, Rules, and Secrets Vault remain preserved.';
  }

  async executeActuator(toolName: string, args: Record<string, unknown>): Promise<ActuatorExecutionRecord> {
    let result = '';

    switch (toolName) {
      case 'open_panel': {
        const panel = (args.panel as PanelType) || 'none';
        result = this.openPanel(panel);
        break;
      }
      case 'toggle_fullscreen': {
        result = this.toggleFullscreen(Boolean(args.enabled));
        break;
      }
      case 'switch_language': {
        const lang: LanguageCode = args.lang === 'hi' ? 'hi' : 'en';
        result = this.switchLanguage(lang);
        break;
      }
      case 'switch_mode': {
        const mode: StudioMode = args.mode === 'manual' ? 'manual' : 'jarvis';
        result = this.switchMode(mode);
        break;
      }
      case 'set_engine': {
        const validEngines: EngineType[] = ['Auto', 'Capacitor 3D/App', 'Godot 4', 'Flutter', 'Unity'];
        const requested = String(args.engine || 'Auto') as EngineType;
        result = this.setEngine(validEngines.includes(requested) ? requested : 'Auto');
        break;
      }
      case 'pause_work': {
        result = this.pauseWork();
        break;
      }
      case 'inspect_work': {
        result = this.inspectWork(false);
        break;
      }
      case 'resume_work': {
        result = this.resumeWork();
        break;
      }
      case 'spawn_sub_bot': {
        result = this.spawnSubBot(String(args.name || 'Specialist'), String(args.role || 'Support'));
        break;
      }
      case 'save_user_rule': {
        result = await this.saveUserRule(String(args.rule || ''));
        break;
      }
      case 'start_build_pipeline': {
        const prompt = String(
          args.prompt ||
            this.state.visionAnalysis?.buildSpec ||
            this.state.activePrompt ||
            'Autonomous 3D Capacitor Studio App'
        );
        result = await this.startBuildPipeline(prompt);
        break;
      }
      case 'fetch_project_assets': {
        const prompt = String(args.prompt || this.state.activePrompt || '3D vehicle game');
        const mode = (args.mode as 'game_3d' | 'commercial_app' | 'auto') || 'auto';
        result = await this.fetchProjectAssets(prompt, mode);
        break;
      }
      case 'select_assets': {
        result = await this.selectAssetsByCommand({
          keep_indices: typeof args.keep_indices === 'string' ? args.keep_indices : undefined,
          reject_indices: typeof args.reject_indices === 'string' ? args.reject_indices : undefined,
          replace_query: typeof args.replace_query === 'string' ? args.replace_query : undefined,
          confirm: Boolean(args.confirm),
        });
        break;
      }
      case 'generate_image': {
        result = await this.generateStudioImage(String(args.prompt || 'Studio banner artwork'));
        break;
      }
      case 'generate_video_cutscene': {
        result = this.generateVideoOrCutscene(String(args.prompt || 'Interactive 3D intro cutscene'));
        break;
      }
      case 'fetch_any_api': {
        result = await this.fetchAnyApi(
          String(args.url || ''),
          typeof args.skill_name === 'string' ? args.skill_name : undefined,
          typeof args.description === 'string' ? args.description : undefined
        );
        break;
      }
      case 'patch_live_code': {
        result = await this.patchLiveCode(String(args.instruction || ''));
        break;
      }
      case 'publish_github_apk': {
        result = await this.publishToGitHubAndBuildApk(
          typeof args.repo_name === 'string' ? args.repo_name : undefined
        );
        break;
      }
      case 'download_local_zip': {
        result = await this.downloadLocalZip();
        break;
      }
      default:
        result = `Unknown actuator "${toolName}".`;
    }

    const record: ActuatorExecutionRecord = {
      tool: toolName,
      args,
      result,
      timestamp: Date.now(),
    };
    studioBus.emit('actuator:executed', record);
    return record;
  }

  // =========================================================================
  // COMMAND ENTRY POINT (Voice + Text Input)
  // =========================================================================

  async processUserCommand(rawText: string, fromVoice = false): Promise<string> {
    const text = rawText.trim();
    if (!text) return '';

    if (!fromVoice && !voiceEngine.getSnapshot().greeted && voiceEngine.getSnapshot().liveEnabled) {
      await voiceEngine.greetIfNeeded();
    }

    this.appendChat({
      id: `user_${Date.now()}`,
      role: 'user',
      text,
      timestamp: Date.now(),
    });

    const response = await routeJarvisCommand(text, this.state, this.secrets);
    const executedActuators: ActuatorExecutionRecord[] = [];

    for (const tc of response.toolCalls as ToolCallRequest[]) {
      const record = await this.executeActuator(tc.name, tc.args);
      executedActuators.push(record);
    }

    const replyText =
      response.text ||
      executedActuators.map((a) => a.result).join(' ') ||
      (this.state.language === 'hi' ? 'कमांड पूरा हो गया, सर।' : 'Command executed, Sir.');

    this.appendChat({
      id: `jarvis_${Date.now()}`,
      role: 'jarvis',
      text: replyText,
      timestamp: Date.now(),
      provider: `${response.provider}/${response.model}`,
      actuators: executedActuators.length > 0 ? executedActuators : undefined,
    });

    if (!fromVoice && executedActuators.some((a) => a.tool === 'inspect_work')) {
      voiceEngine.speak(replyText).catch(() => {});
    }

    return replyText;
  }

  // =========================================================================
  // 5-STAGE NON-BLOCKING BUILD PIPELINE (ASSET PICKER GATE -> 5-STAGE LLM CODEGEN)
  // =========================================================================

  async startBuildPipeline(promptOverride?: string): Promise<string> {
    const prompt =
      promptOverride?.trim() ||
      this.state.activePrompt.trim() ||
      this.state.visionAnalysis?.buildSpec ||
      `Interactive ${this.state.selectedEngine} Showcase`;

    if (this.state.paused && this.state.currentStage > 0 && this.state.currentStage < 5) {
      return this.resumeWork();
    }

    // If assets are awaiting confirmation, confirm and run 5-Stage Codegen immediately
    if (
      !promptOverride &&
      this.state.candidateAssets.length > 0 &&
      !this.state.assetsConfirmed &&
      this.state.currentStage === 2
    ) {
      return this.confirmSelectedAssetsAndDesign();
    }

    this.pipelineAbortToken++;
    this.commit(
      {
        activePrompt: prompt,
        paused: false,
        currentStage: 1,
        stageLabel: PIPELINE_STAGES[0].label,
        stageStepIndex: 0,
        assetsConfirmed: false,
        codeGenProgress: null,
        runtimeErrors: [],
        runningBots: createInitialBots(),
      },
      true
    );

    this.runPipelineFromCursor(1).catch((err) => {
      console.error('[JarvisKernel] Pipeline error:', err);
    });

    return this.state.language === 'hi'
      ? `"${prompt}" के लिए पाइपलाइन शुरू हो गई है। पहले एसेट हंटर Display A में एसेट्स लाएगा।`
      : `Started studio pipeline for "${prompt}". Hunting matching 3D, audio, and web assets into Display A for your Keep/Reject review.`;
  }

  private async waitWhilePaused(token: number, ms: number): Promise<boolean> {
    const slice = 120;
    let elapsed = 0;
    while (elapsed < ms) {
      if (token !== this.pipelineAbortToken) return false;
      if (this.state.paused) {
        await new Promise((r) => setTimeout(r, 150));
        continue;
      }
      await new Promise((r) => setTimeout(r, slice));
      elapsed += slice;
    }
    return token === this.pipelineAbortToken;
  }

  private setBotState(id: SatelliteBotId, patch: Partial<SatelliteBotState>): void {
    const bots = {
      ...this.state.runningBots,
      [id]: {
        ...this.state.runningBots[id],
        ...patch,
      },
    };
    this.commit({ runningBots: bots });
  }

  private async runPipelineFromCursor(forcedStartStage?: number): Promise<void> {
    if (this.pipelineRunning) return;
    this.pipelineRunning = true;
    const token = this.pipelineAbortToken;

    try {
      const startStage = Math.max(1, forcedStartStage ?? (this.state.currentStage || 1));

      // STAGE 1: Blueprint
      if (startStage <= 1) {
        this.commit({ currentStage: 1, stageLabel: 'Blueprint' });
        this.setBotState('code-bot', {
          status: 'active',
          currentTask: `Preparing ${this.state.selectedEngine} spec`,
          progress: 35,
        });
        if (!(await this.waitWhilePaused(token, 600))) return;
        this.setBotState('code-bot', { progress: 100, status: 'done', currentTask: 'Blueprint ready' });
      }

      // STAGE 2: Asset Hunter -> Interactive ✓ Keep / ✕ Reject Asset Picker in Display A
      if (startStage <= 2 && !this.state.assetsConfirmed) {
        this.commit({ currentStage: 2, stageLabel: 'Assets', activeDisplayView: 'assets' });
        const hunt = await huntProjectAssets(
          this.state.activePrompt,
          'auto',
          this.secrets.assetVaultRepo,
          () => this.state.paused
        );
        if (token !== this.pipelineAbortToken) return;

        this.commit(
          {
            candidateAssets: hunt.candidates,
            assetBackupPool: hunt.backupPool,
            activeDisplayView: 'assets',
            stageLabel: 'Review Assets',
          },
          true
        );

        this.appendChat({
          id: `assets_ready_${Date.now()}`,
          role: 'jarvis',
          text:
            this.state.language === 'hi'
              ? `Display A में ${hunt.candidates.length} एसेट्स तैयार हैं। ✓ Keep या ✕ Reject चुनें और फिर "Confirm Selected Assets → Design" दबाएँ।`
              : `Asset Hunter loaded ${hunt.candidates.length} candidates in Display A. Tap ✓ Keep or ✕ Reject (or speak your choices), then tap "Confirm Selected Assets → Design".`,
          timestamp: Date.now(),
        });
        return;
      }

      // STAGE 3: ZERO-SHORTCUT 5-STAGE LIVE CODE GENERATOR
      if (startStage <= 3) {
        this.commit({
          currentStage: 3,
          stageLabel: 'Codegen',
          activeDisplayView: 'preview',
          runtimeErrors: [],
        });

        const genResult = await runFiveStageCodeGenerator(this.state, this.secrets, {
          isPaused: () => this.state.paused,
          isAborted: () => token !== this.pipelineAbortToken,
          onStageProgress: (stageProgress) => {
            this.commit({
              codeGenProgress: stageProgress,
              stageLabel: `Codegen ${stageProgress.stage}/5`,
            });
          },
        });

        if (token !== this.pipelineAbortToken) return;

        if (!genResult.ok) {
          this.commit({
            codeGenProgress: null,
            stageLabel: 'Key Required',
          });
          this.appendChat({
            id: `codegen_err_${Date.now()}`,
            role: 'jarvis',
            text: genResult.error || 'Code generation could not complete.',
            timestamp: Date.now(),
            provider: genResult.providerUsed,
          });
          return;
        }

        // Save Rollback Checkpoint for the freshly built version
        this.commit(
          {
            generatedFiles: genResult.files,
            previewHtml: genResult.previewHtml,
            activeDisplayView: 'preview',
            runtimeErrors: [],
          },
          true
        );
        this.saveRollbackCheckpoint(
          `Build (${this.state.selectedEngine}): ${this.state.activePrompt.slice(0, 36)}`
        );
      }

      // STAGE 4: Live Vision QA Verification
      if (startStage <= 4) {
        this.commit({ currentStage: 4, stageLabel: 'Vision QA' });
        this.setBotState('vision-qa', {
          status: 'active',
          currentTask: 'Auditing Display A runtime',
          progress: 65,
        });
        if (!(await this.waitWhilePaused(token, 700))) return;
        this.setBotState('vision-qa', {
          status: this.state.runtimeErrors.length > 0 ? 'error' : 'done',
          progress: 100,
          currentTask:
            this.state.runtimeErrors.length > 0
              ? `${this.state.runtimeErrors.length} runtime error(s)`
              : 'Live Preview QA clear',
        });
      }

      // STAGE 5: Atomic 1-Commit GitHub Push + Self-Healing Actions APK Build
      if (startStage <= 5) {
        this.commit({ currentStage: 5, stageLabel: 'APK Build' });
        if (this.secrets.githubPat.trim() && this.secrets.githubUsername.trim()) {
          if (!(await this.waitWhilePaused(token, 400))) return;
          const pushSummary = await this.publishToGitHubAndBuildApk();
          this.commit({ currentStage: 5, codeGenProgress: null }, true);
          this.appendChat({
            id: `build_gh_done_${Date.now()}`,
            role: 'jarvis',
            text: pushSummary,
            timestamp: Date.now(),
            provider: 'github-heal',
          });
          return;
        }

        this.setBotState('github-heal', {
          status: 'done',
          progress: 100,
          currentTask: `${this.state.generatedFiles.length} files (ZIP ready)`,
        });
      }

      this.commit({ currentStage: 5, stageLabel: 'Build Ready', codeGenProgress: null }, true);
      this.appendChat({
        id: `build_done_${Date.now()}`,
        role: 'jarvis',
        text:
          this.state.language === 'hi'
            ? `5-स्टेज लाइव कोड जनरेशन पूरा हो गया है, सर। Display A में लाइव प्रीव्यू चल रहा है — लोकल ZIP डाउनलोड करें या क्लाउड APK के लिए Secrets में GitHub PAT जोड़ें।`
            : `5-stage live build complete, Sir! Display A is running your playable preview with ${this.state.generatedFiles.length} ${this.state.selectedEngine} files packaged. Tap Download Local ZIP or add a GitHub PAT in Secrets to trigger the 1-commit cloud APK build.`,
        timestamp: Date.now(),
      });
    } finally {
      this.pipelineRunning = false;
    }
  }
}

export const jarvisKernel = new JarvisKernel();
