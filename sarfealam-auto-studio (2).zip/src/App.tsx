import { useEffect, useState } from 'react';
import { AdminPanel } from './components/AdminPanel';
import { BottomActionBar } from './components/BottomActionBar';
import { CameraPanel } from './components/CameraPanel';
import { CodePanel } from './components/CodePanel';
import { CommandCenter } from './components/CommandCenter';
import { ControlStripAndChat } from './components/ControlStripAndChat';
import { DisplayViewport } from './components/DisplayViewport';
import { SecretsPanel } from './components/SecretsPanel';
import { TopBar } from './components/TopBar';
import { VaultPanel } from './components/VaultPanel';
import { studioBus } from './services/eventBus';
import { jarvisKernel } from './services/jarvisKernel';
import { voiceEngine } from './services/voiceEngine';
import type {
  EngineType,
  LanguageCode,
  PanelType,
  SatelliteBotId,
  SecretsConfig,
  StudioMode,
  VoiceStatusSnapshot,
  WorldState,
} from './types/studio';

const QUICK_SPECIALISTS: Array<{ name: string; role: string }> = [
  { name: 'Shader Synth', role: 'PBR & lighting pipeline' },
  { name: 'Physics Rig', role: 'Collision & rigidbody pass' },
  { name: 'Audio Mixer', role: 'Spatial SFX & voice cues' },
  { name: 'APK Signer', role: 'Gradle & manifest check' },
];

export default function App() {
  const [world, setWorld] = useState<WorldState>(() => jarvisKernel.getState());
  const [secrets, setSecrets] = useState<SecretsConfig>(() => jarvisKernel.getSecrets());
  const [voice, setVoice] = useState<VoiceStatusSnapshot>(() => voiceEngine.getSnapshot());
  const [isProcessing, setIsProcessing] = useState(false);
  const [isHuntingAssets, setIsHuntingAssets] = useState(false);
  const [confirmReset, setConfirmReset] = useState(false);
  const [specialistCursor, setSpecialistCursor] = useState(0);
  const [vaultInitialTab, setVaultInitialTab] = useState<'catalog' | 'tree' | 'checkpoints'>('catalog');

  useEffect(() => {
    const unsubWorld = studioBus.on('world:updated', (next) => {
      setWorld({ ...next });
    });
    const unsubSecrets = studioBus.on('secrets:updated', (next) => {
      setSecrets({ ...next });
    });
    const unsubVoice = studioBus.on('voice:status', (next) => {
      setVoice({ ...next });
    });
    const unsubBot = studioBus.on('bot:progress', ({ botId, status }) => {
      if (botId === 'asset-hunter') {
        setIsHuntingAssets(status === 'active');
      }
    });

    return () => {
      unsubWorld();
      unsubSecrets();
      unsubVoice();
      unsubBot();
    };
  }, []);

  async function handleSendCommand(text: string) {
    setIsProcessing(true);
    try {
      await jarvisKernel.processUserCommand(text, false);
    } finally {
      setIsProcessing(false);
    }
  }

  async function handleToggleLive() {
    if (voice.liveEnabled) {
      await voiceEngine.stopLive();
    } else {
      await voiceEngine.startLive();
    }
  }

  async function handleOrbTap() {
    await voiceEngine.bargeIn();
  }

  function handleLanguageChange(lang: LanguageCode) {
    jarvisKernel.switchLanguage(lang);
  }

  function handleModeChange(mode: StudioMode) {
    jarvisKernel.switchMode(mode);
  }

  function handleEngineChange(engine: EngineType) {
    jarvisKernel.setEngine(engine);
  }

  function handleSelectPanel(panel: PanelType) {
    if (panel === 'vault') {
      setVaultInitialTab('catalog');
    }
    jarvisKernel.openPanel(panel);
  }

  function handleOpenCheckpoints() {
    setVaultInitialTab('checkpoints');
    if (world.fullscreen) {
      jarvisKernel.toggleFullscreen(false);
    }
    jarvisKernel.openPanel('vault');
  }

  function handleBotSelect(botId: SatelliteBotId) {
    const panelMap: Record<SatelliteBotId, PanelType> = {
      'asset-hunter': 'vault',
      'code-bot': 'code',
      'vision-qa': 'camera',
      'github-heal': 'secrets',
    };
    if (panelMap[botId] === 'vault') {
      setVaultInitialTab('catalog');
    }
    jarvisKernel.openPanel(panelMap[botId]);
  }

  function handleSpawnQuickSubBot() {
    const spec = QUICK_SPECIALISTS[specialistCursor % QUICK_SPECIALISTS.length];
    setSpecialistCursor((c) => c + 1);
    jarvisKernel.spawnSubBot(spec.name, spec.role);
  }

  function handleTogglePause() {
    if (world.paused) {
      jarvisKernel.resumeWork();
    } else {
      jarvisKernel.pauseWork();
    }
  }

  function handleInspect() {
    handleSendCommand('inspect work');
  }

  async function handleBuildApk() {
    await jarvisKernel.startBuildPipeline();
  }

  async function handleHuntAssets(query: string, mode: 'auto' | 'game_3d' | 'commercial_app') {
    setIsHuntingAssets(true);
    try {
      await jarvisKernel.fetchProjectAssets(query, mode);
    } finally {
      setIsHuntingAssets(false);
    }
  }

  async function handleRejectAsset(assetId: string) {
    await jarvisKernel.rejectAndReplaceAsset(assetId);
  }

  async function handleConfirmAssets() {
    await jarvisKernel.confirmSelectedAssetsAndDesign();
  }

  async function handleHotPatch(instruction: string) {
    await jarvisKernel.patchLiveCode(instruction);
  }

  async function handleBuildFromVisionSpec(spec: string) {
    jarvisKernel.openPanel('none');
    await jarvisKernel.startBuildPipeline(spec);
  }

  function handleHome() {
    setConfirmReset(false);
    jarvisKernel.openPanel('none');
    if (world.fullscreen) {
      jarvisKernel.toggleFullscreen(false);
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function handleResetRequest() {
    if (!confirmReset) {
      setConfirmReset(true);
      setTimeout(() => setConfirmReset(false), 5000);
      return;
    }
    setConfirmReset(false);
    jarvisKernel.resetWorkspace();
  }

  return (
    <div className="relative flex min-h-screen flex-col bg-[#050811] text-slate-100">
      {/* Subtle Ambient Landscape of Signals Atmospheric Backlight */}
      <div className="pointer-events-none fixed inset-0 z-0 overflow-hidden" aria-hidden="true">
        <div className="absolute -top-36 left-1/2 h-80 w-[680px] -translate-x-1/2 rounded-full bg-cyan-500/10 blur-[120px]" />
        <div className="absolute top-1/2 left-1/4 h-72 w-72 rounded-full bg-violet-600/10 blur-[130px]" />
      </div>

      {/* Top Bar */}
      <TopBar
        language={world.language}
        mode={world.mode}
        engine={world.selectedEngine}
        onLanguageChange={handleLanguageChange}
        onModeChange={handleModeChange}
        onEngineChange={handleEngineChange}
      />

      {/* Main Responsive Studio Canvas */}
      <main className="relative z-10 mx-auto flex w-full max-w-[1440px] flex-1 flex-col gap-4 px-3 py-3 sm:px-4 sm:py-4">
        {/* Inline Non-Blocking Reset Confirmation Banner */}
        {confirmReset && (
          <div className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-rose-400/40 bg-rose-500/12 px-4 py-2.5 text-xs text-rose-100">
            <span>
              Reset current build stage, candidate assets, and generated files? Secrets Vault, Dynamic Skills, and permanent rules stay safe.
            </span>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setConfirmReset(false)}
                className="rounded-lg border border-white/15 px-3 py-1.5 text-slate-200 hover:bg-white/10 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleResetRequest}
                className="rounded-lg bg-rose-500 px-3 py-1.5 font-semibold text-white hover:bg-rose-400 cursor-pointer"
              >
                Confirm Reset
              </button>
            </div>
          </div>
        )}

        {/* Upper Display A Viewport (Asset Picker, Media/Cut-Scene, 5-Stage Codegen, Live Preview) */}
        <DisplayViewport
          world={world}
          isHuntingAssets={isHuntingAssets}
          onToggleFullscreen={() => jarvisKernel.toggleFullscreen()}
          onInspect={handleInspect}
          onOpenCode={() => jarvisKernel.openPanel('code')}
          onQuickPrompt={(prompt) => handleSendCommand(prompt)}
          onDisplayViewChange={(view) => jarvisKernel.setDisplayView(view)}
          onKeepAsset={(id) => jarvisKernel.toggleKeepAsset(id)}
          onRejectAsset={handleRejectAsset}
          onHuntAssets={handleHuntAssets}
          onConfirmAssets={handleConfirmAssets}
          onRuntimeError={(payload) => jarvisKernel.reportPreviewRuntimeError(payload)}
          onPreviewReady={() => jarvisKernel.reportPreviewReady()}
          onClearErrors={() => jarvisKernel.clearRuntimeErrors()}
          onHotPatch={handleHotPatch}
          onOpenCheckpoints={handleOpenCheckpoints}
          onPublishGitHubApk={() => jarvisKernel.publishToGitHubAndBuildApk()}
          onDownloadZip={() => jarvisKernel.downloadLocalZip()}
        />

        {/* Active Workspace Panels (Secrets / Code / Vault / Admin / Camera) */}
        {world.activePanel === 'secrets' && (
          <SecretsPanel
            secrets={secrets}
            onSaveSecrets={(next) => jarvisKernel.updateSecrets(next)}
            onClose={() => jarvisKernel.openPanel('none')}
          />
        )}

        {world.activePanel === 'code' && (
          <CodePanel
            files={world.generatedFiles}
            onUpdateFile={(path, content) => jarvisKernel.updateGeneratedFile(path, content)}
            onStartBuild={handleBuildApk}
            onClose={() => jarvisKernel.openPanel('none')}
          />
        )}

        {world.activePanel === 'vault' && (
          <VaultPanel
            repoSlug={secrets.assetVaultRepo}
            githubPat={secrets.githubPat}
            checkpoints={world.checkpoints}
            initialTab={vaultInitialTab}
            onOpenSecrets={() => jarvisKernel.openPanel('secrets')}
            onPickAssetToDisplay={(item) => jarvisKernel.addVaultAssetToPicker(item)}
            onRestoreCheckpoint={(id) => jarvisKernel.restoreCheckpoint(id)}
            onDeleteCheckpoint={(id) => jarvisKernel.deleteCheckpoint(id)}
            onClose={() => jarvisKernel.openPanel('none')}
          />
        )}

        {world.activePanel === 'admin' && (
          <AdminPanel
            world={world}
            hasGithubPat={Boolean(secrets.githubPat.trim() && secrets.githubUsername.trim())}
            hasAppsSupabase={Boolean(
              secrets.appsSupabase.url.trim() && secrets.appsSupabase.anonKey.trim()
            )}
            onSaveRule={async (rule) => {
              await jarvisKernel.saveUserRule(rule);
            }}
            onDeleteRule={(id) => jarvisKernel.deleteUserRule(id)}
            onSpawnSubBot={(name, role) => jarvisKernel.spawnSubBot(name, role)}
            onRemoveSubBot={(id) => jarvisKernel.removeSubBot(id)}
            onLearnApiSkill={(url, name) => jarvisKernel.fetchAnyApi(url, name)}
            onDeleteSkill={(id) => jarvisKernel.deleteDynamicSkill(id)}
            onPublishGitHubApk={(repoName) => jarvisKernel.publishToGitHubAndBuildApk(repoName)}
            onDownloadZip={(repoName) => jarvisKernel.downloadLocalZip(repoName)}
            onUpdateAppsRemoteConfig={(payload) => jarvisKernel.updateAppsRemoteConfig(payload)}
            onOpenSecrets={() => jarvisKernel.openPanel('secrets')}
            onClose={() => jarvisKernel.openPanel('none')}
          />
        )}

        {world.activePanel === 'camera' && (
          <CameraPanel
            capturedSnapshot={world.capturedSnapshot}
            visionAnalysis={world.visionAnalysis}
            onCaptureSnapshot={(url) => jarvisKernel.setCapturedSnapshot(url)}
            onAnalyzeWithJarvis={(url, hint) => jarvisKernel.analyzeCameraFrame(url, hint)}
            onBuildFromVisionSpec={handleBuildFromVisionSpec}
            onClose={() => jarvisKernel.openPanel('none')}
          />
        )}

        {/* Middle: Landscape of Signals — JARVIS Command Center */}
        <CommandCenter
          world={world}
          voiceState={voice.state}
          voiceTransport={voice.transport}
          liveEnabled={voice.liveEnabled}
          onOrbTap={handleOrbTap}
          onBotSelect={handleBotSelect}
          onSpawnQuickSubBot={handleSpawnQuickSubBot}
          onRemoveSubBot={(id) => jarvisKernel.removeSubBot(id)}
        />

        {/* Control Strip + Scrollable JARVIS Chat Transcript & Command Input */}
        <ControlStripAndChat
          activePanel={world.activePanel}
          messages={world.chatHistory}
          voice={voice}
          isProcessing={isProcessing}
          onSelectPanel={handleSelectPanel}
          onSendCommand={handleSendCommand}
          onBargeIn={handleOrbTap}
        />
      </main>

      {/* Bottom Action Bar */}
      <BottomActionBar
        paused={world.paused}
        voice={voice}
        onTogglePause={handleTogglePause}
        onReset={handleResetRequest}
        onToggleLive={handleToggleLive}
        onBuildApk={handleBuildApk}
        onHome={handleHome}
      />
    </div>
  );
}
