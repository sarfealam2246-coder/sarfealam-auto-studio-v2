export type LanguageCode = 'en' | 'hi';
export type StudioMode = 'jarvis' | 'manual';
export type EngineType = 'Auto' | 'Capacitor 3D/App' | 'Godot 4' | 'Flutter' | 'Unity';
export type PanelType = 'none' | 'secrets' | 'code' | 'vault' | 'admin' | 'camera';
export type VoiceState = 'IDLE' | 'LISTENING' | 'THINKING' | 'SPEAKING' | 'PAUSED';
export type VoiceTransport = 'gemini-live' | 'native-bridge';
export type AIProviderId = 'gemini' | 'groq' | 'nvidia' | 'openrouter' | 'cohere';
export type SatelliteBotId = 'asset-hunter' | 'code-bot' | 'vision-qa' | 'github-heal';

export type AssetCategory =
  | 'vehicles'
  | 'characters'
  | 'weapons_gear'
  | 'village_world'
  | 'textures_pbr'
  | 'hdri_sky'
  | 'audio_sfx'
  | 'app_audio'
  | 'web_photo'
  | 'vector_icon'
  | 'generated_image';

export type AssetFormat = 'glb' | 'pbr' | 'hdr' | 'audio' | 'image' | 'svg';

export interface PolyHavenResolvedMaps {
  diffuse?: string;
  normal?: string;
  roughness?: string;
  hdr1k?: string;
  resolvedAt: number;
}

export interface StudioAssetItem {
  id: string;
  name: string;
  category: AssetCategory;
  source: string;
  rawUrl: string;
  thumbUrl?: string;
  apiFilesUrl?: string;
  pbrMaps?: PolyHavenResolvedMaps;
  format: AssetFormat;
  tags: string[];
  status: 'candidate' | 'kept' | 'rejected';
}

export interface DynamicSkill {
  id: string;
  name: string;
  url: string;
  description: string;
  httpStatus: number;
  sampleKeys: string[];
  previewSnippet: string;
  createdAt: number;
  syncedToSupabase: boolean;
}

export interface VisionAnalysisRecord {
  id: string;
  imageDataUrl: string;
  summary: string;
  buildSpec: string;
  model: string;
  timestamp: number;
}

export interface GeneratedMediaItem {
  id: string;
  kind: 'image' | 'cutscene';
  prompt: string;
  dataUrl?: string;
  cutsceneHtml?: string;
  modelUsed: string;
  note?: string;
  timestamp: number;
}

export interface SatelliteBotState {
  id: SatelliteBotId;
  name: string;
  role: string;
  status: 'idle' | 'active' | 'paused' | 'done' | 'error';
  currentTask: string;
  progress: number;
  telemetryBars: number[];
  accent: 'cyan' | 'violet' | 'emerald' | 'amber';
}

export interface SubBotState {
  id: string;
  name: string;
  role: string;
  status: 'active' | 'paused' | 'idle';
  spawnedAt: number;
  telemetryBars: number[];
}

export interface GeneratedFile {
  path: string;
  language: string;
  content: string;
  updatedAt: number;
}

export interface ActuatorExecutionRecord {
  tool: string;
  args: Record<string, unknown>;
  result: string;
  timestamp: number;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'jarvis' | 'system';
  text: string;
  timestamp: number;
  provider?: string;
  actuators?: ActuatorExecutionRecord[];
}

export interface UserRule {
  id: string;
  rule: string;
  createdAt: number;
  syncedToSupabase: boolean;
}

export interface SupabaseEndpointConfig {
  url: string;
  anonKey: string;
  lastStatus?: number;
  lastMessage?: string;
  testedAt?: number;
}

export interface ProviderTestResult {
  ok: boolean;
  httpStatus: number;
  latencyMs: number;
  model: string;
  message: string;
  testedAt: number;
}

export interface SecretsConfig {
  apiKeys: Record<AIProviderId, string>;
  activeProvider: AIProviderId | 'auto';
  preferGeminiLive: boolean;
  githubUsername: string;
  githubPat: string;
  assetVaultRepo: string;
  studioSupabase: SupabaseEndpointConfig;
  appsSupabase: SupabaseEndpointConfig;
}

export type DisplayViewMode = 'auto' | 'assets' | 'preview' | 'media';

export interface RollbackCheckpoint {
  id: string;
  label: string;
  engine: EngineType;
  prompt: string;
  previewHtml: string;
  generatedFiles: GeneratedFile[];
  createdAt: number;
}

export interface RuntimeErrorEvent {
  id: string;
  message: string;
  source?: string;
  line?: number;
  timestamp: number;
}

export interface CodeGenStageState {
  stage: number; // 1..5
  title: string;
  detail: string;
  completedStages: number[];
}

export interface ReleaseLinks {
  repoFullName: string;
  repoUrl: string;
  actionsUrl: string;
  pagesUrl: string;
  liveTestUrl: string;
  adminPanelUrl: string;
  releasesUrl: string;
  apkDownloadUrl?: string;
  apkFileName?: string;
  updatedAt: number;
}

export interface ActiveBuildJob {
  id: string;
  prompt: string;
  engine: EngineType;
  repoOwner: string;
  repoName: string;
  repoFullName: string;
  commitSha?: string;
  githubRunId?: number;
  runHtmlUrl?: string;
  status:
    | 'pushing'
    | 'queued'
    | 'in_progress'
    | 'healing'
    | 'completed'
    | 'failed'
    | 'paused';
  healRound: number;
  maxHealRounds: number;
  lastErrorLog?: string;
  lastHealSummary?: string;
  statusMessage: string;
  apkDownloadUrl?: string;
  apkFileName?: string;
  startedAt: number;
  updatedAt: number;
}

export interface ErrorMemoryRecord {
  id: string;
  engine: EngineType;
  errorSignature: string;
  diagnosis: string;
  fixSummary: string;
  patchedPath: string;
  patchedContentSnippet: string;
  createdAt: number;
}

export interface AppsRemoteConfig {
  appSlug: string;
  appName: string;
  engine: EngineType;
  versionName: string;
  bannerText: string;
  discountPercent: number;
  gameSpeed: number;
  difficulty: 'easy' | 'normal' | 'hard';
  ownerPinHash?: string;
  updatedAt: number;
}

export interface WorldState {
  activePrompt: string;
  selectedEngine: EngineType;
  language: LanguageCode;
  mode: StudioMode;
  paused: boolean;
  currentStage: number; // 0..5
  stageLabel: string;
  stageStepIndex: number; // exact cursor for pause/resume
  fullscreen: boolean;
  generatedFiles: GeneratedFile[];
  runningBots: Record<SatelliteBotId, SatelliteBotState>;
  spawnedSubBots: SubBotState[];
  userRules: UserRule[];
  activePanel: PanelType;
  chatHistory: ChatMessage[];
  previewHtml: string | null;
  capturedSnapshot: string | null;
  // Phase 2 State: Asset Picker, Vision Eye, Generated Media, Dynamic Skills
  candidateAssets: StudioAssetItem[];
  assetBackupPool: StudioAssetItem[];
  selectedAssets: StudioAssetItem[];
  assetsConfirmed: boolean;
  dynamicSkills: DynamicSkill[];
  visionAnalysis: VisionAnalysisRecord | null;
  generatedMedia: GeneratedMediaItem[];
  activeDisplayView: DisplayViewMode;
  // Phase 3 State: 5-Stage Codegen, Rollback Checkpoints, Runtime Vision QA
  checkpoints: RollbackCheckpoint[];
  runtimeErrors: RuntimeErrorEvent[];
  codeGenProgress: CodeGenStageState | null;
  // Phase 4 State: Atomic GitHub Export, Self-Healing Actions Loop & Release Links
  activeJob: ActiveBuildJob | null;
  releaseLinks: ReleaseLinks | null;
  lastUpdated: number;
}

export interface VoiceStatusSnapshot {
  liveEnabled: boolean;
  state: VoiceState;
  transport: VoiceTransport;
  isNativePlatform: boolean;
  interimTranscript: string;
  lastError: string | null;
  greeted: boolean;
}
