import { Home, Pause, Play, Radio, Rocket, RotateCcw } from 'lucide-react';
import type { VoiceStatusSnapshot } from '../types/studio';

interface BottomActionBarProps {
  paused: boolean;
  voice: VoiceStatusSnapshot;
  onTogglePause: () => void;
  onReset: () => void;
  onToggleLive: () => void;
  onBuildApk: () => void;
  onHome: () => void;
}

export function BottomActionBar({
  paused,
  voice,
  onTogglePause,
  onReset,
  onToggleLive,
  onBuildApk,
  onHome,
}: BottomActionBarProps) {
  return (
    <footer className="sticky bottom-0 z-30 border-t border-cyan-500/15 bg-[#050811]/95 backdrop-blur-xl pb-safe">
      <div className="mx-auto flex max-w-[1440px] items-center justify-between gap-2 px-3 py-2.5 sm:px-4">
        {/* Pause / Resume + Reset */}
        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={onTogglePause}
            className={`inline-flex min-h-[44px] items-center justify-center gap-1.5 rounded-xl border px-3 sm:px-3.5 text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
              paused
                ? 'border-amber-400/55 bg-amber-500/20 text-amber-200 hover:bg-amber-500/30'
                : 'border-white/12 bg-[#0C1428] text-slate-200 hover:border-cyan-400/40'
            }`}
          >
            {paused ? <Play className="h-4 w-4" /> : <Pause className="h-4 w-4" />}
            <span>{paused ? 'Resume' : 'Pause'}</span>
          </button>

          <button
            type="button"
            onClick={onReset}
            title="Reset workspace files & pipeline stage"
            aria-label="Reset workspace"
            className="inline-flex min-h-[44px] min-w-[44px] items-center justify-center gap-1 rounded-xl border border-white/10 bg-[#0C1428] px-2.5 text-xs font-medium text-slate-400 hover:border-rose-400/45 hover:text-rose-200 transition-colors cursor-pointer whitespace-nowrap"
          >
            <RotateCcw className="h-4 w-4" />
            <span className="hidden md:inline">Reset</span>
          </button>
        </div>

        {/* Live ON/OFF */}
        <button
          type="button"
          onClick={onToggleLive}
          className={`inline-flex min-h-[44px] items-center justify-center gap-1.5 rounded-xl border px-3.5 sm:px-4 text-xs font-semibold transition-all cursor-pointer whitespace-nowrap ${
            voice.liveEnabled
              ? 'border-emerald-400/60 bg-emerald-500/20 text-emerald-100 shadow-[0_0_20px_rgba(16,185,129,0.25)]'
              : 'border-cyan-400/35 bg-cyan-500/12 text-cyan-200 hover:bg-cyan-500/20'
          }`}
        >
          <Radio className="h-4 w-4" />
          <span>{voice.liveEnabled ? 'Live ON' : 'Live OFF'}</span>
        </button>

        {/* OK · Build/APK */}
        <button
          type="button"
          onClick={onBuildApk}
          className="inline-flex min-h-[44px] flex-1 sm:flex-none sm:min-w-[165px] items-center justify-center gap-1.5 rounded-xl bg-gradient-to-r from-cyan-400 to-violet-500 px-3.5 sm:px-5 text-xs sm:text-sm font-bold text-slate-950 shadow-[0_0_24px_rgba(34,211,238,0.28)] hover:brightness-110 active:scale-[0.98] transition-all cursor-pointer whitespace-nowrap"
        >
          <Rocket className="h-4 w-4 shrink-0" />
          <span>OK · Build/APK</span>
        </button>

        {/* Home */}
        <button
          type="button"
          onClick={onHome}
          aria-label="Return Home"
          className="inline-flex min-h-[44px] min-w-[44px] items-center justify-center gap-1.5 rounded-xl border border-white/10 bg-[#0C1428] px-3 text-xs font-medium text-slate-200 hover:border-cyan-400/40 hover:text-cyan-100 transition-colors cursor-pointer whitespace-nowrap"
        >
          <Home className="h-4 w-4" />
          <span className="hidden sm:inline">Home</span>
        </button>
      </div>
    </footer>
  );
}
