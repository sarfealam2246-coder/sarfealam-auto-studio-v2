import { useState } from 'react';
import {
  ArrowRight,
  Box,
  Check,
  Image as ImageIcon,
  Layers,
  Loader2,
  Music,
  Search,
  Sparkles,
  Sun,
  X,
} from 'lucide-react';
import type { AssetCategory, StudioAssetItem } from '../types/studio';

interface AssetPickerViewProps {
  candidates: StudioAssetItem[];
  assetsConfirmed: boolean;
  isHunting: boolean;
  onKeepToggle: (assetId: string) => void;
  onRejectReplace: (assetId: string) => Promise<void>;
  onHuntMore: (query: string, mode: 'auto' | 'game_3d' | 'commercial_app') => Promise<void>;
  onConfirmSelected: () => Promise<void>;
}

const CATEGORY_LABELS: Record<AssetCategory, string> = {
  vehicles: 'Vehicles · 3D',
  characters: 'Characters · 3D',
  weapons_gear: 'Weapons & Gear',
  village_world: 'Village & World',
  textures_pbr: 'PBR Texture',
  hdri_sky: 'HDRI Sky',
  audio_sfx: 'Audio SFX',
  app_audio: 'App Audio',
  web_photo: 'Web Photo',
  vector_icon: 'Vector Icon',
  generated_image: 'Gemini Image',
};

function AssetThumbnail({ item }: { item: StudioAssetItem }) {
  const [imgFailed, setImgFailed] = useState(false);

  if (item.format === 'audio') {
    return (
      <div className="flex h-28 flex-col justify-between rounded-lg border border-cyan-400/20 bg-[#050A17] p-2.5">
        <div className="flex items-center gap-2 text-cyan-300">
          <Music className="h-4 w-4 shrink-0" />
          <span className="font-mono text-[11px] truncate">WAV / Audio SFX</span>
        </div>
        <audio
          controls
          preload="none"
          src={item.rawUrl}
          className="h-8 w-full accent-cyan-400"
        />
      </div>
    );
  }

  if (item.thumbUrl && !imgFailed) {
    return (
      <div className="relative h-28 w-full overflow-hidden rounded-lg border border-white/10 bg-[#050914] flex items-center justify-center">
        <img
          src={item.thumbUrl}
          alt={item.name}
          referrerPolicy="no-referrer"
          loading="lazy"
          onError={() => setImgFailed(true)}
          className={
            item.format === 'svg'
              ? 'h-14 w-14 object-contain'
              : 'h-full w-full object-cover'
          }
        />
      </div>
    );
  }

  // Resilient CSS/SVG visual fallback for .glb / .hdr / PBR without thumbnail
  const Icon =
    item.format === 'hdr'
      ? Sun
      : item.format === 'pbr'
      ? Layers
      : item.format === 'image' || item.format === 'svg'
      ? ImageIcon
      : Box;

  return (
    <div className="flex h-28 w-full flex-col items-center justify-center gap-1.5 rounded-lg border border-white/10 bg-gradient-to-br from-[#0B142B] via-[#070C1B] to-[#13102B] px-3 text-center">
      <Icon className="h-6 w-6 text-cyan-300/85" />
      <span className="font-mono text-[11px] uppercase tracking-wider text-slate-300">
        {item.format === 'glb'
          ? '3D GLB Model'
          : item.format === 'pbr'
          ? 'PolyHaven PBR'
          : item.format === 'hdr'
          ? 'PolyHaven 1K HDRI'
          : 'Studio Asset'}
      </span>
    </div>
  );
}

export function AssetPickerView({
  candidates,
  assetsConfirmed,
  isHunting,
  onKeepToggle,
  onRejectReplace,
  onHuntMore,
  onConfirmSelected,
}: AssetPickerViewProps) {
  const [replacingId, setReplacingId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [confirming, setConfirming] = useState(false);

  const keptCount = candidates.filter((c) => c.status === 'kept').length;
  const effectiveConfirmCount = keptCount > 0 ? keptCount : candidates.length;

  async function handleReject(id: string) {
    setReplacingId(id);
    try {
      await onRejectReplace(id);
    } finally {
      setReplacingId(null);
    }
  }

  async function handleSearchSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!searchQuery.trim() || isHunting) return;
    await onHuntMore(searchQuery.trim(), 'auto');
    setSearchQuery('');
  }

  async function handleConfirm() {
    if (confirming || candidates.length === 0) return;
    setConfirming(true);
    try {
      await onConfirmSelected();
    } finally {
      setConfirming(false);
    }
  }

  return (
    <div className="flex h-full flex-col justify-between p-3 sm:p-4 gap-3">
      {/* Top Bar inside Display A: Search + Voice Hint */}
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="text-xs text-slate-300">
          <span className="font-semibold text-cyan-200">Interactive Asset Picker</span>
          <span className="mx-1.5 text-slate-600" aria-hidden="true">·</span>
          <span className="text-slate-400">
            Say “Keep the first and third, reject the second” or tap ✓ / ✕
          </span>
        </div>

        <form onSubmit={handleSearchSubmit} className="flex items-center gap-1.5 w-full sm:w-auto">
          <div className="relative flex-1 sm:w-56">
            <Search className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-500" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Hunt vault, Wikimedia, icons..."
              className="h-9 w-full rounded-lg border border-white/10 bg-[#050914] pl-8 pr-2.5 text-xs text-slate-100 placeholder:text-slate-500 focus:border-cyan-400/50 focus:outline-none"
            />
          </div>
          <button
            type="submit"
            disabled={!searchQuery.trim() || isHunting}
            className="inline-flex h-9 items-center gap-1 rounded-lg border border-cyan-400/35 bg-cyan-500/15 px-3 text-xs font-semibold text-cyan-200 hover:bg-cyan-500/25 disabled:opacity-45 cursor-pointer whitespace-nowrap"
          >
            {isHunting ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : 'Hunt'}
          </button>
        </form>
      </div>

      {/* Asset Cards Grid */}
      {isHunting && candidates.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-10 text-xs text-slate-300 gap-2">
          <Loader2 className="h-5 w-5 animate-spin text-cyan-400" />
          <span>Asset Hunter is fetching Vault 3D models, PolyHaven maps, Wikimedia photos & icons...</span>
        </div>
      ) : candidates.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-8 text-center">
          <Sparkles className="h-5 w-5 text-cyan-300 mb-2" />
          <p className="text-xs text-slate-300">No asset candidates loaded yet.</p>
          <p className="mt-1 text-xs text-slate-500">
            Search above or run “Fetch assets for army truck village game”.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5 max-h-[340px] overflow-y-auto pr-0.5">
          {candidates.map((item, idx) => {
            const isKept = item.status === 'kept';
            const isReplacing = replacingId === item.id;

            return (
              <div
                key={item.id}
                className={`flex flex-col justify-between rounded-xl border p-2.5 transition-all duration-200 ${
                  isKept
                    ? 'border-emerald-400/60 bg-emerald-950/20 shadow-[0_0_20px_rgba(16,185,129,0.16)]'
                    : 'border-white/[0.08] bg-[#0B1226]/90'
                }`}
              >
                <div>
                  <AssetThumbnail item={item} />

                  <div className="mt-2">
                    <div className="flex items-center justify-between gap-1.5">
                      <span className="font-mono text-[11px] font-semibold text-cyan-300 tabular-nums shrink-0">
                        #{idx + 1}
                      </span>
                      <span className="text-xs font-semibold text-slate-100 truncate flex-1">
                        {item.name}
                      </span>
                    </div>

                    {/* Zero-pill clean unboxed metadata */}
                    <div className="mt-0.5 flex items-center gap-1.5 text-[11px] text-slate-400 truncate">
                      <span className="truncate">{item.source}</span>
                      <span aria-hidden="true">·</span>
                      <span className="truncate text-slate-300">
                        {CATEGORY_LABELS[item.category]}
                      </span>
                    </div>

                    {item.pbrMaps && (
                      <div className="mt-1 font-mono text-[10px] text-cyan-300/85 truncate">
                        {[
                          item.pbrMaps.diffuse && 'Diffuse',
                          item.pbrMaps.normal && 'Normal',
                          item.pbrMaps.roughness && 'Rough',
                          item.pbrMaps.hdr1k && '1K HDR',
                        ]
                          .filter(Boolean)
                          .join(' · ')}{' '}
                        resolved
                      </div>
                    )}
                  </div>
                </div>

                {/* ✓ Keep / ✕ Reject Action Row */}
                <div className="mt-2.5 grid grid-cols-2 gap-1.5">
                  <button
                    type="button"
                    disabled={isReplacing}
                    onClick={() => onKeepToggle(item.id)}
                    className={`inline-flex min-h-[38px] items-center justify-center gap-1 rounded-lg border text-xs font-semibold transition-all cursor-pointer ${
                      isKept
                        ? 'border-emerald-400/70 bg-emerald-500/25 text-emerald-100 shadow-[0_0_14px_rgba(16,185,129,0.28)]'
                        : 'border-emerald-400/30 bg-emerald-500/10 text-emerald-200 hover:bg-emerald-500/20'
                    }`}
                  >
                    <Check className="h-3.5 w-3.5" />
                    <span>{isKept ? 'Kept' : 'Keep'}</span>
                  </button>

                  <button
                    type="button"
                    disabled={isReplacing}
                    onClick={() => handleReject(item.id)}
                    className="inline-flex min-h-[38px] items-center justify-center gap-1 rounded-lg border border-rose-400/35 bg-rose-500/12 text-xs font-semibold text-rose-200 hover:bg-rose-500/24 disabled:opacity-50 transition-colors cursor-pointer"
                  >
                    {isReplacing ? (
                      <Loader2 className="h-3.5 w-3.5 animate-spin" />
                    ) : (
                      <X className="h-3.5 w-3.5" />
                    )}
                    <span>{isReplacing ? 'Swap...' : 'Reject'}</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Prominent Confirm CTA Footer */}
      {candidates.length > 0 && (
        <div className="flex flex-wrap items-center justify-between gap-2 border-t border-white/[0.08] pt-3">
          <div className="text-xs text-slate-400 font-mono tabular-nums">
            {keptCount > 0
              ? `${keptCount} kept · ${candidates.length} shown`
              : `All ${candidates.length} candidates ready (tap ✓ Keep to filter)`}
            {assetsConfirmed && ' · Locked in World State'}
          </div>

          <button
            type="button"
            disabled={confirming}
            onClick={handleConfirm}
            className="inline-flex min-h-[42px] items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-emerald-400 to-cyan-400 px-4 text-xs sm:text-sm font-bold text-slate-950 shadow-[0_0_22px_rgba(16,185,129,0.28)] hover:brightness-110 disabled:opacity-55 cursor-pointer whitespace-nowrap"
          >
            {confirming ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Check className="h-4 w-4" />
            )}
            <span>Confirm Selected Assets ({effectiveConfirmCount}) → Design</span>
            <ArrowRight className="h-4 w-4" />
          </button>
        </div>
      )}
    </div>
  );
}
