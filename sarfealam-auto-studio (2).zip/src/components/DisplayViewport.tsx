import { useState } from 'react';
import {
  Check,
  Download,
  ExternalLink,
  Eye,
  Film,
  FolderArchive,
  GitBranch,
  Image as ImageIcon,
  Layers,
  Loader2,
  Lock,
  Maximize2,
  Minimize2,
  PauseCircle,
  Sparkles,
} from 'lucide-react';
import { PIPELINE_STAGES } from '../services/jarvisKernel';
import type { DisplayViewMode, WorldState } from '../types/studio';
import { AssetPickerView } from './AssetPickerView';
import { LivePreviewFrame } from './LivePreviewFrame';

const CODEGEN_STAGES = [
  { stage: 1, title: 'Architecture & Asset Binding' },
  { stage: 2, title: 'World / UI Shell' },
  { stage: 3, title: 'Core Physics / App Logic' },
  { stage: 4, title: 'Controls, Audio SFX & Polish' },
  { stage: 5, title: 'Final Self-Check & Multi-File Packaging' },
];

interface DisplayViewportProps {
  world: WorldState;
  isHuntingAssets: boolean;
  onToggleFullscreen: () => void;
  onInspect: () => void;
  onOpenCode: () => void;
  onQuickPrompt: (prompt: string) => void;
  onDisplayViewChange: (view: DisplayViewMode) => void;
  onKeepAsset: (assetId: string) => void;
  onRejectAsset: (assetId: string) => Promise<void>;
  onHuntAssets: (query: string, mode: 'auto' | 'game_3d' | 'commercial_app') => Promise<void>;
  onConfirmAssets: () => Promise<void>;
  onRuntimeError: (payload: { message: string; source?: string; line?: number }) => void;
  onPreviewReady: () => void;
  onClearErrors: () => void;
  onHotPatch: (instruction: string) => Promise<void>;
  onOpenCheckpoints: () => void;
  onPublishGitHubApk: () => Promise<string>;
  onDownloadZip: () => Promise<string>;
}

const STARTER_BLUEPRINTS = [
  'Fetch assets for army truck village 3D game',
  'Build a modern Indian kirana store billing APK',
  'Generate image of futuristic dark neon studio banner',
];

function isSafeHttps(url?: string): boolean {
  return Boolean(url && /^https:\/\//i.test(url));
}

export function DisplayViewport({
  world,
  isHuntingAssets,
  onToggleFullscreen,
  onInspect,
  onOpenCode,
  onQuickPrompt,
  onDisplayViewChange,
  onKeepAsset,
  onRejectAsset,
  onHuntAssets,
  onConfirmAssets,
  onRuntimeError,
  onPreviewReady,
  onClearErrors,
  onHotPatch,
  onOpenCheckpoints,
  onPublishGitHubApk,
  onDownloadZip,
}: DisplayViewportProps) {
  const [pushingApk, setPushingApk] = useState(false);
  const [downloadingZip, setDownloadingZip] = useState(false);

  const isFullscreen = world.fullscreen;
  const stageNum = world.currentStage;

  const hasAssets = world.candidateAssets.length > 0 || isHuntingAssets;
  const hasMedia = world.generatedMedia.length > 0;
  const hasPreview = Boolean(world.previewHtml);
  const isCodeGenerating = Boolean(world.codeGenProgress);

  // Resolve active Display A view cleanly
  const resolvedView: 'welcome' | 'assets' | 'media' | 'preview' | 'codegen' =
    isCodeGenerating && !hasPreview
      ? 'codegen'
      : world.activeDisplayView === 'assets' && hasAssets
      ? 'assets'
      : world.activeDisplayView === 'media' && hasMedia
      ? 'media'
      : world.activeDisplayView === 'preview' && hasPreview
      ? 'preview'
      : isCodeGenerating
      ? 'codegen'
      : hasAssets && !world.assetsConfirmed
      ? 'assets'
      : hasPreview
      ? 'preview'
      : hasMedia
      ? 'media'
      : hasAssets
      ? 'assets'
      : 'welcome';

  const latestMedia = world.generatedMedia[0] ?? null;

  return (
    <section
      aria-label="Display A Studio Viewport"
      className={
        isFullscreen
          ? 'fixed inset-0 z-50 flex flex-col bg-[#050811] p-3 sm:p-5'
          : 'relative w-full'
      }
    >
      <div
        className={`relative flex flex-col overflow-hidden rounded-2xl border bg-[#070C1A]/90 backdrop-blur-xl transition-all duration-200 ${
          world.paused
            ? 'border-amber-400/45 shadow-[0_0_32px_rgba(245,158,11,0.14)]'
            : 'border-cyan-400/30 shadow-[0_0_36px_rgba(34,211,238,0.12),inset_0_1px_0_rgba(167,139,250,0.22)]'
        } ${isFullscreen ? 'flex-1' : 'min-h-[240px] sm:min-h-[275px]'}`}
      >
        {/* Top Luminous Hairline Accent */}
        <div
          className="pointer-events-none h-[2px] w-full bg-gradient-to-r from-cyan-400/70 via-violet-500/80 to-cyan-400/70"
          aria-hidden="true"
        />

        {/* Viewport Header + View Switcher + Fullscreen */}
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/[0.07] bg-[#091022]/85 px-4 py-2.5">
          <div className="flex items-center gap-2.5 min-w-0">
            <span className="font-display text-xs font-semibold tracking-wide text-cyan-200 whitespace-nowrap">
              Display A
            </span>
            <span className="text-slate-600" aria-hidden="true">·</span>
            <span className="text-xs text-slate-400 truncate max-w-[180px] sm:max-w-[300px]">
              {world.activePrompt || `${world.selectedEngine} Workspace`}
            </span>
            {world.paused && (
              <>
                <span className="text-slate-600" aria-hidden="true">·</span>
                <span className="inline-flex items-center gap-1 text-xs font-medium text-amber-300 whitespace-nowrap">
                  <PauseCircle className="h-3.5 w-3.5" />
                  Paused
                </span>
              </>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-1.5 shrink-0">
            {/* Contextual Display A Tabs when multiple views are available */}
            {(hasAssets || hasMedia || hasPreview) && (
              <div className="inline-flex items-center rounded-lg border border-white/10 bg-[#050914] p-0.5">
                {hasAssets && (
                  <button
                    type="button"
                    onClick={() => onDisplayViewChange('assets')}
                    className={`inline-flex h-7 items-center gap-1 rounded-md px-2 text-[11px] font-medium cursor-pointer ${
                      resolvedView === 'assets'
                        ? 'bg-cyan-500/20 text-cyan-200'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <Layers className="h-3 w-3" />
                    <span>Assets ({world.candidateAssets.length})</span>
                  </button>
                )}
                {hasMedia && (
                  <button
                    type="button"
                    onClick={() => onDisplayViewChange('media')}
                    className={`inline-flex h-7 items-center gap-1 rounded-md px-2 text-[11px] font-medium cursor-pointer ${
                      resolvedView === 'media'
                        ? 'bg-violet-500/25 text-violet-200'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {latestMedia?.kind === 'cutscene' ? (
                      <Film className="h-3 w-3" />
                    ) : (
                      <ImageIcon className="h-3 w-3" />
                    )}
                    <span>Media ({world.generatedMedia.length})</span>
                  </button>
                )}
                {hasPreview && (
                  <button
                    type="button"
                    onClick={() => onDisplayViewChange('preview')}
                    className={`inline-flex h-7 items-center gap-1 rounded-md px-2 text-[11px] font-medium cursor-pointer ${
                      resolvedView === 'preview'
                        ? 'bg-emerald-500/20 text-emerald-200'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <span>Preview</span>
                  </button>
                )}
              </div>
            )}

            {(world.generatedFiles.length > 0 || world.candidateAssets.length > 0 || world.paused) && (
              <button
                type="button"
                onClick={onInspect}
                className="inline-flex min-h-[34px] items-center gap-1.5 rounded-lg border border-white/10 bg-white/[0.04] px-2.5 text-xs font-medium text-slate-200 hover:border-cyan-400/40 hover:text-cyan-200 transition-colors cursor-pointer"
                title="Inspect current build work aloud"
              >
                <Eye className="h-3.5 w-3.5" />
                <span>Inspect</span>
              </button>
            )}

            <button
              type="button"
              onClick={onToggleFullscreen}
              className="inline-flex min-h-[34px] min-w-[34px] items-center justify-center gap-1.5 rounded-lg border border-white/10 bg-white/[0.04] px-2.5 text-xs font-medium text-slate-200 hover:border-cyan-400/40 hover:text-cyan-200 transition-colors cursor-pointer"
              aria-label={isFullscreen ? 'Collapse Display A' : 'Expand Display A fullscreen'}
            >
              {isFullscreen ? (
                <>
                  <Minimize2 className="h-3.5 w-3.5" />
                  <span className="hidden sm:inline">Exit Fullscreen</span>
                </>
              ) : (
                <>
                  <Maximize2 className="h-3.5 w-3.5" />
                  <span className="hidden sm:inline">Fullscreen</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* 5-Stage Progress Bar */}
        <div className="border-b border-white/[0.06] bg-[#060A16]/80 px-4 py-2">
          <div className="grid grid-cols-5 gap-1.5 sm:gap-2.5">
            {PIPELINE_STAGES.map((st) => {
              const completed =
                stageNum > st.stage ||
                (stageNum === 5 &&
                  (world.stageLabel === 'Build Ready' || world.stageLabel === 'APK Ready'));
              const current = stageNum === st.stage && !completed;
              return (
                <div key={st.stage} className="flex flex-col gap-1 min-w-0">
                  <div className="flex items-center justify-between gap-1 text-[11px] leading-none">
                    <span
                      className={`truncate font-medium ${
                        completed
                          ? 'text-emerald-300'
                          : current
                          ? world.paused
                            ? 'text-amber-300'
                            : 'text-cyan-200'
                          : 'text-slate-500'
                      }`}
                    >
                      {st.stage}. {st.label}
                    </span>
                    {completed && <Check className="h-3 w-3 shrink-0 text-emerald-400" />}
                  </div>
                  <div className="h-1.5 w-full overflow-hidden rounded-full bg-slate-800/90">
                    <div
                      className={`h-full rounded-full transition-all duration-300 ${
                        completed
                          ? 'w-full bg-emerald-400'
                          : current
                          ? world.paused
                            ? 'w-2/3 bg-amber-400'
                            : 'w-2/3 bg-gradient-to-r from-cyan-400 to-violet-400'
                          : 'w-0'
                      }`}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Phase 4: Live Cloud APK Release, Owner Admin Web & 1-Tap Local ZIP Strip */}
        {(world.releaseLinks || world.activeJob || world.generatedFiles.length > 0) && (
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/[0.06] bg-[#080F22]/90 px-4 py-2 text-xs">
            <div className="flex items-center gap-2 min-w-0">
              {world.activeJob && ['pushing', 'queued', 'in_progress', 'healing'].includes(world.activeJob.status) && (
                <Loader2 className="h-3.5 w-3.5 shrink-0 animate-spin text-amber-300" />
              )}
              <span className="truncate text-slate-300">
                {world.activeJob
                  ? `${world.activeJob.repoName} · ${world.activeJob.statusMessage}`
                  : `${world.generatedFiles.length} export files ready for 1-Commit GitHub APK or Local ZIP`}
              </span>
            </div>

            <div className="flex flex-wrap items-center gap-1.5 shrink-0">
              {world.releaseLinks && isSafeHttps(world.releaseLinks.apkDownloadUrl) && (
                <a
                  href={world.releaseLinks.apkDownloadUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex h-8 items-center gap-1 rounded-lg bg-emerald-500 px-2.5 text-[11px] font-semibold text-slate-950 hover:bg-emerald-400 whitespace-nowrap"
                >
                  <Download className="h-3 w-3" />
                  <span>Public APK</span>
                </a>
              )}
              {world.releaseLinks && isSafeHttps(world.releaseLinks.liveTestUrl) && (
                <a
                  href={world.releaseLinks.liveTestUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex h-8 items-center gap-1 rounded-lg border border-cyan-400/40 bg-cyan-500/15 px-2.5 text-[11px] font-medium text-cyan-100 hover:bg-cyan-500/25 whitespace-nowrap"
                >
                  <ExternalLink className="h-3 w-3" />
                  <span>Live Web Test</span>
                </a>
              )}
              {world.releaseLinks && isSafeHttps(world.releaseLinks.adminPanelUrl) && (
                <a
                  href={world.releaseLinks.adminPanelUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex h-8 items-center gap-1 rounded-lg border border-violet-400/40 bg-violet-500/18 px-2.5 text-[11px] font-medium text-violet-100 hover:bg-violet-500/28 whitespace-nowrap"
                >
                  <Lock className="h-3 w-3" />
                  <span>Owner Admin</span>
                </a>
              )}

              <button
                type="button"
                disabled={pushingApk}
                onClick={async () => {
                  setPushingApk(true);
                  try {
                    await onPublishGitHubApk();
                  } finally {
                    setPushingApk(false);
                  }
                }}
                className="inline-flex h-8 items-center gap-1 rounded-lg border border-emerald-400/40 bg-emerald-500/15 px-2.5 text-[11px] font-semibold text-emerald-200 hover:bg-emerald-500/25 disabled:opacity-50 whitespace-nowrap cursor-pointer"
              >
                {pushingApk ? (
                  <Loader2 className="h-3 w-3 animate-spin" />
                ) : (
                  <GitBranch className="h-3 w-3" />
                )}
                <span>Push APK</span>
              </button>

              <button
                type="button"
                disabled={downloadingZip}
                onClick={async () => {
                  setDownloadingZip(true);
                  try {
                    await onDownloadZip();
                  } finally {
                    setDownloadingZip(false);
                  }
                }}
                className="inline-flex h-8 items-center gap-1 rounded-lg border border-white/15 bg-white/[0.05] px-2.5 text-[11px] font-medium text-slate-200 hover:border-cyan-400/45 whitespace-nowrap cursor-pointer"
              >
                {downloadingZip ? (
                  <Loader2 className="h-3 w-3 animate-spin" />
                ) : (
                  <FolderArchive className="h-3 w-3" />
                )}
                <span>ZIP</span>
              </button>
            </div>
          </div>
        )}

        {/* Main Display A Body */}
        <div className={`relative flex-1 ${isFullscreen ? 'min-h-0 flex flex-col' : 'min-h-[175px]'}`}>
          {resolvedView === 'assets' && (
            <AssetPickerView
              candidates={world.candidateAssets}
              assetsConfirmed={world.assetsConfirmed}
              isHunting={isHuntingAssets}
              onKeepToggle={onKeepAsset}
              onRejectReplace={onRejectAsset}
              onHuntMore={onHuntAssets}
              onConfirmSelected={onConfirmAssets}
            />
          )}

          {resolvedView === 'media' && latestMedia && (
            <div className="flex h-full flex-col p-3 sm:p-4 gap-3">
              <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                <div className="min-w-0">
                  <span className="font-semibold text-violet-200">
                    {latestMedia.kind === 'cutscene'
                      ? 'Interactive 3D Cut-Scene'
                      : 'Gemini Generated Image'}
                  </span>
                  <span className="mx-1.5 text-slate-600" aria-hidden="true">·</span>
                  <span className="font-mono text-slate-400">{latestMedia.modelUsed}</span>
                </div>
                <span className="text-slate-400 truncate max-w-md">{latestMedia.prompt}</span>
              </div>

              {latestMedia.note && (
                <div className="rounded-lg border border-amber-400/30 bg-amber-500/10 px-3 py-2 text-xs text-amber-200">
                  {latestMedia.note}
                </div>
              )}

              {latestMedia.kind === 'image' && latestMedia.dataUrl ? (
                <div className="flex flex-1 items-center justify-center rounded-xl border border-white/10 bg-[#040711] p-2 overflow-hidden">
                  <img
                    src={latestMedia.dataUrl}
                    alt={latestMedia.prompt}
                    referrerPolicy="no-referrer"
                    className="max-h-[300px] w-auto rounded-lg object-contain"
                  />
                </div>
              ) : latestMedia.cutsceneHtml ? (
                <iframe
                  title="Interactive Animated 3D Cut-Scene"
                  sandbox="allow-scripts"
                  srcDoc={latestMedia.cutsceneHtml}
                  className={`w-full flex-1 rounded-xl border border-violet-400/25 bg-[#040711] ${
                    isFullscreen ? 'h-full' : 'min-h-[260px]'
                  }`}
                />
              ) : null}
            </div>
          )}

          {resolvedView === 'codegen' && world.codeGenProgress && (
            <div className="flex h-full flex-col justify-center px-5 py-6 sm:px-8">
              <div className="mx-auto w-full max-w-2xl space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    {world.paused ? (
                      <PauseCircle className="h-4 w-4 text-amber-400" />
                    ) : (
                      <Loader2 className="h-4 w-4 animate-spin text-cyan-400" />
                    )}
                    <h3 className="font-display text-sm sm:text-base font-semibold text-slate-100">
                      {world.paused
                        ? 'Code Generation Paused'
                        : '5-Stage Live Code Generator Active'}
                    </h3>
                  </div>
                  <span className="font-mono text-xs text-slate-400 tabular-nums">
                    Stage {world.codeGenProgress.stage}/5 · {world.selectedAssets.length} verified assets · {world.selectedEngine}
                  </span>
                </div>

                <div className="space-y-2">
                  {CODEGEN_STAGES.map((item) => {
                    const isDone = world.codeGenProgress?.completedStages.includes(item.stage);
                    const isActive = world.codeGenProgress?.stage === item.stage && !isDone;
                    return (
                      <div
                        key={item.stage}
                        className={`flex items-center justify-between gap-3 rounded-xl border px-3.5 py-2.5 text-xs transition-colors ${
                          isDone
                            ? 'border-emerald-400/25 bg-emerald-500/[0.07] text-emerald-200'
                            : isActive
                            ? world.paused
                              ? 'border-amber-400/35 bg-amber-500/10 text-amber-100'
                              : 'border-cyan-400/40 bg-cyan-500/10 text-cyan-100'
                            : 'border-white/[0.06] bg-[#0B1225]/70 text-slate-500'
                        }`}
                      >
                        <div className="flex items-center gap-2.5 min-w-0">
                          <span className="font-mono tabular-nums text-[11px] opacity-80">
                            0{item.stage}
                          </span>
                          <span className="font-medium truncate">{item.title}</span>
                        </div>
                        <div className="shrink-0">
                          {isDone ? (
                            <Check className="h-4 w-4 text-emerald-400" />
                          ) : isActive ? (
                            world.paused ? (
                              <PauseCircle className="h-4 w-4 text-amber-300" />
                            ) : (
                              <Loader2 className="h-4 w-4 animate-spin text-cyan-300" />
                            )
                          ) : (
                            <span className="font-mono text-[10px] text-slate-600">Queued</span>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>

                <p className="text-xs text-slate-300 leading-relaxed">
                  {world.codeGenProgress.detail}
                </p>
              </div>
            </div>
          )}

          {resolvedView === 'preview' && world.previewHtml && (
            <div className={`relative flex w-full flex-col ${isFullscreen ? 'flex-1 min-h-0' : ''}`}>
              {world.codeGenProgress && (
                <div className="flex flex-wrap items-center justify-between gap-2 border-b border-cyan-400/30 bg-cyan-950/60 px-3.5 py-2 text-xs text-cyan-100">
                  <div className="flex items-center gap-2 min-w-0">
                    {world.paused ? (
                      <PauseCircle className="h-3.5 w-3.5 shrink-0 text-amber-300" />
                    ) : (
                      <Loader2 className="h-3.5 w-3.5 shrink-0 animate-spin text-cyan-300" />
                    )}
                    <span className="font-semibold whitespace-nowrap tabular-nums">
                      Stage {world.codeGenProgress.stage}/5
                    </span>
                    <span className="text-cyan-400/60" aria-hidden="true">·</span>
                    <span className="truncate">{world.codeGenProgress.detail}</span>
                  </div>
                </div>
              )}

              <LivePreviewFrame
                previewHtml={world.previewHtml}
                isFullscreen={isFullscreen}
                runtimeErrors={world.runtimeErrors}
                fileCount={world.generatedFiles.length}
                assetCount={world.selectedAssets.length}
                engine={world.selectedEngine}
                checkpointCount={world.checkpoints.length}
                onRuntimeError={onRuntimeError}
                onPreviewReady={onPreviewReady}
                onClearErrors={onClearErrors}
                onHotPatch={onHotPatch}
                onOpenCode={onOpenCode}
                onOpenCheckpoints={onOpenCheckpoints}
              />
            </div>
          )}

          {resolvedView === 'welcome' && (
            <div className="flex h-full flex-col items-center justify-center px-5 py-6 text-center">
              <div className="mb-2.5 flex items-center gap-2 text-xs font-medium text-cyan-300">
                <Sparkles className="h-3.5 w-3.5 text-violet-400" />
                <span>
                  {world.language === 'hi'
                    ? 'ज़ीरो-सर्वर ऑटोनॉमस वर्कस्पेस और एसेट हंटर तैयार है'
                    : 'Zero-Server Autonomous Workspace & Asset Hunter Ready'}
                </span>
              </div>
              <h2 className="font-display text-lg sm:text-xl font-semibold text-slate-100 max-w-xl [text-wrap:balance]">
                {world.language === 'hi'
                  ? 'बोलें या कमांड लिखें — जार्विस पहले 3D/वेब एसेट्स लाएगा और फिर APK बनाएगा'
                  : 'Command JARVIS to hunt 3D & web assets, inspect via Camera Eye, and build your APK'}
              </h2>
              <p className="mt-1.5 max-w-lg text-xs sm:text-sm text-slate-400 leading-relaxed">
                {world.language === 'hi'
                  ? 'Display A में ✓ Keep / ✕ Reject एसेट पिकर, जेमिनी इमेज प्रीव्यू और लाइव सैंडबॉक्स चलेगा।'
                  : 'Display A hosts the interactive ✓ Keep / ✕ Reject Asset Picker, Gemini Image & Cut-Scene previews, and live build output.'}
              </p>

              <div className="mt-4 flex flex-wrap items-center justify-center gap-2">
                {STARTER_BLUEPRINTS.map((bp) => (
                  <button
                    key={bp}
                    type="button"
                    onClick={() => onQuickPrompt(bp)}
                    className="rounded-lg border border-white/10 bg-[#0D162C]/80 px-3 py-1.5 text-xs text-slate-300 hover:border-cyan-400/45 hover:text-cyan-100 transition-colors cursor-pointer"
                  >
                    {bp}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
