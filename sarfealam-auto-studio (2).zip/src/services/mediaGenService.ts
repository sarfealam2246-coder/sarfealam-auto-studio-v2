import { studioBus } from './eventBus';
import type { EngineType, GeneratedMediaItem } from '../types/studio';

export interface ImageGenResult {
  ok: boolean;
  httpStatus: number;
  media?: GeneratedMediaItem;
  error?: string;
}

/**
 * Generates custom banners, logos, or textures via Gemini Image API:
 * 1) gemini-2.5-flash-image (generateContent with responseModalities: ["IMAGE", "TEXT"])
 * 2) Automatic fallback to imagen-3.0-generate-002 (predict endpoint)
 */
export async function generateImageWithGemini(
  prompt: string,
  geminiApiKey: string
): Promise<ImageGenResult> {
  const key = geminiApiKey.trim();
  if (!key) {
    return {
      ok: false,
      httpStatus: 0,
      error: 'Save a Gemini API key (AIza...) in the Secrets panel to generate images with Gemini.',
    };
  }

  studioBus.emit('bot:progress', {
    botId: 'asset-hunter',
    status: 'active',
    task: 'Generating image via Gemini',
    progress: 40,
  });

  // Primary: gemini-2.5-flash-image
  try {
    const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-image:generateContent?key=${encodeURIComponent(key)}`;
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{ role: 'user', parts: [{ text: prompt }] }],
        generationConfig: {
          responseModalities: ['IMAGE', 'TEXT'],
        },
      }),
    });

    if (res.ok) {
      const data = await res.json();
      const parts = data?.candidates?.[0]?.content?.parts ?? [];
      for (const part of parts) {
        const inline = part.inlineData || part.inline_data;
        if (inline?.data) {
          const mime = inline.mimeType || inline.mime_type || 'image/png';
          const dataUrl = `data:${mime};base64,${inline.data}`;
          const media: GeneratedMediaItem = {
            id: `img_${Date.now()}`,
            kind: 'image',
            prompt,
            dataUrl,
            modelUsed: 'gemini-2.5-flash-image',
            timestamp: Date.now(),
          };
          studioBus.emit('bot:progress', {
            botId: 'asset-hunter',
            status: 'done',
            task: 'Gemini image generated',
            progress: 100,
          });
          return { ok: true, httpStatus: res.status, media };
        }
      }
    }

    // Fallback: imagen-3.0-generate-002
    studioBus.emit('bot:progress', {
      botId: 'asset-hunter',
      status: 'active',
      task: 'Trying Imagen 3.0 endpoint',
      progress: 72,
    });

    const imagenUrl = `https://generativelanguage.googleapis.com/v1beta/models/imagen-3.0-generate-002:predict?key=${encodeURIComponent(key)}`;
    const imagenRes = await fetch(imagenUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        instances: [{ prompt }],
        parameters: { sampleCount: 1 },
      }),
    });

    if (imagenRes.ok) {
      const imgData = await imagenRes.json();
      const pred = imgData?.predictions?.[0];
      const b64 = pred?.bytesBase64Encoded;
      if (typeof b64 === 'string' && b64.length > 0) {
        const mime = pred?.mimeType || 'image/png';
        const media: GeneratedMediaItem = {
          id: `img_${Date.now()}`,
          kind: 'image',
          prompt,
          dataUrl: `data:${mime};base64,${b64}`,
          modelUsed: 'imagen-3.0-generate-002',
          timestamp: Date.now(),
        };
        studioBus.emit('bot:progress', {
          botId: 'asset-hunter',
          status: 'done',
          task: 'Imagen 3.0 asset ready',
          progress: 100,
        });
        return { ok: true, httpStatus: imagenRes.status, media };
      }
    }

    const errText = await imagenRes.text().catch(() => '');
    studioBus.emit('bot:progress', {
      botId: 'asset-hunter',
      status: 'error',
      task: `Image Gen HTTP ${imagenRes.status}`,
      progress: 0,
    });
    return {
      ok: false,
      httpStatus: imagenRes.status,
      error: `Image generation failed (HTTP ${imagenRes.status}): ${errText.slice(0, 150) || imagenRes.statusText}`,
    };
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'Network error during Gemini image generation';
    studioBus.emit('bot:progress', {
      botId: 'asset-hunter',
      status: 'error',
      task: 'Image gen error',
      progress: 0,
    });
    return { ok: false, httpStatus: 0, error: msg };
  }
}

/**
 * Honest Animated Cut-Scene Fallback:
 * When cloud video generation is requested and unavailable on the saved API key,
 * generates a real-time interactive HTML5 3D-projection animated cut-scene so the studio workflow never blocks.
 */
export function buildInteractiveCutsceneFallback(
  prompt: string,
  engine: EngineType
): GeneratedMediaItem {
  const safeTitle = prompt.replace(/</g, '&lt;').replace(/>/g, '&gt;').slice(0, 90);
  const cutsceneHtml = `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1" />
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body {
    background: #040711;
    color: #e2e8f0;
    font-family: system-ui, -apple-system, sans-serif;
    height: 100vh;
    display: flex;
    flex-direction: column;
    overflow: hidden;
  }
  .stage { position: relative; flex: 1; width: 100%; overflow: hidden; }
  canvas { width: 100%; height: 100%; display: block; }
  .hud {
    position: absolute; inset: 12px 14px auto 14px;
    display: flex; justify-content: space-between; align-items: center;
    pointer-events: none;
  }
  .title { font-size: 13px; font-weight: 600; color: #e0f2fe; text-shadow: 0 2px 10px #000; }
  .sub { font-size: 11px; color: #94a3b8; font-family: ui-monospace, monospace; }
  .controls {
    display: flex; align-items: center; gap: 10px;
    padding: 8px 14px; background: rgba(7, 12, 26, 0.95);
    border-top: 1px solid rgba(56, 189, 248, 0.22);
  }
  button {
    padding: 6px 12px; border-radius: 8px;
    border: 1px solid rgba(56, 189, 248, 0.35);
    background: rgba(14, 165, 233, 0.16);
    color: #e0f2fe; font-size: 11px; font-weight: 600; cursor: pointer;
  }
  button:hover { background: rgba(14, 165, 233, 0.3); }
  input[type="range"] { flex: 1; accent-color: #22d3ee; }
</style>
</head>
<body>
  <div class="stage">
    <canvas id="scene"></canvas>
    <div class="hud">
      <div>
        <div class="title">${safeTitle}</div>
        <div class="sub">${engine} · Interactive 3D Cut-Scene Engine</div>
      </div>
      <div class="sub" id="clock">00:00.0</div>
    </div>
  </div>
  <div class="controls">
    <button id="playBtn">Pause</button>
    <button id="camBtn">Camera: Orbit</button>
    <input id="scrub" type="range" min="0" max="1000" value="0" />
  </div>
  <script>
    const canvas = document.getElementById('scene');
    const ctx = canvas.getContext('2d');
    const playBtn = document.getElementById('playBtn');
    const camBtn = document.getElementById('camBtn');
    const scrub = document.getElementById('scrub');
    const clock = document.getElementById('clock');
    let playing = true, camMode = 0, progress = 0;
    const camLabels = ['Orbit', 'Dolly', 'Aerial'];

    function resize() {
      canvas.width = canvas.clientWidth * Math.min(2, window.devicePixelRatio || 1);
      canvas.height = canvas.clientHeight * Math.min(2, window.devicePixelRatio || 1);
    }
    window.addEventListener('resize', resize);
    resize();

    playBtn.onclick = () => { playing = !playing; playBtn.textContent = playing ? 'Pause' : 'Play'; };
    camBtn.onclick = () => { camMode = (camMode + 1) % 3; camBtn.textContent = 'Camera: ' + camLabels[camMode]; };
    scrub.oninput = () => { progress = Number(scrub.value) / 1000; };

    const stars = Array.from({ length: 70 }, (_, i) => ({
      x: ((i * 97) % 100) / 100,
      y: ((i * 53) % 55) / 100,
      r: 0.8 + (i % 3) * 0.6
    }));

    function project(x, y, z, w, h, fov) {
      const dz = z + 5.2;
      if (dz <= 0.2) return null;
      const scale = fov / dz;
      return { x: w * 0.5 + x * scale, y: h * 0.56 - y * scale, s: scale };
    }

    function render() {
      if (playing) {
        progress = (progress + 0.0022) % 1;
        scrub.value = Math.round(progress * 1000);
      }
      const t = progress * Math.PI * 2;
      const sec = progress * 12;
      clock.textContent = '00:' + String(Math.floor(sec)).padStart(2, '0') + '.' + Math.floor((sec % 1) * 10);

      const w = canvas.width, h = canvas.height;
      const sky = ctx.createLinearGradient(0, 0, 0, h);
      sky.addColorStop(0, '#040814');
      sky.addColorStop(0.55, '#0c1530');
      sky.addColorStop(1, '#070b18');
      ctx.fillStyle = sky;
      ctx.fillRect(0, 0, w, h);

      // Stars
      ctx.fillStyle = 'rgba(186, 230, 253, 0.65)';
      for (const s of stars) {
        ctx.beginPath();
        ctx.arc(s.x * w, s.y * h, s.r, 0, Math.PI * 2);
        ctx.fill();
      }

      // 3D Terrain Grid
      const yaw = camMode === 0 ? Math.sin(t) * 0.6 : camMode === 1 ? 0 : t * 0.5;
      const fov = Math.min(w, h) * 0.85;
      ctx.strokeStyle = 'rgba(34, 211, 238, 0.25)';
      ctx.lineWidth = 1.2;

      for (let gz = -4; gz <= 8; gz++) {
        ctx.beginPath();
        let started = false;
        for (let gx = -6; gx <= 6; gx++) {
          const zShift = ((gz - progress * 6) % 12 + 12) % 12 - 3;
          const elev = Math.sin(gx * 0.7 + t) * 0.28 + Math.cos(zShift * 0.6) * 0.22 - 1.1;
          const rx = gx * Math.cos(yaw) - zShift * Math.sin(yaw);
          const rz = gx * Math.sin(yaw) + zShift * Math.cos(yaw);
          const p = project(rx, elev, rz, w, h, fov);
          if (!p) continue;
          if (!started) { ctx.moveTo(p.x, p.y); started = true; }
          else ctx.lineTo(p.x, p.y);
        }
        ctx.stroke();
      }

      // Rotating wireframe centerpiece prism
      const verts = [
        [0, 1.05, 0], [-0.9, -0.3, -0.9], [0.9, -0.3, -0.9], [0.9, -0.3, 0.9], [-0.9, -0.3, 0.9], [0, -1.0, 0]
      ];
      const edges = [[0,1],[0,2],[0,3],[0,4],[1,2],[2,3],[3,4],[4,1],[5,1],[5,2],[5,3],[5,4]];
      const projVerts = verts.map(([vx, vy, vz]) => {
        const ang = t * 1.4;
        const rx = vx * Math.cos(ang) - vz * Math.sin(ang);
        const rz = vx * Math.sin(ang) + vz * Math.cos(ang);
        const bob = Math.sin(t * 2) * 0.16 + (camMode === 2 ? -0.35 : 0.15);
        return project(rx, vy + bob, rz + (camMode === 1 ? Math.sin(t) * 1.4 : 0), w, h, fov);
      });

      ctx.strokeStyle = '#a78bfa';
      ctx.lineWidth = 2.2;
      for (const [a, b] of edges) {
        const pa = projVerts[a], pb = projVerts[b];
        if (!pa || !pb) continue;
        ctx.beginPath();
        ctx.moveTo(pa.x, pa.y);
        ctx.lineTo(pb.x, pb.y);
        ctx.stroke();
      }

      requestAnimationFrame(render);
    }
    render();
  </script>
</body>
</html>`;

  return {
    id: `cutscene_${Date.now()}`,
    kind: 'cutscene',
    prompt,
    cutsceneHtml,
    modelUsed: 'Interactive HTML5 3D Cut-Scene',
    note: 'Direct video generation API is unavailable on this Gemini key — generated an interactive real-time 3D animated cut-scene instead so your workflow stays unblocked.',
    timestamp: Date.now(),
  };
}
