import { studioBus } from './eventBus';
import {
  loadDynamicSkills,
  saveDynamicSkills,
  syncDynamicSkillToStudioSupabase,
} from './storageService';
import type {
  AssetCategory,
  AssetFormat,
  DynamicSkill,
  PolyHavenResolvedMaps,
  StudioAssetItem,
  SupabaseEndpointConfig,
} from '../types/studio';

export const VAULT_CATEGORIES: AssetCategory[] = [
  'vehicles',
  'characters',
  'weapons_gear',
  'village_world',
  'textures_pbr',
  'hdri_sky',
  'audio_sfx',
  'app_audio',
];

interface RawCatalogEntry {
  id?: string;
  name?: string;
  title?: string;
  category?: string;
  source?: string;
  rawUrl?: string;
  url?: string;
  downloadUrl?: string;
  thumbUrl?: string;
  thumbnail?: string;
  previewUrl?: string;
  apiFilesUrl?: string;
  tags?: string[] | string;
  format?: string;
  file?: string;
  path?: string;
}

interface CatalogCacheEntry {
  repo: string;
  items: StudioAssetItem[];
  fetchedAt: number;
  httpStatus: number;
  rawUrl: string;
}

let catalogCache: CatalogCacheEntry | null = null;
const polyHavenCache = new Map<string, PolyHavenResolvedMaps>();

function cleanRepoSlug(assetVaultRepo: string): string {
  return (
    assetVaultRepo
      .trim()
      .replace(/^https?:\/\/github\.com\//i, '')
      .replace(/\/+$/, '') || 'sarfealam2246-coder/sarfealam-3d-assets'
  );
}

function inferFormat(category: AssetCategory, url: string, explicit?: string): AssetFormat {
  const lower = (explicit || url || '').toLowerCase();
  if (category === 'audio_sfx' || category === 'app_audio' || /\.(wav|mp3|ogg|m4a)(\?|$)/.test(lower)) {
    return 'audio';
  }
  if (category === 'hdri_sky' || /\.hdr(\?|$)/.test(lower)) {
    return 'hdr';
  }
  if (category === 'textures_pbr') {
    return 'pbr';
  }
  if (category === 'vector_icon' || /\.svg(\?|$)/.test(lower)) {
    return 'svg';
  }
  if (category === 'web_photo' || category === 'generated_image' || /\.(jpg|jpeg|png|webp)(\?|$)/.test(lower)) {
    return 'image';
  }
  return 'glb';
}

function normalizeCategory(rawCat: string | undefined, fallback: AssetCategory): AssetCategory {
  if (!rawCat) return fallback;
  const cleaned = rawCat.trim().toLowerCase().replace(/[\s-]+/g, '_');
  if ((VAULT_CATEGORIES as string[]).includes(cleaned)) {
    return cleaned as AssetCategory;
  }
  if (cleaned.includes('vehicle') || cleaned.includes('car') || cleaned.includes('truck')) return 'vehicles';
  if (cleaned.includes('char') || cleaned.includes('soldier') || cleaned.includes('human')) return 'characters';
  if (cleaned.includes('weapon') || cleaned.includes('gear') || cleaned.includes('gun')) return 'weapons_gear';
  if (cleaned.includes('village') || cleaned.includes('world') || cleaned.includes('env') || cleaned.includes('prop')) {
    return 'village_world';
  }
  if (cleaned.includes('pbr') || cleaned.includes('texture') || cleaned.includes('material')) return 'textures_pbr';
  if (cleaned.includes('hdri') || cleaned.includes('sky')) return 'hdri_sky';
  if (cleaned.includes('app_audio') || cleaned.includes('ui_sound') || cleaned.includes('tone')) return 'app_audio';
  if (cleaned.includes('audio') || cleaned.includes('sfx') || cleaned.includes('sound')) return 'audio_sfx';
  return fallback;
}

function resolveRelativeRawUrl(urlOrPath: string, repoSlug: string): string {
  const trimmed = urlOrPath.trim();
  if (!trimmed) return '';
  if (/^https?:\/\//i.test(trimmed)) return trimmed;
  const cleanPath = trimmed.replace(/^\/+/, '');
  return `https://raw.githubusercontent.com/${repoSlug}/main/${cleanPath}`;
}

function parseRawEntry(
  entry: RawCatalogEntry,
  categoryHint: AssetCategory,
  repoSlug: string,
  index: number
): StudioAssetItem | null {
  const category = normalizeCategory(entry.category, categoryHint);
  const rawCandidate = entry.rawUrl || entry.downloadUrl || entry.url || entry.file || entry.path || '';
  const rawUrl = resolveRelativeRawUrl(rawCandidate, repoSlug);
  const apiFilesUrl = entry.apiFilesUrl?.trim() || undefined;

  if (!rawUrl && !apiFilesUrl) return null;

  const name = (entry.name || entry.title || entry.id || `${category}_${index + 1}`)
    .toString()
    .replace(/[_-]+/g, ' ')
    .trim();

  const thumbCandidate = entry.thumbUrl || entry.thumbnail || entry.previewUrl || '';
  const thumbUrl = thumbCandidate ? resolveRelativeRawUrl(thumbCandidate, repoSlug) : undefined;

  const tags = Array.isArray(entry.tags)
    ? entry.tags.map((t) => String(t).toLowerCase())
    : typeof entry.tags === 'string'
    ? entry.tags
        .split(/[,\s]+/)
        .map((t) => t.trim().toLowerCase())
        .filter(Boolean)
    : [];

  // Add tokens from name & category for fast search matching
  const derivedTags = Array.from(
    new Set([
      ...tags,
      category,
      ...name.toLowerCase().split(/\s+/).filter((w) => w.length > 1),
    ])
  );

  const id =
    entry.id?.toString().trim() ||
    `vault_${category}_${name.toLowerCase().replace(/[^a-z0-9]+/g, '_')}_${index}`;

  return {
    id,
    name,
    category,
    source: entry.source || (apiFilesUrl?.includes('polyhaven') ? 'PolyHaven' : 'Asset Vault'),
    rawUrl: rawUrl || apiFilesUrl || '',
    thumbUrl,
    apiFilesUrl,
    format: inferFormat(category, rawUrl || apiFilesUrl || '', entry.format),
    tags: derivedTags,
    status: 'candidate',
  };
}

/**
 * Fetches & parses catalog.json directly from:
 * https://raw.githubusercontent.com/${assetVaultRepo}/main/catalog.json
 */
export async function fetchVaultCatalog(
  assetVaultRepo: string,
  forceRefresh = false
): Promise<{
  ok: boolean;
  httpStatus: number;
  items: StudioAssetItem[];
  catalogUrl: string;
  message: string;
}> {
  const repoSlug = cleanRepoSlug(assetVaultRepo);
  const catalogUrl = `https://raw.githubusercontent.com/${repoSlug}/main/catalog.json`;

  if (
    !forceRefresh &&
    catalogCache &&
    catalogCache.repo === repoSlug &&
    Date.now() - catalogCache.fetchedAt < 180_000
  ) {
    return {
      ok: true,
      httpStatus: catalogCache.httpStatus,
      items: catalogCache.items,
      catalogUrl,
      message: `Loaded ${catalogCache.items.length} catalog assets (cached).`,
    };
  }

  studioBus.emit('bot:progress', {
    botId: 'asset-hunter',
    status: 'active',
    task: `Fetching catalog.json from ${repoSlug}`,
    progress: 22,
  });

  try {
    const res = await fetch(catalogUrl, {
      method: 'GET',
      headers: { Accept: 'application/json' },
    });

    if (!res.ok) {
      studioBus.emit('bot:progress', {
        botId: 'asset-hunter',
        status: 'error',
        task: `Catalog HTTP ${res.status}`,
        progress: 0,
      });
      return {
        ok: false,
        httpStatus: res.status,
        items: [],
        catalogUrl,
        message: `Could not fetch catalog.json (HTTP ${res.status}). Verify repo "${repoSlug}" has main/catalog.json.`,
      };
    }

    const data = await res.json();
    const parsedItems: StudioAssetItem[] = [];

    // Support multiple catalog.json schemas cleanly:
    // Schema A: { categories: { vehicles: [...], characters: [...], ... } }
    // Schema B: { vehicles: [...], textures_pbr: [...], ... }
    // Schema C: { assets: [...] } or top-level array [...]
    const rootBuckets =
      data && typeof data === 'object' && !Array.isArray(data)
        ? (data.categories && typeof data.categories === 'object' ? data.categories : data)
        : null;

    if (Array.isArray(data)) {
      data.forEach((entry: RawCatalogEntry, idx: number) => {
        const parsed = parseRawEntry(entry, 'village_world', repoSlug, idx);
        if (parsed) parsedItems.push(parsed);
      });
    } else if (rootBuckets) {
      if (Array.isArray(rootBuckets.assets)) {
        rootBuckets.assets.forEach((entry: RawCatalogEntry, idx: number) => {
          const parsed = parseRawEntry(entry, 'village_world', repoSlug, idx);
          if (parsed) parsedItems.push(parsed);
        });
      }
      if (Array.isArray(rootBuckets.items)) {
        rootBuckets.items.forEach((entry: RawCatalogEntry, idx: number) => {
          const parsed = parseRawEntry(entry, 'village_world', repoSlug, idx);
          if (parsed) parsedItems.push(parsed);
        });
      }

      for (const [key, val] of Object.entries(rootBuckets)) {
        if (!Array.isArray(val) || key === 'assets' || key === 'items') continue;
        const catHint = normalizeCategory(key, 'village_world');
        (val as RawCatalogEntry[]).forEach((entry, idx) => {
          const parsed = parseRawEntry(entry, catHint, repoSlug, idx);
          if (parsed) parsedItems.push(parsed);
        });
      }
    }

    // Deduplicate by id
    const seen = new Set<string>();
    const uniqueItems = parsedItems.filter((item) => {
      if (seen.has(item.id)) return false;
      seen.add(item.id);
      return true;
    });

    catalogCache = {
      repo: repoSlug,
      items: uniqueItems,
      fetchedAt: Date.now(),
      httpStatus: res.status,
      rawUrl: catalogUrl,
    };

    studioBus.emit('bot:progress', {
      botId: 'asset-hunter',
      status: 'active',
      task: `Indexed ${uniqueItems.length} vault assets`,
      progress: 48,
    });

    return {
      ok: true,
      httpStatus: res.status,
      items: uniqueItems,
      catalogUrl,
      message: `Indexed ${uniqueItems.length} assets across vault categories.`,
    };
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'Network error loading catalog.json';
    studioBus.emit('bot:progress', {
      botId: 'asset-hunter',
      status: 'error',
      task: 'Catalog fetch error',
      progress: 0,
    });
    return {
      ok: false,
      httpStatus: 0,
      items: [],
      catalogUrl,
      message: msg,
    };
  }
}

/**
 * Resolves real .jpg Diffuse/Normal/Roughness URLs and .hdr 1k URLs on demand
 * from https://api.polyhaven.com/files/{id}
 */
export async function resolvePolyHavenAsset(item: StudioAssetItem): Promise<StudioAssetItem> {
  if (!item.apiFilesUrl) return item;
  if (item.pbrMaps && (item.pbrMaps.diffuse || item.pbrMaps.hdr1k)) return item;

  const cached = polyHavenCache.get(item.apiFilesUrl);
  if (cached) {
    return {
      ...item,
      pbrMaps: cached,
      rawUrl: cached.hdr1k || cached.diffuse || item.rawUrl,
      thumbUrl: item.thumbUrl || cached.diffuse,
    };
  }

  try {
    const res = await fetch(item.apiFilesUrl, {
      method: 'GET',
      headers: { Accept: 'application/json' },
    });
    if (!res.ok) return item;
    const data = await res.json();

    const maps: PolyHavenResolvedMaps = { resolvedAt: Date.now() };

    // Resolve HDRI 1k .hdr
    const hdr1k =
      data?.hdri?.['1k']?.hdr?.url ||
      data?.hdri?.['2k']?.hdr?.url ||
      data?.hdri?.['1k']?.exr?.url;
    if (typeof hdr1k === 'string') {
      maps.hdr1k = hdr1k;
    }

    // Resolve PBR Diffuse / Normal / Roughness 1k .jpg
    const diffuse =
      data?.Diffuse?.['1k']?.jpg?.url ||
      data?.diff?.['1k']?.jpg?.url ||
      data?.albedo?.['1k']?.jpg?.url ||
      data?.Diffuse?.['2k']?.jpg?.url;
    const normal =
      data?.nor_gl?.['1k']?.jpg?.url ||
      data?.nor_dx?.['1k']?.jpg?.url ||
      data?.Normal?.['1k']?.jpg?.url;
    const roughness =
      data?.Rough?.['1k']?.jpg?.url ||
      data?.roughness?.['1k']?.jpg?.url ||
      data?.arm?.['1k']?.jpg?.url;

    if (typeof diffuse === 'string') maps.diffuse = diffuse;
    if (typeof normal === 'string') maps.normal = normal;
    if (typeof roughness === 'string') maps.roughness = roughness;

    polyHavenCache.set(item.apiFilesUrl, maps);

    const resolvedRawUrl =
      item.category === 'hdri_sky'
        ? maps.hdr1k || item.rawUrl
        : maps.diffuse || maps.hdr1k || item.rawUrl;

    const tonemappedThumb =
      typeof data?.tonemapped?.url === 'string' ? data.tonemapped.url : undefined;

    return {
      ...item,
      pbrMaps: maps,
      rawUrl: resolvedRawUrl,
      thumbUrl: item.thumbUrl || tonemappedThumb || maps.diffuse,
    };
  } catch {
    return item;
  }
}

/**
 * Live Wikimedia Commons API fetcher for real-world photos in commercial apps
 */
export async function searchWikimediaPhotos(
  query: string,
  limit = 6
): Promise<StudioAssetItem[]> {
  const cleanQuery = query.trim();
  if (!cleanQuery) return [];

  const endpoint =
    `https://commons.wikimedia.org/w/api.php?action=query&generator=search&gsrnamespace=6` +
    `&prop=imageinfo&iiprop=url|mime&format=json&origin=*` +
    `&gsrlimit=${Math.min(12, Math.max(3, limit * 2))}&gsrsearch=${encodeURIComponent(cleanQuery)}`;

  try {
    const res = await fetch(endpoint, { method: 'GET' });
    if (!res.ok) return [];
    const data = await res.json();
    const pages = data?.query?.pages;
    if (!pages || typeof pages !== 'object') return [];

    const results: StudioAssetItem[] = [];
    for (const page of Object.values(pages) as Array<{
      pageid?: number;
      title?: string;
      imageinfo?: Array<{ url?: string; mime?: string }>;
    }>) {
      const info = page.imageinfo?.[0];
      const url = info?.url;
      const mime = (info?.mime || '').toLowerCase();
      if (!url) continue;
      if (!['image/jpeg', 'image/png', 'image/webp'].includes(mime)) continue;

      const cleanTitle = (page.title || 'Wikimedia Photo')
        .replace(/^File:/i, '')
        .replace(/\.[a-z0-9]+$/i, '')
        .replace(/[_-]+/g, ' ')
        .slice(0, 48)
        .trim();

      results.push({
        id: `wiki_${page.pageid || results.length}_${Date.now().toString(36)}`,
        name: cleanTitle || 'Wikimedia Photo',
        category: 'web_photo',
        source: 'Wikimedia Commons',
        rawUrl: url,
        thumbUrl: url,
        format: 'image',
        tags: ['wikimedia', 'photo', ...cleanQuery.toLowerCase().split(/\s+/)],
        status: 'candidate',
      });

      if (results.length >= limit) break;
    }

    return results;
  } catch {
    return [];
  }
}

/**
 * Live Iconify API fetcher for real vector UI icons
 */
export async function searchIconifyIcons(
  query: string,
  limit = 6
): Promise<StudioAssetItem[]> {
  const cleanQuery = query.trim();
  if (!cleanQuery) return [];

  const endpoint = `https://api.iconify.design/search?query=${encodeURIComponent(cleanQuery)}&limit=${limit}`;
  try {
    const res = await fetch(endpoint, { method: 'GET' });
    if (!res.ok) return [];
    const data = await res.json();
    const icons: string[] = Array.isArray(data?.icons) ? data.icons : [];

    return icons.slice(0, limit).map((iconName, idx) => {
      const svgUrl = `https://api.iconify.design/${iconName}.svg?color=%2322d3ee`;
      const label = iconName.split(':')[1] || iconName;
      return {
        id: `iconify_${iconName.replace(/[^a-z0-9]/gi, '_')}_${idx}`,
        name: label.replace(/[-_]+/g, ' '),
        category: 'vector_icon',
        source: 'Iconify Vector',
        rawUrl: svgUrl,
        thumbUrl: svgUrl,
        format: 'svg',
        tags: ['icon', 'svg', iconName.toLowerCase(), ...cleanQuery.toLowerCase().split(/\s+/)],
        status: 'candidate',
      };
    });
  } catch {
    return [];
  }
}

/**
 * Universal Web Connector: fetch_any_api(url) + Dynamic Skill Creator
 * Connects to any open JSON/web endpoint, learns its structure, and persists to localStorage (dynamic_skills)
 * and optionally Studio Supabase.
 */
export async function fetchAnyApiAndLearnSkill(
  url: string,
  options?: {
    skillName?: string;
    description?: string;
    studioSupabase?: SupabaseEndpointConfig;
  }
): Promise<{
  ok: boolean;
  httpStatus: number;
  skill?: DynamicSkill;
  dataPreview: string;
  message: string;
}> {
  const cleanUrl = url.trim();
  if (!/^https?:\/\//i.test(cleanUrl)) {
    return {
      ok: false,
      httpStatus: 0,
      dataPreview: '',
      message: 'URL must start with https:// or http://',
    };
  }

  studioBus.emit('bot:progress', {
    botId: 'asset-hunter',
    status: 'active',
    task: `Connecting ${new URL(cleanUrl).hostname}`,
    progress: 50,
  });

  try {
    const res = await fetch(cleanUrl, {
      method: 'GET',
      headers: { Accept: 'application/json, text/plain, */*' },
    });

    const rawText = await res.text();
    let sampleKeys: string[] = [];
    let previewSnippet = rawText.slice(0, 320);

    try {
      const parsed = JSON.parse(rawText);
      if (Array.isArray(parsed)) {
        sampleKeys =
          parsed[0] && typeof parsed[0] === 'object' ? Object.keys(parsed[0]).slice(0, 10) : ['array'];
      } else if (parsed && typeof parsed === 'object') {
        sampleKeys = Object.keys(parsed).slice(0, 12);
      }
      previewSnippet = JSON.stringify(parsed, null, 2).slice(0, 360);
    } catch {
      sampleKeys = ['text/html'];
    }

    if (!res.ok) {
      studioBus.emit('bot:progress', {
        botId: 'asset-hunter',
        status: 'error',
        task: `API HTTP ${res.status}`,
        progress: 0,
      });
      return {
        ok: false,
        httpStatus: res.status,
        dataPreview: previewSnippet,
        message: `Endpoint responded with HTTP ${res.status}: ${res.statusText}`,
      };
    }

    const hostname = new URL(cleanUrl).hostname.replace(/^www\./, '');
    const skill: DynamicSkill = {
      id: `skill_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      name: options?.skillName?.trim() || `${hostname} Connector`,
      url: cleanUrl,
      description:
        options?.description?.trim() ||
        `Learned JSON/Web API from ${hostname} (${sampleKeys.slice(0, 4).join(', ') || 'data'})`,
      httpStatus: res.status,
      sampleKeys,
      previewSnippet,
      createdAt: Date.now(),
      syncedToSupabase: false,
    };

    if (options?.studioSupabase?.url && options?.studioSupabase?.anonKey) {
      skill.syncedToSupabase = await syncDynamicSkillToStudioSupabase(skill, options.studioSupabase);
    }

    const existing = loadDynamicSkills().filter((s) => s.url !== cleanUrl);
    const updated = [skill, ...existing].slice(0, 40);
    saveDynamicSkills(updated);

    studioBus.emit('bot:progress', {
      botId: 'asset-hunter',
      status: 'done',
      task: `Learned ${skill.name}`,
      progress: 100,
    });

    return {
      ok: true,
      httpStatus: res.status,
      skill,
      dataPreview: previewSnippet,
      message: `Connected (HTTP ${res.status}) and saved dynamic skill "${skill.name}" with fields: ${sampleKeys.join(', ') || 'raw text'}.`,
    };
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'Network error calling endpoint';
    studioBus.emit('bot:progress', {
      botId: 'asset-hunter',
      status: 'error',
      task: 'API connect failed',
      progress: 0,
    });
    return {
      ok: false,
      httpStatus: 0,
      dataPreview: '',
      message: msg,
    };
  }
}

function tokenizeQuery(prompt: string): string[] {
  const stopWords = new Set([
    'build', 'create', 'make', 'generate', 'with', 'for', 'the', 'and', 'app', 'game',
    'studio', 'new', 'using', 'into', 'from', 'that', 'this', 'please', 'find', 'another',
  ]);
  return prompt
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, ' ')
    .split(/\s+/)
    .filter((w) => w.length > 2 && !stopWords.has(w));
}

function scoreAssetRelevance(item: StudioAssetItem, tokens: string[], isGame3D: boolean): number {
  let score = 0;
  const hay = `${item.name} ${item.category} ${item.tags.join(' ')} ${item.source}`.toLowerCase();
  for (const tok of tokens) {
    if (item.name.toLowerCase().includes(tok)) score += 6;
    else if (hay.includes(tok)) score += 3;
  }

  // Domain boost
  if (isGame3D) {
    if (['vehicles', 'characters', 'weapons_gear', 'village_world'].includes(item.category)) score += 2.5;
    if (['textures_pbr', 'hdri_sky', 'audio_sfx'].includes(item.category)) score += 1.5;
  } else {
    if (['app_audio', 'web_photo', 'vector_icon'].includes(item.category)) score += 2.5;
  }
  return score;
}

async function waitIfPaused(isPaused: () => boolean): Promise<void> {
  while (isPaused()) {
    studioBus.emit('bot:progress', {
      botId: 'asset-hunter',
      status: 'paused',
      task: 'Paused · Asset fetch held',
      progress: 50,
    });
    await new Promise((r) => setTimeout(r, 180));
  }
}

export interface AssetHuntResult {
  candidates: StudioAssetItem[];
  backupPool: StudioAssetItem[];
  catalogCount: number;
  wikimediaCount: number;
  iconifyCount: number;
  message: string;
}

/**
 * Full multi-source Asset Hunter used by JARVIS before generating final game/app code.
 * Respects Pause/Resume cleanly between every fetch step!
 */
export async function huntProjectAssets(
  prompt: string,
  mode: 'game_3d' | 'commercial_app' | 'auto',
  assetVaultRepo: string,
  isPaused: () => boolean
): Promise<AssetHuntResult> {
  const lower = prompt.toLowerCase();
  const inferredGame =
    mode === 'game_3d' ||
    (mode === 'auto' &&
      /(3d|game|truck|car|army|soldier|village|shooter|racer|racing|fps|godot|unity|vehicle|weapon|world|sky|forest|tank|driving|simulator)/.test(
        lower
      ));

  const tokens = tokenizeQuery(prompt);
  const searchPhrase = tokens.slice(0, 3).join(' ') || (inferredGame ? 'armored vehicle landscape' : 'modern mobile app');

  await waitIfPaused(isPaused);

  // Step 1: Fetch Asset Vault catalog.json
  const catalogRes = await fetchVaultCatalog(assetVaultRepo, false);
  await waitIfPaused(isPaused);

  // Score and rank vault items across all 8 categories
  const rankedVault = [...catalogRes.items]
    .map((item) => ({ item, score: scoreAssetRelevance(item, tokens, inferredGame) }))
    .sort((a, b) => b.score - a.score)
    .map((x) => x.item);

  // Pick a balanced spread across categories (models, PBR, HDRI, SFX/app audio)
  const picked: StudioAssetItem[] = [];
  const usedIds = new Set<string>();

  const pickCategory = (cats: AssetCategory[], maxCount: number) => {
    let added = 0;
    for (const item of rankedVault) {
      if (added >= maxCount) break;
      if (usedIds.has(item.id)) continue;
      if (cats.includes(item.category)) {
        picked.push({ ...item, status: 'candidate' });
        usedIds.add(item.id);
        added++;
      }
    }
  };

  if (inferredGame) {
    pickCategory(['vehicles', 'characters', 'weapons_gear', 'village_world'], 3);
    pickCategory(['textures_pbr'], 1);
    pickCategory(['hdri_sky'], 1);
    pickCategory(['audio_sfx', 'app_audio'], 2);
  } else {
    pickCategory(['app_audio', 'audio_sfx'], 2);
    pickCategory(['vehicles', 'village_world', 'textures_pbr'], 1);
  }

  // Resolve PolyHaven PBR / HDRI URLs on demand for picked items
  studioBus.emit('bot:progress', {
    botId: 'asset-hunter',
    status: 'active',
    task: 'Resolving PolyHaven PBR & HDRI maps',
    progress: 64,
  });

  await waitIfPaused(isPaused);

  for (let i = 0; i < picked.length; i++) {
    if (picked[i].apiFilesUrl) {
      picked[i] = await resolvePolyHavenAsset(picked[i]);
      await waitIfPaused(isPaused);
    }
  }

  // Step 2: Live Wikimedia Commons photos + Iconify vector icons
  studioBus.emit('bot:progress', {
    botId: 'asset-hunter',
    status: 'active',
    task: `Querying Wikimedia & Iconify for "${searchPhrase}"`,
    progress: 82,
  });

  const [wikiPhotos, iconifyIcons] = await Promise.all([
    searchWikimediaPhotos(searchPhrase, inferredGame ? 3 : 5),
    searchIconifyIcons(tokens[0] || 'dashboard', inferredGame ? 2 : 4),
  ]);

  await waitIfPaused(isPaused);

  // Merge candidates cleanly (target 6-8 high-signal picker cards)
  const webToAdd = inferredGame ? wikiPhotos.slice(0, 2) : wikiPhotos.slice(0, 3);
  const iconsToAdd = inferredGame ? iconifyIcons.slice(0, 1) : iconifyIcons.slice(0, 2);

  for (const w of [...webToAdd, ...iconsToAdd]) {
    if (!usedIds.has(w.id)) {
      picked.push(w);
      usedIds.add(w.id);
    }
  }

  // Build rich backup pool for instant ✕ Reject replacement
  const backupPool: StudioAssetItem[] = [
    ...rankedVault.filter((i) => !usedIds.has(i.id)),
    ...wikiPhotos.filter((i) => !usedIds.has(i.id)),
    ...iconifyIcons.filter((i) => !usedIds.has(i.id)),
  ];

  studioBus.emit('bot:progress', {
    botId: 'asset-hunter',
    status: 'done',
    task: `${picked.length} assets ready for review`,
    progress: 100,
  });

  return {
    candidates: picked,
    backupPool,
    catalogCount: catalogRes.items.length,
    wikimediaCount: wikiPhotos.length,
    iconifyCount: iconifyIcons.length,
    message: `Fetched ${picked.length} candidate assets (${catalogRes.items.length} vault indexed, ${wikiPhotos.length} Wikimedia photos, ${iconifyIcons.length} Iconify icons).`,
  };
}

/**
 * Finds the next best real replacement when the user clicks ✕ Reject or says "Find another army truck".
 */
export async function findReplacementAsset(
  rejectedItem: StudioAssetItem,
  queryHint: string,
  backupPool: StudioAssetItem[],
  assetVaultRepo: string,
  excludedIds: Set<string>
): Promise<{ replacement: StudioAssetItem | null; remainingBackup: StudioAssetItem[] }> {
  studioBus.emit('bot:progress', {
    botId: 'asset-hunter',
    status: 'active',
    task: `Finding replacement for ${rejectedItem.name}`,
    progress: 55,
  });

  const tokens = tokenizeQuery(queryHint || rejectedItem.name);

  // 1. Check backupPool for same category first
  const sameCatIdx = backupPool.findIndex(
    (b) => b.category === rejectedItem.category && !excludedIds.has(b.id)
  );
  if (sameCatIdx !== -1) {
    let chosen = backupPool[sameCatIdx];
    const remainingBackup = backupPool.filter((_, idx) => idx !== sameCatIdx);
    if (chosen.apiFilesUrl) {
      chosen = await resolvePolyHavenAsset(chosen);
    }
    studioBus.emit('bot:progress', {
      botId: 'asset-hunter',
      status: 'done',
      task: `Swapped with ${chosen.name}`,
      progress: 100,
    });
    return { replacement: { ...chosen, status: 'candidate' }, remainingBackup };
  }

  // 2. Search catalog.json directly if queryHint was given
  const catalogRes = await fetchVaultCatalog(assetVaultRepo, false);
  const catalogMatch = catalogRes.items
    .filter((i) => !excludedIds.has(i.id))
    .map((i) => ({
      i,
      score:
        scoreAssetRelevance(i, tokens, true) +
        (i.category === rejectedItem.category ? 8 : 0),
    }))
    .sort((a, b) => b.score - a.score)[0];

  if (catalogMatch && catalogMatch.score > 2) {
    let chosen = catalogMatch.i;
    if (chosen.apiFilesUrl) {
      chosen = await resolvePolyHavenAsset(chosen);
    }
    studioBus.emit('bot:progress', {
      botId: 'asset-hunter',
      status: 'done',
      task: `Swapped with ${chosen.name}`,
      progress: 100,
    });
    return { replacement: { ...chosen, status: 'candidate' }, remainingBackup: backupPool };
  }

  // 3. Live web fallback (Iconify for icons, Wikimedia Commons for photos/visuals)
  if (rejectedItem.category === 'vector_icon') {
    const freshIcons = await searchIconifyIcons(queryHint || rejectedItem.name, 6);
    const nextIcon = freshIcons.find((ic) => !excludedIds.has(ic.id));
    if (nextIcon) {
      studioBus.emit('bot:progress', {
        botId: 'asset-hunter',
        status: 'done',
        task: `Swapped icon: ${nextIcon.name}`,
        progress: 100,
      });
      return { replacement: nextIcon, remainingBackup: backupPool };
    }
  }

  const freshPhotos = await searchWikimediaPhotos(
    queryHint || `${rejectedItem.name} ${rejectedItem.category.replace('_', ' ')}`,
    6
  );
  const nextPhoto = freshPhotos.find((p) => !excludedIds.has(p.id));
  if (nextPhoto) {
    studioBus.emit('bot:progress', {
      botId: 'asset-hunter',
      status: 'done',
      task: `Found photo: ${nextPhoto.name}`,
      progress: 100,
    });
    return { replacement: nextPhoto, remainingBackup: backupPool };
  }

  // 4. Any remaining backup item
  const anyIdx = backupPool.findIndex((b) => !excludedIds.has(b.id));
  if (anyIdx !== -1) {
    let chosen = backupPool[anyIdx];
    const remainingBackup = backupPool.filter((_, idx) => idx !== anyIdx);
    if (chosen.apiFilesUrl) {
      chosen = await resolvePolyHavenAsset(chosen);
    }
    studioBus.emit('bot:progress', {
      botId: 'asset-hunter',
      status: 'done',
      task: `Swapped with ${chosen.name}`,
      progress: 100,
    });
    return { replacement: { ...chosen, status: 'candidate' }, remainingBackup };
  }

  studioBus.emit('bot:progress', {
    botId: 'asset-hunter',
    status: 'done',
    task: 'No more alternatives found',
    progress: 100,
  });
  return { replacement: null, remainingBackup: backupPool };
}
