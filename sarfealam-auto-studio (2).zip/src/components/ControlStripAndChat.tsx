import { useEffect, useRef, useState } from 'react';
import {
  Box,
  Camera,
  Code2,
  KeyRound,
  Mic,
  Send,
  ShieldCheck,
} from 'lucide-react';
import type { ChatMessage, PanelType, VoiceStatusSnapshot } from '../types/studio';

interface ControlStripAndChatProps {
  activePanel: PanelType;
  messages: ChatMessage[];
  voice: VoiceStatusSnapshot;
  isProcessing: boolean;
  onSelectPanel: (panel: PanelType) => void;
  onSendCommand: (text: string) => Promise<void>;
  onBargeIn: () => void;
}

const CONTROL_ITEMS: Array<{
  id: Exclude<PanelType, 'none'>;
  label: string;
  Icon: typeof KeyRound;
}> = [
  { id: 'secrets', label: 'Secrets', Icon: KeyRound },
  { id: 'code', label: 'Code', Icon: Code2 },
  { id: 'vault', label: 'Vault', Icon: Box },
  { id: 'admin', label: 'Admin', Icon: ShieldCheck },
  { id: 'camera', label: 'Camera', Icon: Camera },
];

export function ControlStripAndChat({
  activePanel,
  messages,
  voice,
  isProcessing,
  onSelectPanel,
  onSendCommand,
  onBargeIn,
}: ControlStripAndChatProps) {
  const [input, setInput] = useState('');
  const scrollRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages.length, voice.interimTranscript]);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const trimmed = input.trim();
    if (!trimmed || isProcessing) return;
    setInput('');
    await onSendCommand(trimmed);
  }

  return (
    <section
      aria-label="Studio Controls and JARVIS Chat Transcript"
      className="flex flex-col rounded-2xl border border-white/[0.08] bg-[#070C1A]/90 overflow-hidden"
    >
      {/* Control Strip: Secrets, Code, Vault, Admin, Camera */}
      <div className="grid grid-cols-5 border-b border-white/[0.07] bg-[#091023]/90">
        {CONTROL_ITEMS.map(({ id, label, Icon }) => {
          const active = activePanel === id;
          return (
            <button
              key={id}
              type="button"
              onClick={() => onSelectPanel(active ? 'none' : id)}
              className={`relative flex min-h-[44px] items-center justify-center gap-1.5 px-2 text-xs font-medium transition-colors cursor-pointer whitespace-nowrap focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-cyan-400 ${
                active
                  ? 'bg-cyan-500/15 text-cyan-200'
                  : 'text-slate-400 hover:bg-white/[0.03] hover:text-slate-100'
              }`}
            >
              <Icon className="h-4 w-4 shrink-0" />
              <span className="truncate">{label}</span>
              {active && (
                <span
                  className="absolute inset-x-3 bottom-0 h-[2px] rounded-full bg-cyan-400"
                  aria-hidden="true"
                />
              )}
            </button>
          );
        })}
      </div>

      {/* Scrollable JARVIS Chat Transcript */}
      <div
        ref={scrollRef}
        className="flex max-h-[220px] min-h-[145px] flex-col gap-2.5 overflow-y-auto px-4 py-3"
      >
        {messages.map((msg) => {
          const isUser = msg.role === 'user';
          return (
            <div
              key={msg.id}
              className={`flex flex-col ${isUser ? 'items-end' : 'items-start'}`}
            >
              <div
                className={`max-w-[90%] sm:max-w-[80%] rounded-xl px-3.5 py-2 text-xs sm:text-sm leading-relaxed ${
                  isUser
                    ? 'bg-cyan-500/18 text-cyan-50 border border-cyan-400/25'
                    : 'bg-[#0D1529] text-slate-200 border border-white/[0.07]'
                }`}
              >
                <div className="mb-0.5 flex items-center gap-2 text-[11px] text-slate-400">
                  <span className="font-semibold text-slate-300">
                    {isUser ? 'You' : 'JARVIS'}
                  </span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono tabular-nums">
                    {new Date(msg.timestamp).toLocaleTimeString([], {
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </span>
                  {msg.provider && (
                    <>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono text-[10px] text-slate-400 truncate max-w-[160px]">
                        {msg.provider}
                      </span>
                    </>
                  )}
                </div>
                <p className="whitespace-pre-wrap">{msg.text}</p>
                {msg.actuators && msg.actuators.length > 0 && (
                  <div className="mt-1.5 border-t border-white/[0.06] pt-1 text-[11px] font-mono text-cyan-300/90">
                    {msg.actuators.map((act, idx) => (
                      <div key={idx} className="truncate">
                        Executed {act.tool}({Object.values(act.args).join(', ')})
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          );
        })}

        {/* Live Voice Interim Transcript or Error Line */}
        {voice.interimTranscript && (
          <div className="flex items-center gap-2 rounded-lg border border-cyan-400/25 bg-cyan-500/10 px-3 py-1.5 text-xs text-cyan-200">
            <Mic className="h-3.5 w-3.5 shrink-0" />
            <span className="truncate">Listening: “{voice.interimTranscript}”</span>
          </div>
        )}
        {voice.lastError && (
          <div className="text-xs text-amber-300/90 px-1">
            Voice notice: {voice.lastError}
          </div>
        )}
      </div>

      {/* Command Input Bar */}
      <form
        onSubmit={handleSubmit}
        className="flex items-center gap-2 border-t border-white/[0.07] bg-[#060A16] px-3 py-2.5"
      >
        <button
          type="button"
          onClick={onBargeIn}
          aria-label="Tap to speak or barge-in"
          className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border transition-colors cursor-pointer ${
            voice.state === 'LISTENING'
              ? 'border-cyan-400/60 bg-cyan-500/20 text-cyan-200'
              : voice.state === 'SPEAKING'
              ? 'border-emerald-400/60 bg-emerald-500/20 text-emerald-200'
              : 'border-white/10 bg-[#0D152B] text-slate-300 hover:border-cyan-400/40 hover:text-cyan-200'
          }`}
          title="1-Tap Barge-In / Speak"
        >
          <Mic className="h-4 w-4" />
        </button>

        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Speak or type any command..."
          aria-label="Command input"
          className="h-10 flex-1 rounded-xl border border-white/10 bg-[#0B1224] px-3.5 text-sm text-slate-100 placeholder:text-slate-500 focus:border-cyan-400/50 focus:outline-none"
        />

        <button
          type="submit"
          disabled={!input.trim() || isProcessing}
          className="inline-flex h-10 items-center gap-1.5 rounded-xl bg-cyan-500 px-4 text-xs sm:text-sm font-semibold text-slate-950 hover:bg-cyan-400 disabled:opacity-45 disabled:cursor-not-allowed transition-colors cursor-pointer whitespace-nowrap shrink-0"
        >
          <Send className="h-3.5 w-3.5" />
          <span>{isProcessing ? 'Working' : 'Send'}</span>
        </button>
      </form>
    </section>
  );
}
