import { Capacitor } from '@capacitor/core';
import { SpeechRecognition } from '@capacitor-community/speech-recognition';
import { TextToSpeech } from '@capacitor-community/text-to-speech';
import { buildGeminiFunctionDeclarations, buildJarvisSystemPrompt } from './aiRouter';
import { studioBus } from './eventBus';
import type {
  LanguageCode,
  SecretsConfig,
  VoiceState,
  VoiceStatusSnapshot,
  VoiceTransport,
  WorldState,
} from '../types/studio';

interface WebSpeechRecognitionEvent {
  resultIndex: number;
  results: {
    length: number;
    [index: number]: {
      isFinal: boolean;
      [alt: number]: { transcript: string };
    };
  };
}

interface WebSpeechRecognitionInstance {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  onresult: ((ev: WebSpeechRecognitionEvent) => void) | null;
  onerror: ((ev: { error: string }) => void) | null;
  onend: (() => void) | null;
  start: () => void;
  stop: () => void;
  abort: () => void;
}

type TranscriptHandler = (text: string) => Promise<string | void>;
type LiveToolHandler = (name: string, args: Record<string, unknown>) => Promise<string>;
type ContextProvider = () => { state: WorldState; secrets: SecretsConfig };

const SILENCE_DEBOUNCE_MS = 900;
const ECHO_GUARD_MS = 250;

function float32ToInt16Base64(float32: Float32Array): string {
  const int16 = new Int16Array(float32.length);
  for (let i = 0; i < float32.length; i++) {
    const s = Math.max(-1, Math.min(1, float32[i]));
    int16[i] = s < 0 ? s * 0x8000 : s * 0x7fff;
  }
  const bytes = new Uint8Array(int16.buffer);
  let binary = '';
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

function base64Pcm16ToFloat32(base64: string): Float32Array {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  const view = new DataView(bytes.buffer);
  const sampleCount = Math.floor(bytes.byteLength / 2);
  const float32 = new Float32Array(sampleCount);
  for (let i = 0; i < sampleCount; i++) {
    float32[i] = view.getInt16(i * 2, true) / 32768;
  }
  return float32;
}

class DualLiveVoiceEngine {
  private liveEnabled = false;
  private state: VoiceState = 'IDLE';
  private transport: VoiceTransport = 'native-bridge';
  private interimTranscript = '';
  private lastError: string | null = null;
  private greeted = false;
  private isNative = Capacitor.isNativePlatform();

  // Sequential Bridge state (Mode B) — NEVER opens getUserMedia!
  private silenceTimer: ReturnType<typeof setTimeout> | null = null;
  private echoGuardTimer: ReturnType<typeof setTimeout> | null = null;
  private pendingTranscript = '';
  private nativeListenerHandle: { remove: () => Promise<void> } | null = null;
  private webRecognition: WebSpeechRecognitionInstance | null = null;
  private recognitionActive = false;
  private isSpeaking = false;

  // Gemini Multimodal Live WebSocket state (Mode A)
  private liveWs: WebSocket | null = null;
  private inputAudioCtx: AudioContext | null = null;
  private outputAudioCtx: AudioContext | null = null;
  private mediaStream: MediaStream | null = null;
  private scriptProcessor: ScriptProcessorNode | null = null;
  private scheduledSources: AudioBufferSourceNode[] = [];
  private nextPlaybackTime = 0;

  // Hooks injected by JarvisKernel
  private onUserUtterance: TranscriptHandler | null = null;
  private onLiveToolCall: LiveToolHandler | null = null;
  private getContext: ContextProvider | null = null;

  configure(handlers: {
    onUserUtterance: TranscriptHandler;
    onLiveToolCall: LiveToolHandler;
    getContext: ContextProvider;
  }): void {
    this.onUserUtterance = handlers.onUserUtterance;
    this.onLiveToolCall = handlers.onLiveToolCall;
    this.getContext = handlers.getContext;
  }

  getSnapshot(): VoiceStatusSnapshot {
    return {
      liveEnabled: this.liveEnabled,
      state: this.state,
      transport: this.transport,
      isNativePlatform: this.isNative,
      interimTranscript: this.interimTranscript,
      lastError: this.lastError,
      greeted: this.greeted,
    };
  }

  private emitStatus(): void {
    studioBus.emit('voice:status', this.getSnapshot());
  }

  private setState(next: VoiceState): void {
    this.state = next;
    this.emitStatus();
  }

  private getBcp47Lang(): string {
    const lang: LanguageCode = this.getContext?.().state.language ?? 'en';
    return lang === 'hi' ? 'hi-IN' : 'en-IN';
  }

  private getGreetingText(): string {
    const lang: LanguageCode = this.getContext?.().state.language ?? 'en';
    return lang === 'hi'
      ? 'नमस्ते सर, जार्विस ऑनलाइन और तैयार है।'
      : 'Namaste Sir, JARVIS is online and ready.';
  }

  async greetIfNeeded(): Promise<void> {
    if (this.greeted) return;
    this.greeted = true;
    await this.speakDirect(this.getGreetingText(), false);
  }

  async startLive(): Promise<void> {
    if (this.liveEnabled) return;
    this.lastError = null;
    this.liveEnabled = true;

    const ctx = this.getContext?.();
    const geminiKey = ctx?.secrets.apiKeys.gemini?.trim() ?? '';
    const useGeminiLive = Boolean(geminiKey.startsWith('AIza') && ctx?.secrets.preferGeminiLive);

    if (useGeminiLive) {
      this.transport = 'gemini-live';
      this.emitStatus();
      const connected = await this.startGeminiLiveMode(geminiKey);
      if (connected) {
        return;
      }
      // Graceful automatic fallback to Mode B Sequential Bridge
      this.transport = 'native-bridge';
      this.emitStatus();
    } else {
      this.transport = 'native-bridge';
      this.emitStatus();
    }

    // Mode B: Greet aloud first, then enter strict sequential LISTENING loop
    this.greeted = true;
    await this.speakDirect(this.getGreetingText(), true);
  }

  async stopLive(): Promise<void> {
    this.liveEnabled = false;
    this.clearTimers();
    this.interimTranscript = '';
    this.pendingTranscript = '';

    await this.teardownGeminiLive();
    await this.stopListeningBridge();
    await this.stopSpeakingImmediate();

    this.setState('IDLE');
  }

  setPausedVisual(paused: boolean): void {
    // Pause freezes studio work WITHOUT disconnecting Voice!
    // Only reflect PAUSED orb hue when voice is otherwise idle.
    if (!this.liveEnabled) {
      this.setState(paused ? 'PAUSED' : 'IDLE');
    }
  }

  /**
   * Instant 1-tap Barge-In:
   * Immediately halts TTS / PCM audio output and enters LISTENING without locking mic.
   */
  async bargeIn(): Promise<void> {
    if (!this.liveEnabled) {
      await this.startLive();
      return;
    }

    this.clearTimers();
    this.pendingTranscript = '';
    this.interimTranscript = '';

    if (this.transport === 'gemini-live') {
      this.clearGeminiAudioQueue();
      this.setState('LISTENING');
      return;
    }

    await this.stopSpeakingImmediate();
    await this.startListeningBridge();
  }

  /**
   * Public speech output used by Kernel (e.g., inspect_work, tool replies, text chat).
   * Respects strict sequential state machine: stops recognition before speaking,
   * speaks without iOS-only category flags, waits 250ms echo guard, then restarts recognition.
   */
  async speak(text: string): Promise<void> {
    const clean = text.trim();
    if (!clean) return;
    await this.speakDirect(clean, this.liveEnabled && this.transport === 'native-bridge');
  }

  // =========================================================================
  // MODE A: GEMINI MULTIMODAL LIVE WEBSOCKET (BidiGenerateContent)
  // =========================================================================

  private async startGeminiLiveMode(geminiKey: string): Promise<boolean> {
    // CRITICAL: Ensure Mode B SpeechRecognition is completely stopped before touching mic
    await this.stopListeningBridge();

    return new Promise<boolean>((resolve) => {
      let settled = false;
      const finish = (ok: boolean) => {
        if (!settled) {
          settled = true;
          resolve(ok);
        }
      };

      try {
        const wsUrl = `wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=${encodeURIComponent(geminiKey)}`;
        const ws = new WebSocket(wsUrl);
        this.liveWs = ws;
        this.setState('THINKING');

        const timeout = setTimeout(() => {
          if (ws.readyState !== WebSocket.OPEN) {
            this.lastError = 'Gemini Live WebSocket timed out — switching to Native Sequential Bridge.';
            this.teardownGeminiLive();
            finish(false);
          }
        }, 7000);

        ws.onopen = async () => {
          clearTimeout(timeout);
          const ctx = this.getContext?.();
          const sysPrompt = ctx
            ? buildJarvisSystemPrompt(ctx.state)
            : 'You are JARVIS in Sarfealam Auto-Studio.';

          const setupMsg = {
            setup: {
              model: 'models/gemini-2.5-flash-native-audio-preview-09-2025',
              generationConfig: {
                responseModalities: ['AUDIO'],
                speechConfig: {
                  voiceConfig: {
                    prebuiltVoiceConfig: { voiceName: 'Fenrir' },
                  },
                },
              },
              systemInstruction: {
                parts: [{ text: sysPrompt }],
              },
              inputAudioTranscription: {},
              outputAudioTranscription: {},
              tools: [{ functionDeclarations: buildGeminiFunctionDeclarations() }],
            },
          };

          ws.send(JSON.stringify(setupMsg));

          try {
            await this.startGeminiMicStream(ws);
            this.greeted = true;
            // Prompt JARVIS Live to speak the greeting aloud immediately
            ws.send(
              JSON.stringify({
                clientContent: {
                  turns: [
                    {
                      role: 'user',
                      parts: [
                        {
                          text: `Greet the user right now by saying exactly: "${this.getGreetingText()}"`,
                        },
                      ],
                    },
                  ],
                  turnComplete: true,
                },
              })
            );
            this.setState('SPEAKING');
            finish(true);
          } catch (micErr) {
            this.lastError =
              micErr instanceof Error
                ? `Gemini Live mic error (${micErr.message}) — falling back to Sequential Bridge.`
                : 'Mic capture unavailable — falling back to Sequential Bridge.';
            await this.teardownGeminiLive();
            finish(false);
          }
        };

        ws.onmessage = async (event) => {
          await this.handleGeminiWsMessage(event.data);
        };

        ws.onerror = () => {
          clearTimeout(timeout);
          this.lastError = 'Gemini Live WebSocket connection error — switching to Native Sequential Bridge.';
          this.teardownGeminiLive();
          finish(false);
        };

        ws.onclose = () => {
          clearTimeout(timeout);
          if (!settled) {
            this.lastError = 'Gemini Live session closed — falling back to Native Sequential Bridge.';
            finish(false);
          } else if (this.liveEnabled && this.transport === 'gemini-live') {
            // Unexpected mid-session drop -> fall back seamlessly to Mode B
            this.transport = 'native-bridge';
            this.teardownGeminiLive().then(() => {
              if (this.liveEnabled) {
                this.startListeningBridge();
              }
            });
          }
        };
      } catch (err) {
        this.lastError = err instanceof Error ? err.message : 'Failed to initialize Gemini Live WebSocket.';
        finish(false);
      }
    });
  }

  private async startGeminiMicStream(ws: WebSocket): Promise<void> {
    if (!navigator.mediaDevices?.getUserMedia) {
      throw new Error('getUserMedia not supported in this WebView');
    }

    const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    this.inputAudioCtx = new AudioCtx({ sampleRate: 16000 });
    this.outputAudioCtx = new AudioCtx({ sampleRate: 24000 });
    this.nextPlaybackTime = this.outputAudioCtx.currentTime;

    const stream = await navigator.mediaDevices.getUserMedia({
      audio: {
        sampleRate: 16000,
        channelCount: 1,
        echoCancellation: true,
        noiseSuppression: true,
        autoGainControl: true,
      },
      video: false,
    });
    this.mediaStream = stream;

    const source = this.inputAudioCtx.createMediaStreamSource(stream);
    const processor = this.inputAudioCtx.createScriptProcessor(4096, 1, 1);
    this.scriptProcessor = processor;

    processor.onaudioprocess = (e) => {
      if (ws.readyState !== WebSocket.OPEN || !this.liveEnabled) return;
      const channelData = e.inputBuffer.getChannelData(0);
      const base64Audio = float32ToInt16Base64(channelData);
      ws.send(
        JSON.stringify({
          realtimeInput: {
            audio: {
              mimeType: 'audio/pcm;rate=16000',
              data: base64Audio,
            },
          },
        })
      );
    };

    source.connect(processor);
    processor.connect(this.inputAudioCtx.destination);
  }

  private async handleGeminiWsMessage(rawData: string | Blob): Promise<void> {
    try {
      const textData = rawData instanceof Blob ? await rawData.text() : rawData;
      const msg = JSON.parse(textData);

      // Handle server-side barge-in interrupt
      if (msg.serverContent?.interrupted) {
        this.clearGeminiAudioQueue();
        this.setState('LISTENING');
        return;
      }

      // Live input transcription
      const inputText = msg.serverContent?.inputTranscription?.text;
      if (typeof inputText === 'string' && inputText.trim()) {
        this.interimTranscript = inputText.trim();
        this.emitStatus();
      }

      // Live output audio chunks (24kHz PCM16)
      const parts = msg.serverContent?.modelTurn?.parts ?? [];
      for (const part of parts) {
        if (part.inlineData?.data) {
          this.setState('SPEAKING');
          this.enqueuePcm24kAudio(part.inlineData.data);
        }
      }

      // Live output transcription
      const outputText = msg.serverContent?.outputTranscription?.text;
      if (typeof outputText === 'string' && outputText.trim()) {
        studioBus.emit('voice:user_speech', {
          text: outputText.trim(),
          source: 'gemini-live',
        });
      }

      // Real-time Robot UI Tool Calls over Live WebSocket
      const functionCalls = msg.toolCall?.functionCalls;
      if (Array.isArray(functionCalls) && functionCalls.length > 0 && this.onLiveToolCall) {
        this.setState('THINKING');
        const functionResponses = [];
        for (const call of functionCalls) {
          const result = await this.onLiveToolCall(call.name, call.args ?? {});
          functionResponses.push({
            id: call.id,
            name: call.name,
            response: { result },
          });
        }
        if (this.liveWs?.readyState === WebSocket.OPEN) {
          this.liveWs.send(JSON.stringify({ toolResponse: { functionResponses } }));
        }
      }

      if (msg.serverContent?.turnComplete) {
        this.interimTranscript = '';
        if (this.liveEnabled) {
          this.setState('LISTENING');
        }
      }
    } catch (err) {
      console.error('[VoiceEngine] Error parsing Gemini Live frame:', err);
    }
  }

  private enqueuePcm24kAudio(base64Pcm: string): void {
    if (!this.outputAudioCtx) return;
    if (this.outputAudioCtx.state === 'suspended') {
      this.outputAudioCtx.resume().catch(() => {});
    }
    const samples = base64Pcm16ToFloat32(base64Pcm);
    const buffer = this.outputAudioCtx.createBuffer(1, samples.length, 24000);
    buffer.getChannelData(0).set(samples);

    const source = this.outputAudioCtx.createBufferSource();
    source.buffer = buffer;
    source.connect(this.outputAudioCtx.destination);

    const now = this.outputAudioCtx.currentTime;
    const startAt = Math.max(now + 0.02, this.nextPlaybackTime);
    source.start(startAt);
    this.nextPlaybackTime = startAt + buffer.duration;

    this.scheduledSources.push(source);
    source.onended = () => {
      this.scheduledSources = this.scheduledSources.filter((s) => s !== source);
      if (this.scheduledSources.length === 0 && this.liveEnabled && this.state === 'SPEAKING') {
        this.setState('LISTENING');
      }
    };
  }

  private clearGeminiAudioQueue(): void {
    for (const src of this.scheduledSources) {
      try {
        src.stop();
      } catch {
        // ignore already stopped
      }
    }
    this.scheduledSources = [];
    if (this.outputAudioCtx) {
      this.nextPlaybackTime = this.outputAudioCtx.currentTime;
    }
  }

  private async teardownGeminiLive(): Promise<void> {
    this.clearGeminiAudioQueue();
    if (this.scriptProcessor) {
      try {
        this.scriptProcessor.disconnect();
      } catch {
        // ignore
      }
      this.scriptProcessor = null;
    }
    if (this.mediaStream) {
      this.mediaStream.getTracks().forEach((t) => t.stop());
      this.mediaStream = null;
    }
    if (this.inputAudioCtx) {
      await this.inputAudioCtx.close().catch(() => {});
      this.inputAudioCtx = null;
    }
    if (this.outputAudioCtx) {
      await this.outputAudioCtx.close().catch(() => {});
      this.outputAudioCtx = null;
    }
    if (this.liveWs) {
      try {
        this.liveWs.close();
      } catch {
        // ignore
      }
      this.liveWs = null;
    }
  }

  // =========================================================================
  // MODE B: CLEAN NATIVE ANDROID SEQUENTIAL BRIDGE + BROWSER WEB SPEECH FALLBACK
  // CRITICAL ANTI-MIC-LOCK RULE: NEVER CALL getUserMedia IN MODE B!
  // =========================================================================

  private async startListeningBridge(): Promise<void> {
    if (!this.liveEnabled || this.isSpeaking || this.transport !== 'native-bridge') return;

    this.clearTimers();
    this.pendingTranscript = '';
    this.interimTranscript = '';

    if (this.isNative) {
      await this.startNativeAndroidListening();
    } else {
      this.startBrowserWebSpeechListening();
    }
  }

  private async startNativeAndroidListening(): Promise<void> {
    try {
      const perm = await SpeechRecognition.checkPermissions();
      if (perm.speechRecognition !== 'granted') {
        const req = await SpeechRecognition.requestPermissions();
        if (req.speechRecognition !== 'granted') {
          this.lastError = 'Android microphone permission denied for SpeechRecognition.';
          this.liveEnabled = false;
          this.setState('IDLE');
          return;
        }
      }

      if (this.nativeListenerHandle) {
        await this.nativeListenerHandle.remove().catch(() => {});
        this.nativeListenerHandle = null;
      }

      this.nativeListenerHandle = await SpeechRecognition.addListener(
        'partialResults',
        (data: { matches?: string[] }) => {
          if (!this.liveEnabled || this.state !== 'LISTENING') return;
          const match = data.matches?.[0]?.trim();
          if (!match) return;

          this.pendingTranscript = match;
          this.interimTranscript = match;
          this.emitStatus();

          // 900ms silence debounce -> stop SpeechRecognition -> THINKING
          if (this.silenceTimer) clearTimeout(this.silenceTimer);
          this.silenceTimer = setTimeout(() => {
            this.finalizeUtterance('native-bridge');
          }, SILENCE_DEBOUNCE_MS);
        }
      );

      this.recognitionActive = true;
      this.setState('LISTENING');

      await SpeechRecognition.start({
        language: this.getBcp47Lang(),
        maxResults: 1,
        partialResults: true,
        popup: false,
      });
    } catch (err) {
      this.recognitionActive = false;
      this.lastError = err instanceof Error ? err.message : 'Native SpeechRecognition failed to start.';
      studioBus.emit('voice:error', { message: this.lastError });
      this.setState('IDLE');
    }
  }

  private startBrowserWebSpeechListening(): void {
    const win = window as unknown as {
      SpeechRecognition?: new () => WebSpeechRecognitionInstance;
      webkitSpeechRecognition?: new () => WebSpeechRecognitionInstance;
    };
    const SpeechRecCtor = win.SpeechRecognition || win.webkitSpeechRecognition;

    if (!SpeechRecCtor) {
      this.lastError =
        'Browser SpeechRecognition unavailable (use Chrome or native Android APK). You can still type commands and hear TTS replies.';
      this.setState('IDLE');
      return;
    }

    try {
      this.stopBrowserRecognitionOnly();
      const rec = new SpeechRecCtor();
      rec.continuous = true;
      rec.interimResults = true;
      rec.lang = this.getBcp47Lang();

      rec.onresult = (event: WebSpeechRecognitionEvent) => {
        if (!this.liveEnabled || this.state !== 'LISTENING') return;
        let combined = '';
        for (let i = event.resultIndex; i < event.results.length; i++) {
          combined += event.results[i][0]?.transcript ?? '';
        }
        const cleaned = combined.trim();
        if (!cleaned) return;

        this.pendingTranscript = cleaned;
        this.interimTranscript = cleaned;
        this.emitStatus();

        if (this.silenceTimer) clearTimeout(this.silenceTimer);
        this.silenceTimer = setTimeout(() => {
          this.finalizeUtterance('web-speech');
        }, SILENCE_DEBOUNCE_MS);
      };

      rec.onerror = (ev) => {
        if (ev.error === 'no-speech' || ev.error === 'aborted') return;
        this.lastError = `Voice input: ${ev.error}`;
        this.emitStatus();
      };

      rec.onend = () => {
        this.recognitionActive = false;
        // Auto-recover listening if still in LISTENING state and no pending utterance
        if (
          this.liveEnabled &&
          this.transport === 'native-bridge' &&
          this.state === 'LISTENING' &&
          !this.pendingTranscript &&
          !this.isSpeaking
        ) {
          this.echoGuardTimer = setTimeout(() => {
            if (this.liveEnabled && this.state === 'LISTENING') {
              this.startBrowserWebSpeechListening();
            }
          }, ECHO_GUARD_MS);
        }
      };

      this.webRecognition = rec;
      this.recognitionActive = true;
      this.setState('LISTENING');
      rec.start();
    } catch (err) {
      this.recognitionActive = false;
      this.lastError = err instanceof Error ? err.message : 'Unable to start browser voice recognition.';
      this.emitStatus();
    }
  }

  private async finalizeUtterance(source: 'native-bridge' | 'web-speech'): Promise<void> {
    this.clearTimers();
    const spokenText = this.pendingTranscript.trim();
    this.pendingTranscript = '';
    this.interimTranscript = '';

    // STRICT STEP 1: Stop SpeechRecognition completely BEFORE thinking/speaking
    await this.stopListeningBridge();

    if (!spokenText) {
      if (this.liveEnabled && this.transport === 'native-bridge') {
        await this.startListeningBridge();
      }
      return;
    }

    // STRICT STEP 2: Enter THINKING
    this.setState('THINKING');
    studioBus.emit('voice:user_speech', { text: spokenText, source });

    try {
      const reply = await this.onUserUtterance?.(spokenText);
      // STRICT STEP 3: Enter SPEAKING (then 250ms echo guard -> restart LISTENING)
      if (typeof reply === 'string' && reply.trim()) {
        await this.speakDirect(reply.trim(), this.liveEnabled && this.transport === 'native-bridge');
      } else if (this.liveEnabled && this.transport === 'native-bridge') {
        this.scheduleResumeListeningAfterEchoGuard();
      } else {
        this.setState('IDLE');
      }
    } catch (err) {
      this.lastError = err instanceof Error ? err.message : 'Error processing voice command.';
      if (this.liveEnabled && this.transport === 'native-bridge') {
        this.scheduleResumeListeningAfterEchoGuard();
      } else {
        this.setState('IDLE');
      }
    }
  }

  private async speakDirect(text: string, resumeListeningAfter: boolean): Promise<void> {
    // Always stop recognition before speaking so hardware mic never clashes with TTS
    await this.stopListeningBridge();
    this.isSpeaking = true;
    this.setState('SPEAKING');

    const lang = this.getBcp47Lang();

    try {
      if (this.isNative) {
        // CRITICAL: Call Capacitor TextToSpeech WITHOUT iOS-only category: 'ambient'
        await TextToSpeech.speak({
          text,
          lang,
          rate: 1.05,
          pitch: 1.0,
          volume: 1.0,
        });
      } else if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        await new Promise<void>((resolve) => {
          try {
            window.speechSynthesis.cancel();
            const utter = new SpeechSynthesisUtterance(text);
            utter.lang = lang;
            utter.rate = 1.05;
            utter.pitch = 1.0;

            const voices = window.speechSynthesis.getVoices();
            const matched =
              voices.find((v) => v.lang.toLowerCase() === lang.toLowerCase()) ||
              voices.find((v) => v.lang.toLowerCase().startsWith(lang.slice(0, 2).toLowerCase()));
            if (matched) utter.voice = matched;

            // Safety timeout in case a headless browser suppresses onend
            const guardMs = Math.min(18000, Math.max(2500, text.length * 95));
            const fallbackTimer = setTimeout(() => resolve(), guardMs);

            utter.onend = () => {
              clearTimeout(fallbackTimer);
              resolve();
            };
            utter.onerror = () => {
              clearTimeout(fallbackTimer);
              resolve();
            };

            window.speechSynthesis.speak(utter);
          } catch {
            resolve();
          }
        });
      }
    } catch (err) {
      this.lastError = err instanceof Error ? err.message : 'TTS playback error';
    } finally {
      this.isSpeaking = false;
    }

    if (resumeListeningAfter && this.liveEnabled && this.transport === 'native-bridge') {
      // STRICT STEP 4: 250ms echo guard -> auto-restart SpeechRecognition
      this.scheduleResumeListeningAfterEchoGuard();
    } else if (!this.liveEnabled) {
      const isPaused = this.getContext?.().state.paused ?? false;
      this.setState(isPaused ? 'PAUSED' : 'IDLE');
    } else if (this.transport === 'gemini-live') {
      this.setState('LISTENING');
    }
  }

  private scheduleResumeListeningAfterEchoGuard(): void {
    if (this.echoGuardTimer) clearTimeout(this.echoGuardTimer);
    this.echoGuardTimer = setTimeout(() => {
      if (this.liveEnabled && this.transport === 'native-bridge' && !this.isSpeaking) {
        this.startListeningBridge();
      }
    }, ECHO_GUARD_MS);
  }

  private async stopListeningBridge(): Promise<void> {
    if (this.silenceTimer) {
      clearTimeout(this.silenceTimer);
      this.silenceTimer = null;
    }
    if (this.isNative) {
      if (this.recognitionActive) {
        this.recognitionActive = false;
        await SpeechRecognition.stop().catch(() => {});
      }
      if (this.nativeListenerHandle) {
        await this.nativeListenerHandle.remove().catch(() => {});
        this.nativeListenerHandle = null;
      }
    } else {
      this.stopBrowserRecognitionOnly();
    }
  }

  private stopBrowserRecognitionOnly(): void {
    if (this.webRecognition) {
      try {
        this.webRecognition.onresult = null;
        this.webRecognition.onend = null;
        this.webRecognition.onerror = null;
        this.webRecognition.stop();
      } catch {
        // ignore
      }
      this.webRecognition = null;
    }
    this.recognitionActive = false;
  }

  private async stopSpeakingImmediate(): Promise<void> {
    this.isSpeaking = false;
    if (this.isNative) {
      await TextToSpeech.stop().catch(() => {});
    } else if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      try {
        window.speechSynthesis.cancel();
      } catch {
        // ignore
      }
    }
  }

  private clearTimers(): void {
    if (this.silenceTimer) {
      clearTimeout(this.silenceTimer);
      this.silenceTimer = null;
    }
    if (this.echoGuardTimer) {
      clearTimeout(this.echoGuardTimer);
      this.echoGuardTimer = null;
    }
  }
}

export const voiceEngine = new DualLiveVoiceEngine();
