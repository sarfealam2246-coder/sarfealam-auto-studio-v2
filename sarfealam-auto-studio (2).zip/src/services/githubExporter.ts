import JSZip from 'jszip';
import { studioBus } from './eventBus';
import type {
  EngineType,
  GeneratedFile,
  ReleaseLinks,
  SecretsConfig,
  WorldState,
} from '../types/studio';

export interface AtomicExportFile {
  path: string;
  content: string;
}

export interface AtomicPushResult {
  ok: boolean;
  repoOwner: string;
  repoName: string;
  repoFullName: string;
  commitSha?: string;
  links?: ReleaseLinks;
  pagesEnabled?: boolean;
  pagesNote?: string;
  fileCount: number;
  error?: string;
}

const GITHUB_API = 'https://api.github.com';

function ghHeaders(pat: string): Record<string, string> {
  return {
    Accept: 'application/vnd.github+json',
    Authorization: `Bearer ${pat.trim()}`,
    'X-GitHub-Api-Version': '2022-11-28',
    'Content-Type': 'application/json',
  };
}

export function sanitizeRepoName(rawInput: string): string {
  const cleaned = rawInput
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 40);
  if (!cleaned) {
    return `sarfealam-app-${Date.now().toString(36).slice(-5)}`;
  }
  return cleaned.startsWith('sarfealam-') ? cleaned : `sarfealam-${cleaned}`;
}

export function resolveEffectiveEngine(engine: EngineType): Exclude<EngineType, 'Auto'> {
  return engine === 'Auto' ? 'Capacitor 3D/App' : engine;
}

export function getApkWorkflowFileName(engine: EngineType): string {
  const eff = resolveEffectiveEngine(engine);
  switch (eff) {
    case 'Godot 4':
      return 'build-godot-apk.yml';
    case 'Flutter':
      return 'build-flutter-apk.yml';
    case 'Unity':
      return 'build-unity-apk.yml';
    case 'Capacitor 3D/App':
    default:
      return 'build-apk.yml';
  }
}

// ============================================================================
// REAL APK WORKFLOWS (ZERO `|| echo` FAKE GREEN TICKS)
// ============================================================================

function buildDeployAdminWorkflow(): string {
  return `name: Deploy Owner Admin & Live Web Test

on:
  push:
    branches: ["main"]
    paths:
      - "docs/**"
  workflow_dispatch:

permissions:
  contents: read
  pages: write
  id-token: write

concurrency:
  group: "\${{ github.workflow }}-\${{ github.ref }}"
  cancel-in-progress: true

jobs:
  deploy-pages:
    environment:
      name: github-pages
      url: \${{ steps.deployment.outputs.page_url }}
    runs-on: ubuntu-latest
    steps:
      - name: Checkout repository
        uses: actions/checkout@v4

      - name: Verify docs/index.html exists
        run: |
          if [ ! -f docs/index.html ]; then
            echo "ERROR: docs/index.html is missing"
            exit 1
          fi

      - name: Configure GitHub Pages
        uses: actions/configure-pages@v5

      - name: Upload docs artifact
        uses: actions/upload-pages-artifact@v3
        with:
          path: "docs"

      - name: Deploy to GitHub Pages
        id: deployment
        uses: actions/deploy-pages@v4
`;
}

function buildCapacitorApkWorkflow(appSlug: string): string {
  return `name: Build Capacitor Android APK

on:
  push:
    branches: ["main"]
  workflow_dispatch:

permissions:
  contents: write

concurrency:
  group: "apk-build-\${{ github.ref }}"
  cancel-in-progress: true

jobs:
  build-android-apk:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout source
        uses: actions/checkout@v4

      - name: Setup Node.js 22
        uses: actions/setup-node@v4
        with:
          node-version: "22"

      - name: Setup Java 21
        uses: actions/setup-java@v4
        with:
          distribution: "temurin"
          java-version: "21"

      - name: Setup Android SDK
        uses: android-actions/setup-android@v3

      - name: Install dependencies
        run: npm install

      - name: Build web bundle
        run: npm run build

      - name: Add and sync Capacitor Android platform
        run: |
          if [ ! -d android ]; then
            npx cap add android
          fi
          npx cap sync android

      - name: Compile Android Debug APK with Gradle
        run: |
          cd android
          chmod +x gradlew
          ./gradlew assembleDebug --no-daemon

      - name: Verify real APK output exists (fail loudly if missing)
        id: verify_apk
        run: |
          APK_FILE="android/app/build/outputs/apk/debug/app-debug.apk"
          if [ ! -f "$APK_FILE" ]; then
            echo "FATAL: Expected APK not found at $APK_FILE"
            exit 1
          fi
          mkdir -p release-artifacts
          cp "$APK_FILE" "release-artifacts/${appSlug}-debug.apk"
          ls -lh "release-artifacts/${appSlug}-debug.apk"

      - name: Publish real APK to GitHub Releases
        uses: softprops/action-gh-release@v2
        with:
          tag_name: v1.0.\${{ github.run_number }}
          name: "${appSlug} APK Build #\${{ github.run_number }}"
          body: "Automated Android APK built via Vite + Capacitor 6 (Node 22, Java 21)."
          files: release-artifacts/${appSlug}-debug.apk
          make_latest: true
`;
}

function buildGodotApkWorkflow(appSlug: string): string {
  return `name: Build Godot 4 Android APK

on:
  push:
    branches: ["main"]
  workflow_dispatch:

permissions:
  contents: write

concurrency:
  group: "godot-apk-\${{ github.ref }}"
  cancel-in-progress: true

jobs:
  build-godot-apk:
    runs-on: ubuntu-latest
    env:
      GODOT_VERSION: "4.3-stable"
    steps:
      - name: Checkout Godot 4 project
        uses: actions/checkout@v4

      - name: Setup Java 17
        uses: actions/setup-java@v4
        with:
          distribution: "temurin"
          java-version: "17"

      - name: Setup Android SDK & Build Tools
        uses: android-actions/setup-android@v3

      - name: Generate Android debug.keystore
        run: |
          mkdir -p android-keys
          keytool -genkeypair -v \\
            -keystore android-keys/debug.keystore \\
            -storepass android \\
            -alias androiddebugkey \\
            -keypass android \\
            -keyalg RSA \\
            -keysize 2048 \\
            -validity 10000 \\
            -dname "CN=Android Debug,O=Android,C=US"

      - name: Download Godot 4.3 headless binary & Android export templates
        run: |
          wget -q "https://github.com/godotengine/godot/releases/download/\${GODOT_VERSION}/Godot_v\${GODOT_VERSION}_linux.x86_64.zip" -O godot.zip
          unzip -q godot.zip
          chmod +x "Godot_v\${GODOT_VERSION}_linux.x86_64"
          sudo mv "Godot_v\${GODOT_VERSION}_linux.x86_64" /usr/local/bin/godot

          wget -q "https://github.com/godotengine/godot/releases/download/\${GODOT_VERSION}/Godot_v\${GODOT_VERSION}_export_templates.tpz" -O templates.tpz
          mkdir -p ~/.local/share/godot/export_templates/4.3.stable
          unzip -q templates.tpz -d /tmp/godot_tpl
          mv /tmp/godot_tpl/templates/* ~/.local/share/godot/export_templates/4.3.stable/

      - name: Configure Godot Android SDK & Keystore settings
        run: |
          mkdir -p ~/.config/godot build
          cat <<EOF > ~/.config/godot/editor_settings-4.3.tres
          [gd_resource type="EditorSettings" format=3]
          [resource]
          export/android/android_sdk_path = "\${ANDROID_HOME}"
          export/android/debug_keystore = "\${GITHUB_WORKSPACE}/android-keys/debug.keystore"
          export/android/debug_keystore_user = "androiddebugkey"
          export/android/debug_keystore_pass = "android"
          EOF

      - name: Export Godot 4 Android APK
        run: |
          godot --headless --path . --export-release "Android" "build/app-release.apk"

      - name: Fail loudly if app-release.apk is missing
        run: |
          if [ ! -f "build/app-release.apk" ]; then
            echo "FATAL: build/app-release.apk was not produced by Godot export."
            exit 1
          fi
          cp "build/app-release.apk" "build/${appSlug}.apk"
          ls -lh "build/${appSlug}.apk"

      - name: Publish Godot APK to GitHub Releases
        uses: softprops/action-gh-release@v2
        with:
          tag_name: v1.0.\${{ github.run_number }}
          name: "${appSlug} Godot APK #\${{ github.run_number }}"
          body: "Automated Godot 4.3 Android APK release."
          files: build/${appSlug}.apk
          make_latest: true
`;
}

function buildFlutterApkWorkflow(appSlug: string): string {
  return `name: Build Flutter Android APK

on:
  push:
    branches: ["main"]
  workflow_dispatch:

permissions:
  contents: write

concurrency:
  group: "flutter-apk-\${{ github.ref }}"
  cancel-in-progress: true

jobs:
  build-flutter-apk:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout Flutter project
        uses: actions/checkout@v4

      - name: Setup Java 17
        uses: actions/setup-java@v4
        with:
          distribution: "temurin"
          java-version: "17"

      - name: Setup Flutter stable SDK
        uses: subosito/flutter-action@v2
        with:
          channel: "stable"
          cache: true

      - name: Ensure Android platform folder exists
        run: |
          if [ ! -d android ]; then
            flutter create --platforms=android .
          fi
          flutter pub get

      - name: Build release APK
        run: flutter build apk --release

      - name: Verify real release APK exists
        run: |
          APK_FILE="build/app/outputs/flutter-apk/app-release.apk"
          if [ ! -f "$APK_FILE" ]; then
            echo "FATAL: Flutter release APK missing at $APK_FILE"
            exit 1
          fi
          mkdir -p release-artifacts
          cp "$APK_FILE" "release-artifacts/${appSlug}-release.apk"
          ls -lh "release-artifacts/${appSlug}-release.apk"

      - name: Publish Flutter APK to GitHub Releases
        uses: softprops/action-gh-release@v2
        with:
          tag_name: v1.0.\${{ github.run_number }}
          name: "${appSlug} Flutter APK #\${{ github.run_number }}"
          body: "Automated Flutter Android release APK (Java 17)."
          files: release-artifacts/${appSlug}-release.apk
          make_latest: true
`;
}

function buildUnityApkWorkflow(appSlug: string): string {
  return `name: Build Unity Android APK

on:
  push:
    branches: ["main"]
  workflow_dispatch:

permissions:
  contents: write

concurrency:
  group: "unity-apk-\${{ github.ref }}"
  cancel-in-progress: true

jobs:
  build-unity-apk:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout Unity project
        uses: actions/checkout@v4
        with:
          lfs: true

      - name: Check UNITY_LICENSE secret before building
        env:
          UNITY_LICENSE_VALUE: \${{ secrets.UNITY_LICENSE }}
        run: |
          if [ -z "$UNITY_LICENSE_VALUE" ]; then
            echo "DIAGNOSTIC: Missing GitHub repository secret UNITY_LICENSE."
            echo "Add your Unity .ulf license content under Repo Settings -> Secrets and variables -> Actions -> UNITY_LICENSE and re-run."
            exit 1
          fi

      - name: Build Unity Android APK
        uses: game-ci/unity-builder@v4
        env:
          UNITY_LICENSE: \${{ secrets.UNITY_LICENSE }}
        with:
          targetPlatform: Android
          androidExportType: androidPackage
          buildName: ${appSlug}

      - name: Verify real Unity APK exists
        run: |
          APK_FILE=$(find build/Android -name "*.apk" | head -n 1)
          if [ -z "$APK_FILE" ] || [ ! -f "$APK_FILE" ]; then
            echo "FATAL: Unity Android APK artifact not found under build/Android."
            exit 1
          fi
          mkdir -p release-artifacts
          cp "$APK_FILE" "release-artifacts/${appSlug}-unity.apk"
          ls -lh "release-artifacts/${appSlug}-unity.apk"

      - name: Publish Unity APK to GitHub Releases
        uses: softprops/action-gh-release@v2
        with:
          tag_name: v1.0.\${{ github.run_number }}
          name: "${appSlug} Unity APK #\${{ github.run_number }}"
          body: "Automated Unity Android APK built via game-ci/unity-builder@v4."
          files: release-artifacts/${appSlug}-unity.apk
          make_latest: true
`;
}

// ============================================================================
// PIN-LOCKED OWNER ADMIN WEB PANEL (docs/index.html)
// Strictly isolated: ONLY embeds Apps Supabase public URL + anonKey (NEVER PAT/Studio secrets!)
// ============================================================================

function escapeJsString(value: string): string {
  return JSON.stringify(value ?? '')
    .replace(/</g, '\\u003c')
    .replace(/>/g, '\\u003e');
}

function buildOwnerAdminHtml(params: {
  appName: string;
  appSlug: string;
  engine: string;
  repoOwner: string;
  repoName: string;
  appsSupabaseUrl: string;
  appsSupabaseAnonKey: string;
}): string {
  const releasesUrl = `https://github.com/${params.repoOwner}/${params.repoName}/releases/latest`;
  const repoUrl = `https://github.com/${params.repoOwner}/${params.repoName}`;

  return `<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>${params.appName.replace(/</g, '&lt;')} · Owner Admin</title>
  <style>
    :root { color-scheme: dark; }
    * { box-sizing: border-box; }
    body {
      margin: 0;
      min-height: 100vh;
      font-family: system-ui, -apple-system, Segoe UI, Roboto, sans-serif;
      background: radial-gradient(circle at 20% 0%, #0d1d3a 0%, #050811 60%);
      color: #e2e8f0;
      padding: 20px 16px 40px;
    }
    .wrap { max-width: 780px; margin: 0 auto; display: grid; gap: 16px; }
    .card {
      background: rgba(11, 18, 37, 0.92);
      border: 1px solid rgba(56, 189, 248, 0.28);
      border-radius: 16px;
      padding: 18px;
      box-shadow: 0 10px 34px rgba(0, 0, 0, 0.45);
    }
    h1, h2 { margin: 0 0 6px; font-weight: 700; letter-spacing: -0.01em; }
    h1 { font-size: 20px; color: #f8fafc; }
    h2 { font-size: 15px; color: #bae6fd; }
    p { margin: 0; font-size: 13px; color: #94a3b8; line-height: 1.5; }
    .row { display: flex; flex-wrap: wrap; gap: 10px; margin-top: 14px; }
    .btn {
      display: inline-flex; align-items: center; justify-content: center;
      min-height: 42px; padding: 0 16px; border-radius: 10px; font-size: 13px;
      font-weight: 600; text-decoration: none; cursor: pointer;
      border: 1px solid rgba(56, 189, 248, 0.4);
      background: rgba(14, 165, 233, 0.18); color: #e0f2fe;
    }
    .btn.primary { background: #10b981; border-color: #34d399; color: #041310; }
    .btn.secondary { background: rgba(139, 92, 246, 0.2); border-color: rgba(167, 139, 250, 0.45); color: #ede9fe; }
    label { display: grid; gap: 6px; font-size: 12px; color: #cbd5e1; margin-top: 12px; }
    input, select {
      height: 42px; border-radius: 10px; border: 1px solid rgba(148, 163, 184, 0.25);
      background: #050914; color: #f8fafc; padding: 0 12px; font-size: 13px; width: 100%;
    }
    .grid2 { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 12px; }
    .status { margin-top: 12px; font-family: ui-monospace, monospace; font-size: 12px; color: #67e8f9; min-height: 18px; }
    .hidden { display: none !important; }
  </style>
</head>
<body>
  <div class="wrap">
    <div class="card">
      <h1 id="app-title"></h1>
      <p id="app-meta"></p>
      <div class="row">
        <a class="btn primary" href="./play.html">Open Live Web Test</a>
        <a class="btn" href="${releasesUrl}" target="_blank" rel="noreferrer">Download Latest APK</a>
        <a class="btn secondary" href="${repoUrl}" target="_blank" rel="noreferrer">GitHub Repository</a>
      </div>
    </div>

    <div id="pin-gate" class="card">
      <h2 id="pin-title">Owner Admin PIN Lock</h2>
      <p id="pin-subtitle">Enter your 4–8 digit Owner PIN to unlock live remote controls for this exported APK.</p>
      <label>
        <span>Owner PIN</span>
        <input id="pin-input" type="password" inputmode="numeric" maxlength="12" placeholder="Enter PIN..." autocomplete="off" />
      </label>
      <div class="row">
        <button id="pin-submit" class="btn primary" type="button">Unlock Owner Panel</button>
      </div>
      <div id="pin-status" class="status"></div>
    </div>

    <div id="admin-panel" class="card hidden">
      <h2>Live Remote Controls (Apps Supabase · No APK Rebuild Needed)</h2>
      <p>Changes pushed here update your exported APK live via the isolated apps_config table.</p>

      <label>
        <span>Live Remote Banner Text</span>
        <input id="banner-text" type="text" placeholder="Festival Offer: Flat 20% OFF today!" />
      </label>

      <div class="grid2">
        <label>
          <span>Discount % (0–95)</span>
          <input id="discount-pct" type="number" min="0" max="95" value="0" />
        </label>
        <label>
          <span>Game Speed Multiplier (0.25–3.0)</span>
          <input id="game-speed" type="number" min="0.25" max="3" step="0.05" value="1.0" />
        </label>
        <label>
          <span>Difficulty Mode</span>
          <select id="difficulty">
            <option value="easy">Easy</option>
            <option value="normal" selected>Normal</option>
            <option value="hard">Hard</option>
          </select>
        </label>
      </div>

      <div class="row">
        <button id="push-config" class="btn primary" type="button">Push Live Remote Update</button>
        <button id="reload-config" class="btn" type="button">Reload From Apps Supabase</button>
        <button id="lock-panel" class="btn secondary" type="button">Lock Panel</button>
      </div>
      <div id="admin-status" class="status"></div>
    </div>
  </div>

  <script>
    (function () {
      const APP_NAME = ${escapeJsString(params.appName)};
      const APP_SLUG = ${escapeJsString(params.appSlug)};
      const ENGINE = ${escapeJsString(params.engine)};
      const APPS_SB_URL = ${escapeJsString(params.appsSupabaseUrl.trim().replace(/\/+$/, ''))};
      const APPS_SB_ANON = ${escapeJsString(params.appsSupabaseAnonKey.trim())};
      const PIN_KEY = 'owner_pin_hash_' + APP_SLUG;

      document.getElementById('app-title').textContent = APP_NAME + ' · Owner Admin';
      document.getElementById('app-meta').textContent = 'Slug: ' + APP_SLUG + ' · Engine: ' + ENGINE + ' · Dedicated Apps Supabase';

      const pinGate = document.getElementById('pin-gate');
      const adminPanel = document.getElementById('admin-panel');
      const pinTitle = document.getElementById('pin-title');
      const pinSubtitle = document.getElementById('pin-subtitle');
      const pinInput = document.getElementById('pin-input');
      const pinSubmit = document.getElementById('pin-submit');
      const pinStatus = document.getElementById('pin-status');
      const adminStatus = document.getElementById('admin-status');

      let storedHash = localStorage.getItem(PIN_KEY) || '';

      async function hashPin(pin) {
        const enc = new TextEncoder().encode('sarfealam-owner-v1::' + APP_SLUG + '::' + pin);
        const buf = await crypto.subtle.digest('SHA-256', enc);
        return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, '0')).join('');
      }

      function refreshPinUi() {
        if (!storedHash) {
          pinTitle.textContent = 'First-Run Owner PIN Setup';
          pinSubtitle.textContent = 'Claim this Owner Admin Panel by creating your 4–12 digit PIN (stored as SHA-256 hash).';
          pinSubmit.textContent = 'Set Owner PIN & Unlock';
        } else {
          pinTitle.textContent = 'Owner Admin PIN Lock';
          pinSubtitle.textContent = 'Enter your Owner PIN to unlock live remote APK controls.';
          pinSubmit.textContent = 'Unlock Owner Panel';
        }
      }

      async function loadRemoteConfig() {
        if (!APPS_SB_URL || !APPS_SB_ANON) {
          adminStatus.textContent = 'Apps Supabase credentials were not configured during export. Set them in Studio Secrets and re-export.';
          return;
        }
        adminStatus.textContent = 'Loading live config from Apps Supabase...';
        try {
          const res = await fetch(APPS_SB_URL + '/rest/v1/apps_config?app_slug=eq.' + encodeURIComponent(APP_SLUG) + '&select=*&limit=1', {
            headers: { apikey: APPS_SB_ANON, Authorization: 'Bearer ' + APPS_SB_ANON, Accept: 'application/json' }
          });
          if (!res.ok) throw new Error('HTTP ' + res.status);
          const rows = await res.json();
          if (rows && rows[0]) {
            const row = rows[0];
            document.getElementById('banner-text').value = row.banner_text || '';
            document.getElementById('discount-pct').value = Number(row.discount_percent || 0);
            document.getElementById('game-speed').value = Number(row.game_speed || 1);
            document.getElementById('difficulty').value = row.difficulty || 'normal';
            if (row.owner_pin_hash && !storedHash) {
              storedHash = row.owner_pin_hash;
              localStorage.setItem(PIN_KEY, storedHash);
              refreshPinUi();
            }
            adminStatus.textContent = 'Synced live config (' + new Date().toLocaleTimeString() + ').';
          } else {
            adminStatus.textContent = 'No remote record yet — save below to initialize apps_config.';
          }
        } catch (err) {
          adminStatus.textContent = 'Could not load Apps Supabase: ' + (err && err.message ? err.message : String(err));
        }
      }

      async function saveRemoteConfig() {
        if (!APPS_SB_URL || !APPS_SB_ANON) {
          adminStatus.textContent = 'Apps Supabase is not configured.';
          return;
        }
        adminStatus.textContent = 'Pushing live update to Apps Supabase...';
        const bannerText = document.getElementById('banner-text').value.trim();
        const discountPercent = Math.max(0, Math.min(95, parseInt(document.getElementById('discount-pct').value, 10) || 0));
        const gameSpeed = Math.max(0.25, Math.min(3, parseFloat(document.getElementById('game-speed').value) || 1));
        const difficulty = document.getElementById('difficulty').value;

        try {
          const res = await fetch(APPS_SB_URL + '/rest/v1/apps_config?on_conflict=app_slug', {
            method: 'POST',
            headers: {
              apikey: APPS_SB_ANON,
              Authorization: 'Bearer ' + APPS_SB_ANON,
              'Content-Type': 'application/json',
              Prefer: 'resolution=merge-duplicates'
            },
            body: JSON.stringify({
              app_slug: APP_SLUG,
              app_name: APP_NAME,
              engine: ENGINE,
              version_name: '1.0.0',
              banner_text: bannerText,
              discount_percent: discountPercent,
              game_speed: gameSpeed,
              difficulty: difficulty,
              owner_pin_hash: storedHash,
              feature_flags: { bannerText, discountPercent, gameSpeed, difficulty },
              updated_at: new Date().toISOString()
            })
          });
          if (!res.ok) throw new Error('HTTP ' + res.status);
          adminStatus.textContent = 'Live remote update published successfully! Exported APKs will reflect changes immediately.';
        } catch (err) {
          adminStatus.textContent = 'Save failed: ' + (err && err.message ? err.message : String(err));
        }
      }

      pinSubmit.addEventListener('click', async function () {
        const pin = pinInput.value.trim();
        if (pin.length < 4) {
          pinStatus.textContent = 'PIN must be at least 4 characters.';
          return;
        }
        const hashed = await hashPin(pin);
        if (!storedHash) {
          storedHash = hashed;
          localStorage.setItem(PIN_KEY, storedHash);
          pinStatus.textContent = 'Owner PIN set.';
          pinGate.classList.add('hidden');
          adminPanel.classList.remove('hidden');
          await loadRemoteConfig();
          return;
        }
        if (hashed === storedHash) {
          pinStatus.textContent = '';
          pinInput.value = '';
          pinGate.classList.add('hidden');
          adminPanel.classList.remove('hidden');
          await loadRemoteConfig();
        } else {
          pinStatus.textContent = 'Incorrect PIN. Access denied.';
        }
      });

      document.getElementById('push-config').addEventListener('click', saveRemoteConfig);
      document.getElementById('reload-config').addEventListener('click', loadRemoteConfig);
      document.getElementById('lock-panel').addEventListener('click', function () {
        adminPanel.classList.add('hidden');
        pinGate.classList.remove('hidden');
        pinInput.value = '';
        refreshPinUi();
      });

      refreshPinUi();
      // Check if an existing remote owner_pin_hash is present in Apps Supabase
      if (!storedHash && APPS_SB_URL && APPS_SB_ANON) {
        fetch(APPS_SB_URL + '/rest/v1/apps_config?app_slug=eq.' + encodeURIComponent(APP_SLUG) + '&select=owner_pin_hash&limit=1', {
          headers: { apikey: APPS_SB_ANON, Authorization: 'Bearer ' + APPS_SB_ANON, Accept: 'application/json' }
        })
          .then((r) => (r.ok ? r.json() : []))
          .then((rows) => {
            if (rows && rows[0] && rows[0].owner_pin_hash) {
              storedHash = rows[0].owner_pin_hash;
              localStorage.setItem(PIN_KEY, storedHash);
              refreshPinUi();
            }
          })
          .catch(() => {});
      }
    })();
  </script>
</body>
</html>
`;
}

// ============================================================================
// BUILD COMPLETE ENGINE-AWARE EXPORT BUNDLE (FOR ATOMIC PUSH & LOCAL ZIP)
// ============================================================================

export function buildExportBundle(
  state: WorldState,
  secrets: SecretsConfig,
  repoOwner: string,
  repoName: string
): AtomicExportFile[] {
  const effectiveEngine = resolveEffectiveEngine(state.selectedEngine);
  const appSlug = repoName.toLowerCase();
  const appName = (state.activePrompt || repoName).slice(0, 48);
  const fileMap = new Map<string, string>();

  // 1. Add all LLM-generated files from Phase 3
  for (const f of state.generatedFiles) {
    const cleanPath = f.path.replace(/^\/+/, '');
    if (cleanPath && f.content) {
      fileMap.set(cleanPath, f.content);
    }
  }

  // Ensure playable HTML is available at index.html if Capacitor/Web
  const playableHtml =
    state.previewHtml ||
    fileMap.get('index.html') ||
    `<!doctype html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${appName}</title></head><body style="background:#050811;color:#e2e8f0;font-family:sans-serif;padding:24px;"><h1>${appName}</h1></body></html>`;

  // 2. Engine-specific build scaffolds + Real APK Workflows (NO `|| echo`)
  if (effectiveEngine === 'Capacitor 3D/App') {
    if (!fileMap.has('index.html')) {
      fileMap.set('index.html', playableHtml);
    }
    if (!fileMap.has('package.json')) {
      fileMap.set(
        'package.json',
        JSON.stringify(
          {
            name: appSlug,
            private: true,
            version: '1.0.0',
            type: 'module',
            scripts: {
              dev: 'vite',
              build: 'vite build',
              preview: 'vite preview',
            },
            dependencies: {
              '@capacitor/android': '^6.2.0',
              '@capacitor/cli': '^6.2.0',
              '@capacitor/core': '^6.2.0',
            },
            devDependencies: {
              vite: '^6.0.0',
            },
          },
          null,
          2
        )
      );
    } else {
      // Ensure Capacitor 6 packages are present in package.json so npx cap add android never fails
      try {
        const pkg = JSON.parse(fileMap.get('package.json') || '{}') as {
          dependencies?: Record<string, string>;
          devDependencies?: Record<string, string>;
          scripts?: Record<string, string>;
        };
        pkg.dependencies = {
          '@capacitor/core': '^6.2.0',
          '@capacitor/android': '^6.2.0',
          '@capacitor/cli': '^6.2.0',
          ...(pkg.dependencies ?? {}),
        };
        pkg.devDependencies = {
          vite: '^6.0.0',
          ...(pkg.devDependencies ?? {}),
        };
        pkg.scripts = {
          dev: 'vite',
          build: 'vite build',
          ...(pkg.scripts ?? {}),
        };
        fileMap.set('package.json', JSON.stringify(pkg, null, 2));
      } catch {
        // leave as-is if non-JSON
      }
    }

    if (!fileMap.has('vite.config.ts') && !fileMap.has('vite.config.js')) {
      fileMap.set(
        'vite.config.ts',
        `import { defineConfig } from 'vite';\n\nexport default defineConfig({\n  base: './',\n  build: {\n    outDir: 'dist',\n  },\n});\n`
      );
    }

    if (!fileMap.has('capacitor.config.json')) {
      fileMap.set(
        'capacitor.config.json',
        JSON.stringify(
          {
            appId: `com.sarfealam.${appSlug.replace(/[^a-z0-9]/g, '').slice(0, 20) || 'app'}`,
            appName,
            webDir: 'dist',
            plugins: {
              CapacitorHttp: {
                enabled: true,
              },
            },
          },
          null,
          2
        )
      );
    }

    fileMap.set('.github/workflows/build-apk.yml', buildCapacitorApkWorkflow(appSlug));
  } else if (effectiveEngine === 'Godot 4') {
    if (!fileMap.has('export_presets.cfg')) {
      fileMap.set(
        'export_presets.cfg',
        `[preset.0]\nname="Android"\nplatform="Android"\nrunnable=true\nexport_filter="all_resources"\nexport_path="build/app-release.apk"\n\n[preset.0.options]\npackage/unique_name="com.sarfealam.${appSlug.replace(/[^a-z0-9]/g, '').slice(0, 20) || 'godot'}"\npackage/name="${appName.replace(/"/g, '')}"\narchitectures/arm64-v8a=true\n`
      );
    }
    fileMap.set('.github/workflows/build-godot-apk.yml', buildGodotApkWorkflow(appSlug));
  } else if (effectiveEngine === 'Flutter') {
    if (!fileMap.has('pubspec.yaml')) {
      fileMap.set(
        'pubspec.yaml',
        `name: ${appSlug.replace(/[^a-z0-9_]/g, '_')}\ndescription: Generated by Sarfealam Auto-Studio\npublish_to: 'none'\nversion: 1.0.0+1\nenvironment:\n  sdk: '>=3.3.0 <4.0.0'\ndependencies:\n  flutter:\n    sdk: flutter\nflutter:\n  uses-material-design: true\n`
      );
    }
    fileMap.set('.github/workflows/build-flutter-apk.yml', buildFlutterApkWorkflow(appSlug));
  } else if (effectiveEngine === 'Unity') {
    if (!fileMap.has('ProjectSettings/ProjectVersion.txt')) {
      fileMap.set('ProjectSettings/ProjectVersion.txt', 'm_EditorVersion: 2022.3.42f1\n');
    }
    fileMap.set('.github/workflows/build-unity-apk.yml', buildUnityApkWorkflow(appSlug));
  }

  // 3. Always include GitHub Pages Deploy Workflow with concurrency lock + Owner Admin + Live Playable Test
  fileMap.set('.github/workflows/deploy-admin.yml', buildDeployAdminWorkflow());
  fileMap.set(
    'docs/index.html',
    buildOwnerAdminHtml({
      appName,
      appSlug,
      engine: effectiveEngine,
      repoOwner,
      repoName,
      appsSupabaseUrl: secrets.appsSupabase.url,
      appsSupabaseAnonKey: secrets.appsSupabase.anonKey,
    })
  );
  fileMap.set('docs/play.html', playableHtml);

  // 4. Clean README with direct links
  if (!fileMap.has('README.md')) {
    fileMap.set(
      'README.md',
      `# ${appName}\n\n- **Engine:** ${effectiveEngine}\n- **Live Web Test:** https://${repoOwner}.github.io/${repoName}/play.html\n- **Owner Admin Panel (PIN-Locked):** https://${repoOwner}.github.io/${repoName}/\n- **Latest Android APK:** https://github.com/${repoOwner}/${repoName}/releases/latest\n`
    );
  }

  return Array.from(fileMap.entries()).map(([path, content]) => ({ path, content }));
}

// ============================================================================
// ATOMIC 1-COMMIT GITHUB GIT TREES API PUSHER (NEVER FILE-BY-FILE CONTENTS API)
// ============================================================================

async function ensureRepositoryReady(
  owner: string,
  repoName: string,
  pat: string,
  description: string
): Promise<{ ok: boolean; defaultBranch: string; error?: string }> {
  const checkRes = await fetch(`${GITHUB_API}/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repoName)}`, {
    method: 'GET',
    headers: ghHeaders(pat),
  });

  if (checkRes.ok) {
    const data = (await checkRes.json()) as { default_branch?: string };
    return { ok: true, defaultBranch: data.default_branch || 'main' };
  }

  if (checkRes.status !== 404) {
    const errText = await checkRes.text().catch(() => '');
    return {
      ok: false,
      defaultBranch: 'main',
      error: `GitHub repo check failed (HTTP ${checkRes.status}): ${errText.slice(0, 180)}`,
    };
  }

  // Create repository with auto_init: true so heads/main exists cleanly
  const createRes = await fetch(`${GITHUB_API}/user/repos`, {
    method: 'POST',
    headers: ghHeaders(pat),
    body: JSON.stringify({
      name: repoName,
      description: description.slice(0, 160),
      private: false,
      auto_init: true,
    }),
  });

  if (!createRes.ok) {
    const errText = await createRes.text().catch(() => '');
    return {
      ok: false,
      defaultBranch: 'main',
      error: `Could not create repo "${repoName}" (HTTP ${createRes.status}): ${errText.slice(0, 200)}`,
    };
  }

  const created = (await createRes.json()) as { default_branch?: string };
  const branch = created.default_branch || 'main';

  // Wait briefly for GitHub auto_init commit ref to become readable
  for (let attempt = 0; attempt < 6; attempt++) {
    await new Promise((r) => setTimeout(r, 900));
    const refRes = await fetch(
      `${GITHUB_API}/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repoName)}/git/ref/heads/${encodeURIComponent(branch)}`,
      { method: 'GET', headers: ghHeaders(pat) }
    );
    if (refRes.ok) {
      return { ok: true, defaultBranch: branch };
    }
  }

  return { ok: true, defaultBranch: branch };
}

async function enableGitHubPagesMainDocs(
  owner: string,
  repoName: string,
  branch: string,
  pat: string
): Promise<{ enabled: boolean; note: string }> {
  const pagesEndpoint = `${GITHUB_API}/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repoName)}/pages`;
  const payload = {
    source: {
      branch,
      path: '/docs',
    },
  };

  try {
    const res = await fetch(pagesEndpoint, {
      method: 'POST',
      headers: ghHeaders(pat),
      body: JSON.stringify(payload),
    });

    if (res.ok || res.status === 201) {
      return { enabled: true, note: `GitHub Pages enabled on ${branch} /docs.` };
    }

    if (res.status === 409) {
      // Already enabled — update source to ensure main /docs
      const putRes = await fetch(pagesEndpoint, {
        method: 'PUT',
        headers: ghHeaders(pat),
        body: JSON.stringify(payload),
      });
      return {
        enabled: true,
        note: putRes.ok
          ? `GitHub Pages verified on ${branch} /docs.`
          : 'GitHub Pages already active.',
      };
    }

    const errText = await res.text().catch(() => '');
    return {
      enabled: false,
      note: `Pages API HTTP ${res.status}: ${errText.slice(0, 120)}`,
    };
  } catch (err) {
    return {
      enabled: false,
      note: err instanceof Error ? err.message : 'Pages enable request failed.',
    };
  }
}

export async function pushAtomicGitTreeCommit(params: {
  owner: string;
  repoName: string;
  branch?: string;
  pat: string;
  files: AtomicExportFile[];
  commitMessage: string;
}): Promise<{ ok: boolean; commitSha?: string; branch: string; error?: string }> {
  const { owner, repoName, pat, files, commitMessage } = params;
  const branch = params.branch || 'main';
  const baseRepoApi = `${GITHUB_API}/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repoName)}`;

  // 1. Read current HEAD ref
  const refRes = await fetch(`${baseRepoApi}/git/ref/heads/${encodeURIComponent(branch)}`, {
    method: 'GET',
    headers: ghHeaders(pat),
  });
  if (!refRes.ok) {
    const errText = await refRes.text().catch(() => '');
    return {
      ok: false,
      branch,
      error: `Failed to read heads/${branch} (HTTP ${refRes.status}): ${errText.slice(0, 160)}`,
    };
  }
  const refData = (await refRes.json()) as { object: { sha: string } };
  const baseCommitSha = refData.object.sha;

  // 2. Read base commit to get base_tree SHA
  const commitRes = await fetch(`${baseRepoApi}/git/commits/${baseCommitSha}`, {
    method: 'GET',
    headers: ghHeaders(pat),
  });
  if (!commitRes.ok) {
    const errText = await commitRes.text().catch(() => '');
    return {
      ok: false,
      branch,
      error: `Failed to read base commit (HTTP ${commitRes.status}): ${errText.slice(0, 160)}`,
    };
  }
  const commitData = (await commitRes.json()) as { tree: { sha: string } };
  const baseTreeSha = commitData.tree.sha;

  // 3. Create Git blobs in small parallel batches (POST /git/blobs)
  const treeEntries: Array<{
    path: string;
    mode: '100644';
    type: 'blob';
    sha: string;
  }> = [];

  const batchSize = 5;
  for (let i = 0; i < files.length; i += batchSize) {
    const batch = files.slice(i, i + batchSize);
    const createdBlobs = await Promise.all(
      batch.map(async (file) => {
        const blobRes = await fetch(`${baseRepoApi}/git/blobs`, {
          method: 'POST',
          headers: ghHeaders(pat),
          body: JSON.stringify({
            content: file.content,
            encoding: 'utf-8',
          }),
        });
        if (!blobRes.ok) {
          const errText = await blobRes.text().catch(() => '');
          throw new Error(`Blob failed for ${file.path} (HTTP ${blobRes.status}): ${errText.slice(0, 120)}`);
        }
        const blobData = (await blobRes.json()) as { sha: string };
        return {
          path: file.path.replace(/^\/+/, ''),
          mode: '100644' as const,
          type: 'blob' as const,
          sha: blobData.sha,
        };
      })
    );
    treeEntries.push(...createdBlobs);
  }

  // 4. Create single atomic Git Tree (POST /git/trees)
  const treeRes = await fetch(`${baseRepoApi}/git/trees`, {
    method: 'POST',
    headers: ghHeaders(pat),
    body: JSON.stringify({
      base_tree: baseTreeSha,
      tree: treeEntries,
    }),
  });
  if (!treeRes.ok) {
    const errText = await treeRes.text().catch(() => '');
    return {
      ok: false,
      branch,
      error: `POST /git/trees failed (HTTP ${treeRes.status}): ${errText.slice(0, 180)}`,
    };
  }
  const treeData = (await treeRes.json()) as { sha: string };

  // 5. Create single Commit (POST /git/commits)
  const newCommitRes = await fetch(`${baseRepoApi}/git/commits`, {
    method: 'POST',
    headers: ghHeaders(pat),
    body: JSON.stringify({
      message: commitMessage,
      tree: treeData.sha,
      parents: [baseCommitSha],
    }),
  });
  if (!newCommitRes.ok) {
    const errText = await newCommitRes.text().catch(() => '');
    return {
      ok: false,
      branch,
      error: `POST /git/commits failed (HTTP ${newCommitRes.status}): ${errText.slice(0, 180)}`,
    };
  }
  const newCommitData = (await newCommitRes.json()) as { sha: string };

  // 6. Move branch ref atomically (PATCH /git/refs/heads/main)
  const patchRefRes = await fetch(`${baseRepoApi}/git/refs/heads/${encodeURIComponent(branch)}`, {
    method: 'PATCH',
    headers: ghHeaders(pat),
    body: JSON.stringify({
      sha: newCommitData.sha,
      force: false,
    }),
  });
  if (!patchRefRes.ok) {
    const errText = await patchRefRes.text().catch(() => '');
    return {
      ok: false,
      branch,
      error: `PATCH /git/refs/heads/${branch} failed (HTTP ${patchRefRes.status}): ${errText.slice(0, 180)}`,
    };
  }

  return { ok: true, commitSha: newCommitData.sha, branch };
}

export async function exportProjectAtomicallyToGitHub(
  state: WorldState,
  secrets: SecretsConfig,
  repoNameOverride?: string
): Promise<AtomicPushResult> {
  const owner = secrets.githubUsername.trim();
  const pat = secrets.githubPat.trim();

  if (!owner || !pat) {
    return {
      ok: false,
      repoOwner: owner,
      repoName: '',
      repoFullName: '',
      fileCount: 0,
      error:
        'GitHub Username and PAT (with repo + workflow scopes) are required in Secrets Vault to push & build cloud APKs.',
    };
  }

  const repoName = sanitizeRepoName(repoNameOverride || state.activePrompt || 'studio-build');
  const repoFullName = `${owner}/${repoName}`;

  studioBus.emit('bot:progress', {
    botId: 'github-heal',
    status: 'active',
    task: `Preparing ${repoName}`,
    progress: 18,
  });

  // Step 1: Ensure target repo exists
  const repoReady = await ensureRepositoryReady(
    owner,
    repoName,
    pat,
    `${state.selectedEngine} project built with Sarfealam Auto-Studio`
  );
  if (!repoReady.ok) {
    studioBus.emit('bot:progress', {
      botId: 'github-heal',
      status: 'error',
      task: 'Repo init failed',
      progress: 100,
    });
    return {
      ok: false,
      repoOwner: owner,
      repoName,
      repoFullName,
      fileCount: 0,
      error: repoReady.error,
    };
  }

  // Step 2: Assemble complete bundle (app files + real APK workflow + deploy-admin.yml + docs/index.html + docs/play.html)
  const bundle = buildExportBundle(state, secrets, owner, repoName);

  studioBus.emit('bot:progress', {
    botId: 'github-heal',
    status: 'active',
    task: `Atomic 1-commit push (${bundle.length} files)`,
    progress: 52,
  });

  // Step 3: Execute ONE SINGLE ATOMIC COMMIT via Git Trees API
  let commitRes: { ok: boolean; commitSha?: string; branch: string; error?: string };
  try {
    commitRes = await pushAtomicGitTreeCommit({
      owner,
      repoName,
      branch: repoReady.defaultBranch,
      pat,
      files: bundle,
      commitMessage: `feat: atomic Sarfealam Auto-Studio release (${resolveEffectiveEngine(state.selectedEngine)}, ${bundle.length} files)`,
    });
  } catch (err) {
    commitRes = {
      ok: false,
      branch: repoReady.defaultBranch,
      error: err instanceof Error ? err.message : 'Atomic Git Trees push failed.',
    };
  }

  if (!commitRes.ok || !commitRes.commitSha) {
    studioBus.emit('bot:progress', {
      botId: 'github-heal',
      status: 'error',
      task: 'Atomic push failed',
      progress: 100,
    });
    return {
      ok: false,
      repoOwner: owner,
      repoName,
      repoFullName,
      fileCount: bundle.length,
      error: commitRes.error || 'Atomic push failed.',
    };
  }

  studioBus.emit('bot:progress', {
    botId: 'github-heal',
    status: 'active',
    task: 'Enabling GitHub Pages (/docs)',
    progress: 82,
  });

  // Step 4: Automatically enable GitHub Pages on main /docs
  const pagesRes = await enableGitHubPagesMainDocs(owner, repoName, commitRes.branch, pat);

  const pagesUrl = `https://${owner}.github.io/${repoName}/`;
  const links: ReleaseLinks = {
    repoFullName,
    repoUrl: `https://github.com/${repoFullName}`,
    actionsUrl: `https://github.com/${repoFullName}/actions`,
    pagesUrl,
    liveTestUrl: `${pagesUrl}play.html`,
    adminPanelUrl: pagesUrl,
    releasesUrl: `https://github.com/${repoFullName}/releases/latest`,
    updatedAt: Date.now(),
  };

  studioBus.emit('bot:progress', {
    botId: 'github-heal',
    status: 'active',
    task: 'Polling Actions APK build',
    progress: 90,
  });

  return {
    ok: true,
    repoOwner: owner,
    repoName,
    repoFullName,
    commitSha: commitRes.commitSha,
    links,
    pagesEnabled: pagesRes.enabled,
    pagesNote: pagesRes.note,
    fileCount: bundle.length,
  };
}

// ============================================================================
// 1-TAP LOCAL ZIP DOWNLOAD VIA JSZIP
// ============================================================================

export async function downloadLocalProjectZip(
  state: WorldState,
  secrets: SecretsConfig,
  repoNameOverride?: string
): Promise<{ ok: boolean; fileName: string; fileCount: number; error?: string }> {
  try {
    const owner = secrets.githubUsername.trim() || 'sarfealam-owner';
    const repoName = sanitizeRepoName(repoNameOverride || state.activePrompt || 'studio-project');
    const bundle = buildExportBundle(state, secrets, owner, repoName);

    const zip = new JSZip();
    for (const file of bundle) {
      zip.file(file.path, file.content);
    }

    const blob = await zip.generateAsync({ type: 'blob' });
    const url = URL.createObjectURL(blob);
    const fileName = `${repoName}.zip`;
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = fileName;
    document.body.appendChild(anchor);
    anchor.click();
    document.body.removeChild(anchor);
    setTimeout(() => URL.revokeObjectURL(url), 5000);

    return { ok: true, fileName, fileCount: bundle.length };
  } catch (err) {
    return {
      ok: false,
      fileName: '',
      fileCount: 0,
      error: err instanceof Error ? err.message : 'ZIP packaging failed.',
    };
  }
}

export function mergeFilesIntoGeneratedList(
  existing: GeneratedFile[],
  patches: AtomicExportFile[]
): GeneratedFile[] {
  const map = new Map<string, GeneratedFile>();
  for (const f of existing) {
    map.set(f.path.replace(/^\/+/, ''), f);
  }
  const now = Date.now();
  for (const p of patches) {
    const clean = p.path.replace(/^\/+/, '');
    const ext = clean.split('.').pop() || 'txt';
    map.set(clean, {
      path: clean,
      language: ext,
      content: p.content,
      updatedAt: now,
    });
  }
  return Array.from(map.values());
}
