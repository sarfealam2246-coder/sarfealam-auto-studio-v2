import { useState } from 'react';
import {
  Check,
  Copy,
  Database,
  Eye,
  EyeOff,
  GitBranch,
  KeyRound,
  Loader2,
  ShieldCheck,
  Sparkles,
  X,
} from 'lucide-react';
import { AI_PROVIDERS, testGitHubPat, testProviderKey } from '../services/aiRouter';
import {
  APPS_SUPABASE_SQL,
  detectKeyProvider,
  STUDIO_SUPABASE_SQL,
  testSupabaseEndpoint,
} from '../services/storageService';
import type { AIProviderId, ProviderTestResult, SecretsConfig } from '../types/studio';

interface SecretsPanelProps {
  secrets: SecretsConfig;
  onSaveSecrets: (next: SecretsConfig) => void;
  onClose: () => void;
}

const PROVIDER_ORDER: AIProviderId[] = ['gemini', 'groq', 'nvidia', 'openrouter', 'cohere'];

export function SecretsPanel({ secrets, onSaveSecrets, onClose }: SecretsPanelProps) {
  const [draft, setDraft] = useState<SecretsConfig>(() => structuredClone(secrets));
  const [visibleKeys, setVisibleKeys] = useState<Record<string, boolean>>({});
  const [testingProvider, setTestingProvider] = useState<AIProviderId | null>(null);
  const [providerResults, setProviderResults] = useState<
    Partial<Record<AIProviderId, ProviderTestResult>>
  >({});
  const [autoDetectNotice, setAutoDetectNotice] = useState<string | null>(null);

  const [testingGithub, setTestingGithub] = useState(false);
  const [githubResult, setGithubResult] = useState<{
    ok: boolean;
    httpStatus: number;
    message: string;
  } | null>(null);

  const [testingStudioSb, setTestingStudioSb] = useState(false);
  const [studioSbResult, setStudioSbResult] = useState<{
    ok: boolean;
    httpStatus: number;
    message: string;
  } | null>(null);

  const [testingAppsSb, setTestingAppsSb] = useState(false);
  const [appsSbResult, setAppsSbResult] = useState<{
    ok: boolean;
    httpStatus: number;
    message: string;
  } | null>(null);

  const [copiedWhich, setCopiedWhich] = useState<'studio' | 'apps' | null>(null);
  const [savedBanner, setSavedBanner] = useState(false);

  function commitDraft(next: SecretsConfig) {
    setDraft(next);
    onSaveSecrets(next);
    setSavedBanner(true);
    setTimeout(() => setSavedBanner(false), 1800);
  }

  function handleKeyInput(targetProvider: AIProviderId, rawValue: string) {
    const trimmed = rawValue.trim();
    const detected = detectKeyProvider(trimmed);

    // Smart Auto-Detect routing if user pastes a key belonging to another provider
    if (detected && detected !== targetProvider && trimmed.length > 16) {
      const next: SecretsConfig = {
        ...draft,
        apiKeys: {
          ...draft.apiKeys,
          [detected]: trimmed,
        },
      };
      setAutoDetectNotice(
        `Auto-detected ${AI_PROVIDERS[detected].label} key and routed it to ${AI_PROVIDERS[detected].label}.`
      );
      commitDraft(next);
      return;
    }

    setAutoDetectNotice(
      detected
        ? `Auto-detected valid ${AI_PROVIDERS[detected].label} key format.`
        : null
    );
    const next: SecretsConfig = {
      ...draft,
      apiKeys: {
        ...draft.apiKeys,
        [targetProvider]: rawValue,
      },
    };
    commitDraft(next);
  }

  async function handleTestProvider(provider: AIProviderId) {
    setTestingProvider(provider);
    onSaveSecrets(draft);
    const result = await testProviderKey(provider, draft.apiKeys[provider]);
    setProviderResults((prev) => ({ ...prev, [provider]: result }));
    setTestingProvider(null);
  }

  async function handleTestGithub() {
    setTestingGithub(true);
    onSaveSecrets(draft);
    const res = await testGitHubPat(draft.githubUsername, draft.githubPat);
    setGithubResult({ ok: res.ok, httpStatus: res.httpStatus, message: res.message });
    setTestingGithub(false);
  }

  async function handleSaveAndTestSupabase(which: 'studio' | 'apps') {
    onSaveSecrets(draft);
    if (which === 'studio') {
      setTestingStudioSb(true);
      const res = await testSupabaseEndpoint(draft.studioSupabase, 'studio_state');
      setStudioSbResult(res);
      const updated: SecretsConfig = {
        ...draft,
        studioSupabase: {
          ...draft.studioSupabase,
          lastStatus: res.httpStatus,
          lastMessage: res.message,
          testedAt: Date.now(),
        },
      };
      commitDraft(updated);
      setTestingStudioSb(false);
    } else {
      setTestingAppsSb(true);
      const res = await testSupabaseEndpoint(draft.appsSupabase, 'apps_config');
      setAppsSbResult(res);
      const updated: SecretsConfig = {
        ...draft,
        appsSupabase: {
          ...draft.appsSupabase,
          lastStatus: res.httpStatus,
          lastMessage: res.message,
          testedAt: Date.now(),
        },
      };
      commitDraft(updated);
      setTestingAppsSb(false);
    }
  }

  async function handleCopySql(which: 'studio' | 'apps') {
    const sql = which === 'studio' ? STUDIO_SUPABASE_SQL : APPS_SUPABASE_SQL;
    try {
      await navigator.clipboard.writeText(sql);
      setCopiedWhich(which);
      setTimeout(() => setCopiedWhich(null), 2000);
    } catch {
      // Fallback textarea copy for restricted Android WebViews
      const ta = document.createElement('textarea');
      ta.value = sql;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      document.body.removeChild(ta);
      setCopiedWhich(which);
      setTimeout(() => setCopiedWhich(null), 2000);
    }
  }

  return (
    <section
      aria-label="Secrets Vault Panel"
      className="rounded-2xl border border-cyan-400/30 bg-[#070C1B]/95 p-4 sm:p-5 shadow-[0_0_40px_rgba(34,211,238,0.1)]"
    >
      {/* Panel Header */}
      <div className="flex items-center justify-between gap-3 border-b border-white/[0.08] pb-3.5">
        <div className="flex items-center gap-2.5 min-w-0">
          <KeyRound className="h-5 w-5 text-cyan-300 shrink-0" />
          <div className="min-w-0">
            <h2 className="font-display text-base font-semibold text-slate-100">
              Secrets Vault
            </h2>
            <p className="text-xs text-slate-400 truncate">
              Stored locally on device via localStorage · Direct CapacitorHttp client transport
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          {savedBanner && (
            <span className="inline-flex items-center gap-1 text-xs font-medium text-emerald-300">
              <Check className="h-3.5 w-3.5" />
              Saved
            </span>
          )}
          <button
            type="button"
            onClick={onClose}
            aria-label="Close Secrets Vault"
            className="flex h-9 w-9 items-center justify-center rounded-lg border border-white/10 bg-white/[0.04] text-slate-300 hover:border-cyan-400/40 hover:text-white cursor-pointer"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      </div>

      <div className="mt-4 space-y-6">
        {/* SECTION 1: 5 AUTO-DETECT AI API KEYS */}
        <div>
          <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
            <div>
              <h3 className="font-display text-sm font-semibold text-slate-100">
                AI Provider Keys (Auto-Detect)
              </h3>
              <p className="text-xs text-slate-400">
                Paste any key (AIza, gsk_, nvapi-, sk-or-v1-, Cohere) — auto-detected and tested with live HTTP status.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <label className="inline-flex items-center gap-1.5 rounded-lg border border-white/10 bg-[#0B1328] px-2.5 py-1.5 text-xs text-slate-300">
                <span className="text-slate-400">Router</span>
                <select
                  value={draft.activeProvider}
                  onChange={(e) =>
                    commitDraft({
                      ...draft,
                      activeProvider: e.target.value as SecretsConfig['activeProvider'],
                    })
                  }
                  className="bg-transparent font-semibold text-cyan-200 focus:outline-none cursor-pointer"
                >
                  <option value="auto" className="bg-[#0B1328]">Auto Priority</option>
                  {PROVIDER_ORDER.map((id) => (
                    <option key={id} value={id} className="bg-[#0B1328]">
                      {AI_PROVIDERS[id].label}
                    </option>
                  ))}
                </select>
              </label>

              <button
                type="button"
                onClick={() =>
                  commitDraft({ ...draft, preferGeminiLive: !draft.preferGeminiLive })
                }
                className={`min-h-[34px] rounded-lg border px-2.5 text-xs font-medium transition-colors cursor-pointer ${
                  draft.preferGeminiLive
                    ? 'border-cyan-400/45 bg-cyan-500/15 text-cyan-200'
                    : 'border-white/10 bg-[#0B1328] text-slate-400'
                }`}
              >
                Gemini Live WS: {draft.preferGeminiLive ? 'ON' : 'OFF'}
              </button>
            </div>
          </div>

          {autoDetectNotice && (
            <div className="mb-3 flex items-center gap-2 rounded-lg border border-cyan-400/30 bg-cyan-500/10 px-3 py-2 text-xs text-cyan-200">
              <Sparkles className="h-3.5 w-3.5 shrink-0" />
              <span>{autoDetectNotice}</span>
            </div>
          )}

          <div className="grid gap-2.5">
            {PROVIDER_ORDER.map((providerId) => {
              const meta = AI_PROVIDERS[providerId];
              const value = draft.apiKeys[providerId];
              const isVisible = Boolean(visibleKeys[providerId]);
              const isTesting = testingProvider === providerId;
              const testRes = providerResults[providerId];

              return (
                <div
                  key={providerId}
                  className="rounded-xl border border-white/[0.08] bg-[#0B1225]/90 p-3"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2 mb-1.5">
                    <div className="flex items-center gap-2 text-xs">
                      <span className="font-semibold text-slate-100">{meta.label}</span>
                      <span className="text-slate-600" aria-hidden="true">·</span>
                      <span className="font-mono text-[11px] text-slate-400">{meta.defaultModel}</span>
                    </div>
                    <span className="text-[11px] text-slate-500">{meta.prefixHint}</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <div className="relative flex-1">
                      <input
                        type={isVisible ? 'text' : 'password'}
                        value={value}
                        onChange={(e) => handleKeyInput(providerId, e.target.value)}
                        placeholder={meta.placeholder}
                        autoComplete="off"
                        spellCheck={false}
                        className="h-10 w-full rounded-lg border border-white/10 bg-[#050914] pl-3 pr-9 font-mono text-xs text-slate-100 placeholder:text-slate-600 focus:border-cyan-400/50 focus:outline-none"
                      />
                      <button
                        type="button"
                        onClick={() =>
                          setVisibleKeys((prev) => ({ ...prev, [providerId]: !prev[providerId] }))
                        }
                        aria-label={isVisible ? `Hide ${meta.label} key` : `Show ${meta.label} key`}
                        className="absolute right-2 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-slate-200 cursor-pointer"
                      >
                        {isVisible ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
                      </button>
                    </div>

                    <button
                      type="button"
                      disabled={isTesting}
                      onClick={() => handleTestProvider(providerId)}
                      className="inline-flex h-10 min-w-[78px] items-center justify-center gap-1.5 rounded-lg border border-cyan-400/35 bg-cyan-500/12 px-3 text-xs font-semibold text-cyan-200 hover:bg-cyan-500/22 disabled:opacity-50 cursor-pointer whitespace-nowrap"
                    >
                      {isTesting ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : 'Test'}
                    </button>
                  </div>

                  {testRes && (
                    <div
                      className={`mt-2 flex flex-wrap items-center justify-between gap-2 text-xs font-mono tabular-nums ${
                        testRes.ok ? 'text-emerald-300' : 'text-rose-300'
                      }`}
                    >
                      <span>
                        HTTP {testRes.httpStatus || 'ERR'} · {testRes.message}
                      </span>
                      <span className="text-slate-400">{testRes.latencyMs}ms</span>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* SECTION 2: GITHUB CI/CD & 3D ASSET VAULT REPO */}
        <div className="border-t border-white/[0.08] pt-5">
          <div className="flex items-center gap-2 mb-3">
            <GitBranch className="h-4 w-4 text-amber-300" />
            <h3 className="font-display text-sm font-semibold text-slate-100">
              GitHub Actions & 3D Asset Vault
            </h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <label className="flex flex-col gap-1.5 text-xs">
              <span className="font-medium text-slate-300">GitHub Username</span>
              <input
                type="text"
                value={draft.githubUsername}
                onChange={(e) => commitDraft({ ...draft, githubUsername: e.target.value })}
                placeholder="sarfealam2246-coder"
                className="h-10 rounded-lg border border-white/10 bg-[#050914] px-3 font-mono text-xs text-slate-100 focus:border-cyan-400/50 focus:outline-none"
              />
            </label>

            <label className="flex flex-col gap-1.5 text-xs">
              <span className="font-medium text-slate-300">3D Asset Vault Repo</span>
              <input
                type="text"
                value={draft.assetVaultRepo}
                onChange={(e) => commitDraft({ ...draft, assetVaultRepo: e.target.value })}
                placeholder="sarfealam2246-coder/sarfealam-3d-assets"
                className="h-10 rounded-lg border border-white/10 bg-[#050914] px-3 font-mono text-xs text-slate-100 focus:border-cyan-400/50 focus:outline-none"
              />
            </label>
          </div>

          <div className="mt-3">
            <label className="block text-xs font-medium text-slate-300 mb-1.5">
              GitHub PAT Token (requires <code className="text-amber-300">repo</code> +{' '}
              <code className="text-amber-300">workflow</code> scopes)
            </label>
            <div className="flex items-center gap-2">
              <div className="relative flex-1">
                <input
                  type={visibleKeys.githubPat ? 'text' : 'password'}
                  value={draft.githubPat}
                  onChange={(e) => commitDraft({ ...draft, githubPat: e.target.value })}
                  placeholder="ghp_... or github_pat_..."
                  autoComplete="off"
                  className="h-10 w-full rounded-lg border border-white/10 bg-[#050914] pl-3 pr-9 font-mono text-xs text-slate-100 placeholder:text-slate-600 focus:border-cyan-400/50 focus:outline-none"
                />
                <button
                  type="button"
                  onClick={() =>
                    setVisibleKeys((prev) => ({ ...prev, githubPat: !prev.githubPat }))
                  }
                  aria-label="Toggle GitHub PAT visibility"
                  className="absolute right-2 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-slate-200 cursor-pointer"
                >
                  {visibleKeys.githubPat ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
                </button>
              </div>
              <button
                type="button"
                disabled={testingGithub}
                onClick={handleTestGithub}
                className="inline-flex h-10 items-center justify-center gap-1.5 rounded-lg border border-amber-400/40 bg-amber-500/12 px-3.5 text-xs font-semibold text-amber-200 hover:bg-amber-500/22 disabled:opacity-50 cursor-pointer whitespace-nowrap"
              >
                {testingGithub ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : 'Test PAT'}
              </button>
            </div>
            {githubResult && (
              <div
                className={`mt-2 text-xs font-mono tabular-nums ${
                  githubResult.ok ? 'text-emerald-300' : 'text-rose-300'
                }`}
              >
                HTTP {githubResult.httpStatus || 'ERR'} · {githubResult.message}
              </div>
            )}
          </div>
        </div>

        {/* SECTION 3: STRICTLY ISOLATED DUAL SUPABASE CONFIGS */}
        <div className="border-t border-white/[0.08] pt-5">
          <div className="flex items-center gap-2 mb-3">
            <Database className="h-4 w-4 text-violet-300" />
            <h3 className="font-display text-sm font-semibold text-slate-100">
              Strictly Isolated Dual Supabase Architecture
            </h3>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* 1. Studio Supabase */}
            <div className="rounded-xl border border-violet-400/25 bg-[#0B1225]/90 p-3.5 space-y-3">
              <div>
                <h4 className="font-display text-sm font-semibold text-violet-200">
                  1. Studio Supabase
                </h4>
                <p className="text-[11px] text-slate-400 font-mono">
                  Tables: studio_state · user_rules · dynamic_skills · error_memory · active_jobs
                </p>
              </div>

              <input
                type="url"
                value={draft.studioSupabase.url}
                onChange={(e) =>
                  commitDraft({
                    ...draft,
                    studioSupabase: { ...draft.studioSupabase, url: e.target.value },
                  })
                }
                placeholder="https://studio-project.supabase.co"
                className="h-10 w-full rounded-lg border border-white/10 bg-[#050914] px-3 font-mono text-xs text-slate-100 placeholder:text-slate-600 focus:border-violet-400/50 focus:outline-none"
              />
              <input
                type={visibleKeys.studioSb ? 'text' : 'password'}
                value={draft.studioSupabase.anonKey}
                onChange={(e) =>
                  commitDraft({
                    ...draft,
                    studioSupabase: { ...draft.studioSupabase, anonKey: e.target.value },
                  })
                }
                placeholder="Studio Supabase Anon Key (eyJ...)"
                className="h-10 w-full rounded-lg border border-white/10 bg-[#050914] px-3 font-mono text-xs text-slate-100 placeholder:text-slate-600 focus:border-violet-400/50 focus:outline-none"
              />

              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleCopySql('studio')}
                  className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg border border-white/12 bg-white/[0.04] px-3 text-xs font-medium text-slate-200 hover:border-violet-400/50 cursor-pointer"
                >
                  {copiedWhich === 'studio' ? (
                    <>
                      <Check className="h-3.5 w-3.5 text-emerald-300" />
                      Copied SQL
                    </>
                  ) : (
                    <>
                      <Copy className="h-3.5 w-3.5" />
                      Copy Table SQL
                    </>
                  )}
                </button>
                <button
                  type="button"
                  disabled={testingStudioSb}
                  onClick={() => handleSaveAndTestSupabase('studio')}
                  className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg border border-violet-400/40 bg-violet-500/18 px-3 text-xs font-semibold text-violet-100 hover:bg-violet-500/28 disabled:opacity-50 cursor-pointer"
                >
                  {testingStudioSb ? (
                    <Loader2 className="h-3.5 w-3.5 animate-spin" />
                  ) : (
                    <ShieldCheck className="h-3.5 w-3.5" />
                  )}
                  Save & Test
                </button>
              </div>

              {studioSbResult && (
                <div
                  className={`text-xs font-mono tabular-nums ${
                    studioSbResult.ok ? 'text-emerald-300' : 'text-rose-300'
                  }`}
                >
                  HTTP {studioSbResult.httpStatus || 'ERR'} · {studioSbResult.message}
                </div>
              )}
            </div>

            {/* 2. Apps Supabase */}
            <div className="rounded-xl border border-cyan-400/25 bg-[#0B1225]/90 p-3.5 space-y-3">
              <div>
                <h4 className="font-display text-sm font-semibold text-cyan-200">
                  2. Apps Supabase (Exported APKs)
                </h4>
                <p className="text-[11px] text-slate-400 font-mono">
                  Table: apps_config (strictly isolated from Studio state)
                </p>
              </div>

              <input
                type="url"
                value={draft.appsSupabase.url}
                onChange={(e) =>
                  commitDraft({
                    ...draft,
                    appsSupabase: { ...draft.appsSupabase, url: e.target.value },
                  })
                }
                placeholder="https://exported-apps.supabase.co"
                className="h-10 w-full rounded-lg border border-white/10 bg-[#050914] px-3 font-mono text-xs text-slate-100 placeholder:text-slate-600 focus:border-cyan-400/50 focus:outline-none"
              />
              <input
                type={visibleKeys.appsSb ? 'text' : 'password'}
                value={draft.appsSupabase.anonKey}
                onChange={(e) =>
                  commitDraft({
                    ...draft,
                    appsSupabase: { ...draft.appsSupabase, anonKey: e.target.value },
                  })
                }
                placeholder="Apps Supabase Anon Key (eyJ...)"
                className="h-10 w-full rounded-lg border border-white/10 bg-[#050914] px-3 font-mono text-xs text-slate-100 placeholder:text-slate-600 focus:border-cyan-400/50 focus:outline-none"
              />

              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleCopySql('apps')}
                  className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg border border-white/12 bg-white/[0.04] px-3 text-xs font-medium text-slate-200 hover:border-cyan-400/50 cursor-pointer"
                >
                  {copiedWhich === 'apps' ? (
                    <>
                      <Check className="h-3.5 w-3.5 text-emerald-300" />
                      Copied SQL
                    </>
                  ) : (
                    <>
                      <Copy className="h-3.5 w-3.5" />
                      Copy Table SQL
                    </>
                  )}
                </button>
                <button
                  type="button"
                  disabled={testingAppsSb}
                  onClick={() => handleSaveAndTestSupabase('apps')}
                  className="inline-flex min-h-[38px] items-center gap-1.5 rounded-lg border border-cyan-400/40 bg-cyan-500/18 px-3 text-xs font-semibold text-cyan-100 hover:bg-cyan-500/28 disabled:opacity-50 cursor-pointer"
                >
                  {testingAppsSb ? (
                    <Loader2 className="h-3.5 w-3.5 animate-spin" />
                  ) : (
                    <ShieldCheck className="h-3.5 w-3.5" />
                  )}
                  Save & Test
                </button>
              </div>

              {appsSbResult && (
                <div
                  className={`text-xs font-mono tabular-nums ${
                    appsSbResult.ok ? 'text-emerald-300' : 'text-rose-300'
                  }`}
                >
                  HTTP {appsSbResult.httpStatus || 'ERR'} · {appsSbResult.message}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
