import { useEffect, useRef, useState } from 'react';
import {
  Camera,
  CameraOff,
  Loader2,
  Rocket,
  ScanEye,
  Trash2,
  Upload,
  X,
} from 'lucide-react';
import type { VisionAnalysisRecord } from '../types/studio';

interface CameraPanelProps {
  capturedSnapshot: string | null;
  visionAnalysis: VisionAnalysisRecord | null;
  onCaptureSnapshot: (dataUrl: string | null) => void;
  onAnalyzeWithJarvis: (
    imageDataUrl: string,
    hint?: string
  ) => Promise<{ ok: boolean; summary: string; buildSpec?: string; error?: string }>;
  onBuildFromVisionSpec: (spec: string) => Promise<void>;
  onClose: () => void;
}

/**
 * Live Camera Vision Eye Panel
 * CRITICAL ANTI-MIC-LOCK RULE:
 * Strictly calls getUserMedia({ video: { facingMode: 'environment' }, audio: false })
 * so Android's hardware microphone is NEVER touched or locked while SpeechRecognition runs.
 */
export function CameraPanel({
  capturedSnapshot,
  visionAnalysis,
  onCaptureSnapshot,
  onAnalyzeWithJarvis,
  onBuildFromVisionSpec,
  onClose,
}: CameraPanelProps) {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const [cameraActive, setCameraActive] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);
  const [hint, setHint] = useState('');
  const [error, setError] = useState<string | null>(null);

  function stopStream() {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
    setCameraActive(false);
  }

  useEffect(() => {
    return () => stopStream();
  }, []);

  async function startCamera() {
    setError(null);
    if (!navigator.mediaDevices?.getUserMedia) {
      setError('Live camera API unavailable here. Use "Upload Photo / Screenshot" below.');
      return;
    }
    try {
      // STRICTLY audio: false to guarantee zero Android mic lock
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' },
        audio: false,
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }
      setCameraActive(true);
    } catch (err) {
      setError(
        err instanceof Error
          ? `${err.message} — You can also upload any photo or screenshot below.`
          : 'Unable to open rear camera. Use Upload Photo / Screenshot instead.'
      );
    }
  }

  function grabCurrentVideoFrame(): string | null {
    const video = videoRef.current;
    if (!video || !cameraActive) return null;
    const canvas = document.createElement('canvas');
    const maxW = 960;
    const vw = video.videoWidth || 640;
    const vh = video.videoHeight || 360;
    const scale = vw > maxW ? maxW / vw : 1;
    canvas.width = Math.round(vw * scale);
    canvas.height = Math.round(vh * scale);
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL('image/jpeg', 0.85);
  }

  function handleFileUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setError(null);

    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        onCaptureSnapshot(reader.result);
      }
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  }

  async function handleCaptureAndShowJarvis() {
    setError(null);
    const frame = cameraActive ? grabCurrentVideoFrame() : capturedSnapshot;
    if (!frame) {
      setError('Start the rear camera or upload a photo/screenshot first.');
      return;
    }

    onCaptureSnapshot(frame);
    setAnalyzing(true);
    try {
      const res = await onAnalyzeWithJarvis(frame, hint.trim() || undefined);
      if (!res.ok && res.error) {
        setError(res.error);
      }
    } finally {
      setAnalyzing(false);
    }
  }

  return (
    <section
      aria-label="Live Camera Vision Eye Panel"
      className="rounded-2xl border border-emerald-400/30 bg-[#070C1B]/95 p-4 sm:p-5 space-y-4"
    >
      <div className="flex items-center justify-between gap-3 border-b border-white/[0.08] pb-3">
        <div className="flex items-center gap-2">
          <Camera className="h-5 w-5 text-emerald-300" />
          <div>
            <h2 className="font-display text-base font-semibold text-slate-100">
              Live Camera Vision Eye
            </h2>
            <p className="text-xs text-slate-400">
              Rear camera (audio: false — zero mic lock) or photo upload → Gemini Vision (gemini-2.5-flash).
            </p>
          </div>
        </div>
        <button
          type="button"
          onClick={() => {
            stopStream();
            onClose();
          }}
          aria-label="Close Camera Vision Eye"
          className="flex h-9 w-9 items-center justify-center rounded-lg border border-white/10 bg-white/[0.04] text-slate-300 hover:text-white cursor-pointer"
        >
          <X className="h-4 w-4" />
        </button>
      </div>

      {error && (
        <div className="rounded-lg border border-rose-400/35 bg-rose-500/10 px-3 py-2 text-xs text-rose-200">
          {error}
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Left: Live Rear Camera / Upload Controls */}
        <div className="flex flex-col gap-2.5">
          <div className="relative aspect-video w-full overflow-hidden rounded-xl border border-white/10 bg-[#040711] flex items-center justify-center">
            <video
              ref={videoRef}
              playsInline
              muted
              className={`h-full w-full object-cover ${cameraActive ? 'block' : 'hidden'}`}
            />
            {!cameraActive && (
              <div className="text-center px-4">
                <ScanEye className="mx-auto h-7 w-7 text-slate-600 mb-1.5" />
                <p className="text-xs text-slate-400">Rear camera standby</p>
              </div>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {!cameraActive ? (
              <button
                type="button"
                onClick={startCamera}
                className="inline-flex h-10 flex-1 items-center justify-center gap-1.5 rounded-lg border border-cyan-400/40 bg-cyan-500/15 px-3 text-xs font-semibold text-cyan-200 hover:bg-cyan-500/25 cursor-pointer whitespace-nowrap"
              >
                <Camera className="h-4 w-4" />
                <span>Start Rear Camera</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={stopStream}
                className="inline-flex h-10 flex-1 items-center justify-center gap-1.5 rounded-lg border border-white/10 bg-[#0B1225] px-3 text-xs font-medium text-slate-200 hover:border-rose-400/40 cursor-pointer whitespace-nowrap"
              >
                <CameraOff className="h-4 w-4" />
                <span>Stop Camera</span>
              </button>
            )}

            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleFileUpload}
              className="hidden"
            />
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="inline-flex h-10 flex-1 items-center justify-center gap-1.5 rounded-lg border border-white/12 bg-[#0B1225] px-3 text-xs font-medium text-slate-200 hover:border-cyan-400/40 cursor-pointer whitespace-nowrap"
            >
              <Upload className="h-4 w-4" />
              <span>Upload Photo / Screenshot</span>
            </button>
          </div>

          <input
            type="text"
            value={hint}
            onChange={(e) => setHint(e.target.value)}
            placeholder="Optional note for JARVIS (e.g. Build a 3D game matching this sketch)..."
            className="h-10 w-full rounded-lg border border-white/10 bg-[#050914] px-3 text-xs text-slate-100 placeholder:text-slate-500 focus:border-emerald-400/50 focus:outline-none"
          />

          <button
            type="button"
            disabled={analyzing || (!cameraActive && !capturedSnapshot)}
            onClick={handleCaptureAndShowJarvis}
            className="inline-flex min-h-[44px] w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-emerald-400 to-cyan-400 px-4 text-xs sm:text-sm font-bold text-slate-950 shadow-[0_0_20px_rgba(16,185,129,0.24)] hover:brightness-110 disabled:opacity-45 disabled:cursor-not-allowed cursor-pointer"
          >
            {analyzing ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <ScanEye className="h-4 w-4" />
            )}
            <span>{analyzing ? 'Analyzing via Gemini Vision...' : 'Capture & Show JARVIS'}</span>
          </button>
        </div>

        {/* Right: Captured Frame & Live Gemini Vision Spec */}
        <div className="flex flex-col gap-2.5">
          <div className="relative aspect-video w-full overflow-hidden rounded-xl border border-white/10 bg-[#040711] flex items-center justify-center">
            {capturedSnapshot ? (
              <img
                src={capturedSnapshot}
                alt="Captured Vision Eye frame"
                referrerPolicy="no-referrer"
                className="h-full w-full object-contain"
              />
            ) : (
              <p className="text-xs text-slate-500 px-4 text-center">
                Captured snapshot or uploaded screenshot appears here before Gemini Vision analysis.
              </p>
            )}
          </div>

          {capturedSnapshot && (
            <button
              type="button"
              onClick={() => onCaptureSnapshot(null)}
              className="inline-flex h-9 items-center justify-center gap-1.5 rounded-lg border border-white/10 bg-[#0B1225] px-3 text-xs text-slate-300 hover:text-rose-200 cursor-pointer"
            >
              <Trash2 className="h-3.5 w-3.5" />
              <span>Clear Snapshot</span>
            </button>
          )}

          {visionAnalysis && (
            <div className="rounded-xl border border-emerald-400/30 bg-[#0B1424] p-3 space-y-2">
              <div className="flex items-center justify-between text-[11px] font-mono text-emerald-300">
                <span>Vision Spec Attached to World State</span>
                <span>{visionAnalysis.model}</span>
              </div>
              <p className="text-xs text-slate-100 leading-relaxed">{visionAnalysis.summary}</p>
              <p className="text-[11px] text-slate-400 leading-relaxed border-t border-white/[0.06] pt-2">
                {visionAnalysis.buildSpec}
              </p>
              <button
                type="button"
                onClick={() => onBuildFromVisionSpec(visionAnalysis.buildSpec)}
                className="inline-flex h-9 w-full items-center justify-center gap-1.5 rounded-lg border border-cyan-400/45 bg-cyan-500/18 text-xs font-semibold text-cyan-100 hover:bg-cyan-500/28 cursor-pointer"
              >
                <Rocket className="h-3.5 w-3.5" />
                <span>Build Matching 3D Game / App</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
