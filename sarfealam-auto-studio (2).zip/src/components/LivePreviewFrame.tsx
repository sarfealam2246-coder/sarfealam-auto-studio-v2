import { useEffect, useState } from 'react';
import {
  AlertTriangle,
  History,
  Loader2,
  RefreshCw,
  Wand2,
  Wrench,
  X,
} from 'lucide-react';
import type { EngineType, RuntimeErrorEvent } from '../types/studio';

interface LivePreviewFrameProps {
  previewHtml: string;
  isFullscreen: boolean;
  runtimeErrors: RuntimeErrorEvent[];
  fileCount: number;
  assetCount: number;
  engine: EngineType;
  checkpointCount: number;
  onRuntimeError: (payload: { message: string; source?: string; line?: number }) => void;
  onPreviewReady: () => void;
  onClearErrors: () => void;
  onHotPatch: (instruction: string) => Promise<void>;
  onOpenCode: () => void;
  onOpenCheckpoints: () => void;
}

export function LivePreviewFrame({
  previewHtml,
  isFullscreen,
  runtimeErrors,
  fileCount,
  assetCount,
  engine,
  checkpointCount,
  onRuntimeError,
  onPreviewReady,
  onClearErrors,
  onHotPatch,
  onOpenCode,
  onOpenCheckpoints,
}: LivePreviewFrameProps) {
  const [reloadKey, setReloadKey] = useState(0);
  const [patchText, setPatchText] = useState('');
  const [isPatching, setIsPatching] = useState(false);

  useEffect(() => {
    function handleMessage(event: MessageEvent) {
      const data = event.data;
      if (!data || typeof data !== 'object') return;
      if (data.type === 'SARFEALAM_PREVIEW_ERROR' && data.payload) {
        const msg = String(data.payload.message || 'Unknown preview runtime error');
        onRuntimeError({
          message: msg,
          source: data.payload.source ? String(data.payload.source) : undefined,
          line: typeof data.payload.line === 'number' ? data.payload.line : undefined,
        });
      } else if (data.type === 'SARFEALAM_PREVIEW_READY') {
        onPreviewReady();
      }
    }

    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, [onRuntimeError, onPreviewReady]);

  async function submitPatch(instruction: string) {
    const clean = instruction.trim();
    if (!clean || isPatching) return;
    setIsPatching(true);
    try {
      await onHotPatch(clean);
      setPatchText('');
      setReloadKey((k) => k + 1);
    } finally {
      setIsPatching(false);
    }
  }

  async function handleFormSubmit(e: React.FormEvent) {
    e.preventDefault();
    await submitPatch(patchText);
  }

  const latestError = runtimeErrors[0] ?? null;

  return (
    <div
      className={`relative flex w-full flex-col bg-[#040711] ${
        isFullscreen ? 'flex-1 min-h-0' : 'min-h-[360px] sm:min-h-[420px]'
      }`}
    >
      {/* Vision QA Runtime Error Strip */}
      {latestError && (
        <div
          role="alert"
          className="flex flex-wrap items-center justify-between gap-2 border-b border-rose-400/35 bg-rose-950/75 px-3.5 py-2 text-xs text-rose-100"
        >
          <div className="flex items-center gap-2 min-w-0 flex-1">
            <AlertTriangle className="h-4 w-4 shrink-0 text-rose-400" />
            <span className="font-semibold text-rose-200 whitespace-nowrap">Vision QA</span>
            <span className="text-rose-400/60" aria-hidden="true">·</span>
            <span className="font-mono truncate">{latestError.message}</span>
            {typeof latestError.line === 'number' && latestError.line > 0 && (
              <span className="font-mono tabular-nums text-rose-300/80 whitespace-nowrap">
                L{latestError.line}
              </span>
            )}
            {runtimeErrors.length > 1 && (
              <span className="font-mono tabular-nums text-rose-300/75 whitespace-nowrap">
                (+{runtimeErrors.length - 1} more)
              </span>
            )}
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            <button
              type="button"
              disabled={isPatching}
              onClick={() =>
                submitPatch(
                  `Fix this runtime error cleanly without losing any features or assets: ${latestError.message}`
                )
              }
              className="inline-flex min-h-[32px] items-center gap-1.5 rounded-lg border border-rose-300/40 bg-rose-500/25 px-2.5 text-xs font-semibold text-rose-50 hover:bg-rose-500/35 disabled:opacity-60 whitespace-nowrap cursor-pointer"
            >
              {isPatching ? (
                <Loader2 className="h-3.5 w-3.5 animate-spin" />
              ) : (
                <Wrench className="h-3.5 w-3.5" />
              )}
              <span>Fix with JARVIS</span>
            </button>
            <button
              type="button"
              onClick={onClearErrors}
              aria-label="Dismiss runtime error"
              className="inline-flex h-8 w-8 items-center justify-center rounded-lg border border-white/10 text-rose-200 hover:bg-white/10 cursor-pointer"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* Edge-to-Edge Live Sandboxed Preview Iframe */}
      <iframe
        key={reloadKey}
        title="Display A Live Playable Preview"
        sandbox="allow-scripts allow-forms allow-modals"
        srcDoc={previewHtml}
        className={`w-full flex-1 border-0 bg-[#040711] ${
          isFullscreen ? 'min-h-0' : 'min-h-[320px] sm:min-h-[380px]'
        }`}
      />

      {/* Live Hot-Patch Bar + Checkpoints / Inspect Controls */}
      <div className="border-t border-white/[0.08] bg-[#080E1E]/95 px-3 py-2 space-y-2">
        <form onSubmit={handleFormSubmit} className="flex items-center gap-2">
          <div className="relative flex-1 min-w-0">
            <Wand2 className="pointer-events-none absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-cyan-400" />
            <input
              type="text"
              value={patchText}
              onChange={(e) => setPatchText(e.target.value)}
              disabled={isPatching}
              placeholder="Hot-patch live build: e.g. change truck color, brighter headlights, add offer banner..."
              className="h-9 w-full rounded-lg border border-white/10 bg-[#050914] pl-8 pr-3 text-xs text-slate-100 placeholder:text-slate-500 focus:border-cyan-400/50 focus:outline-none"
            />
          </div>
          <button
            type="submit"
            disabled={isPatching || !patchText.trim()}
            className="inline-flex h-9 items-center gap-1.5 rounded-lg border border-cyan-400/40 bg-cyan-500/20 px-3 text-xs font-semibold text-cyan-100 hover:bg-cyan-500/30 disabled:opacity-50 whitespace-nowrap cursor-pointer shrink-0"
          >
            {isPatching ? (
              <>
                <Loader2 className="h-3.5 w-3.5 animate-spin" />
                <span>Patching...</span>
              </>
            ) : (
              <span>Patch</span>
            )}
          </button>
        </form>

        <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-400">
          <span className="font-mono tabular-nums truncate">
            {fileCount} files · {assetCount} verified assets · {engine}
          </span>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => setReloadKey((k) => k + 1)}
              className="inline-flex items-center gap-1 text-slate-300 hover:text-cyan-200 whitespace-nowrap cursor-pointer"
              title="Reload live preview"
            >
              <RefreshCw className="h-3 w-3" />
              <span>Reload</span>
            </button>
            <span className="text-slate-700" aria-hidden="true">·</span>
            <button
              type="button"
              onClick={onOpenCheckpoints}
              className="inline-flex items-center gap-1 text-violet-300 hover:text-violet-200 font-medium whitespace-nowrap cursor-pointer"
            >
              <History className="h-3 w-3" />
              <span className="tabular-nums">Checkpoints ({checkpointCount})</span>
            </button>
            <span className="text-slate-700" aria-hidden="true">·</span>
            <button
              type="button"
              onClick={onOpenCode}
              className="text-cyan-300 hover:text-cyan-200 font-medium whitespace-nowrap cursor-pointer"
            >
              Inspect Source →
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
