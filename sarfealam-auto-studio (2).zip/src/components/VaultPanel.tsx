import { useEffect, useState } from 'react';
import {
  ArrowLeft,
  Box,
  ExternalLink,
  FileCode2,
  Folder,
  History,
  Loader2,
  Plus,
  RefreshCw,
  RotateCcw,
  Trash2,
  X,
} from 'lucide-react';
import { fetchGitHubVaultContents, type GitHubVaultItem } from '../services/aiRouter';
import {
  fetchVaultCatalog,
  resolvePolyHavenAsset,
  VAULT_CATEGORIES,
} from '../services/assetHunter';
import type { AssetCategory, RollbackCheckpoint, StudioAssetItem } from '../types/studio';

interface VaultPanelProps {
  repoSlug: string;
  githubPat: string;
  checkpoints: RollbackCheckpoint[];
  initialTab?: 'catalog' | 'tree' | 'checkpoints';
  onOpenSecrets: () => void;
  onPickAssetToDisplay: (item: StudioAssetItem) => void;
  onRestoreCheckpoint: (id: string) => void;
  onDeleteCheckpoint: (id: string) => void;
  onClose: () => void;
}

export function VaultPanel({
  repoSlug,
  githubPat,
  checkpoints,
  initialTab = 'catalog',
  onOpenSecrets,
  onPickAssetToDisplay,
  onRestoreCheckpoint,
  onDeleteCheckpoint,
  onClose,
}: VaultPanelProps) {
  const [tab, setTab] = useState<'catalog' | 'tree' | 'checkpoints'>(initialTab);

  useEffect(() => {
    setTab(initialTab);
  }, [initialTab]);

  // Catalog Index state
  const [catalogItems, setCatalogItems] = useState<StudioAssetItem[]>([]);
  const [catalogLoading, setCatalogLoading] = useState(false);
  const [catalogStatus, setCatalogStatus] = useState('');
  const [catalogOk, setCatalogOk] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState<AssetCategory | 'all'>('all');
  const [resolvingId, setResolvingId] = useState<string | null>(null);

  // GitHub Tree state
  const [currentPath, setCurrentPath] = useState('');
  const [treeItems, setTreeItems] = useState<GitHubVaultItem[]>([]);
  const [treeLoading, setTreeLoading] = useState(false);
  const [treeStatus, setTreeStatus] = useState('');
  const [treeHttpStatus, setTreeHttpStatus] = useState<number>(0);
  const [treeOk, setTreeOk] = useState<boolean>(true);

  async function loadCatalog(force = false) {
    setCatalogLoading(true);
    const res = await fetchVaultCatalog(repoSlug, force);
    setCatalogItems(res.items);
    setCatalogOk(res.ok);
    setCatalogStatus(res.message);
    setCatalogLoading(false);
  }

  async function loadDir(path: string) {
    setTreeLoading(true);
    const res = await fetchGitHubVaultContents(repoSlug, path, githubPat);
    setTreeItems(res.items);
    setTreeOk(res.ok);
    setTreeHttpStatus(res.httpStatus);
    setTreeStatus(res.message);
    setCurrentPath(path);
    setTreeLoading(false);
  }

  useEffect(() => {
    loadCatalog(false);
    loadDir('');
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [repoSlug, githubPat]);

  async function handleAddCatalogItem(item: StudioAssetItem) {
    if (item.apiFilesUrl && !item.pbrMaps) {
      setResolvingId(item.id);
      const resolved = await resolvePolyHavenAsset(item);
      setCatalogItems((prev) => prev.map((x) => (x.id === item.id ? resolved : x)));
      setResolvingId(null);
      onPickAssetToDisplay(resolved);
      return;
    }
    onPickAssetToDisplay(item);
  }

  function navigateUp() {
    const parts = currentPath.split('/').filter(Boolean);
    parts.pop();
    loadDir(parts.join('/'));
  }

  const filteredCatalog =
    selectedCategory === 'all'
      ? catalogItems
      : catalogItems.filter((i) => i.category === selectedCategory);

  return (
    <section
      aria-label="3D Asset Vault & Checkpoints Browser"
      className="rounded-2xl border border-cyan-400/30 bg-[#070C1B]/95 p-4 sm:p-5"
    >
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/[0.08] pb-3">
        <div className="flex items-center gap-2 min-w-0">
          <Box className="h-5 w-5 text-cyan-300 shrink-0" />
          <div className="min-w-0">
            <h2 className="font-display text-base font-semibold text-slate-100">
              3D Asset Vault &amp; Checkpoints
            </h2>
            <p className="text-xs font-mono text-slate-400 truncate">
              {tab === 'checkpoints'
                ? `${checkpoints.length} local 1-second rollback snapshots`
                : `${repoSlug}${tab === 'tree' && currentPath ? `/${currentPath}` : '/main/catalog.json'}`}
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2 shrink-0">
          <div className="inline-flex rounded-lg border border-white/10 bg-[#050914] p-0.5">
            <button
              type="button"
              onClick={() => setTab('catalog')}
              className={`h-8 rounded-md px-2.5 text-xs font-medium whitespace-nowrap cursor-pointer ${
                tab === 'catalog'
                  ? 'bg-cyan-500/20 text-cyan-200'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Catalog ({catalogItems.length})
            </button>
            <button
              type="button"
              onClick={() => setTab('tree')}
              className={`h-8 rounded-md px-2.5 text-xs font-medium whitespace-nowrap cursor-pointer ${
                tab === 'tree'
                  ? 'bg-cyan-500/20 text-cyan-200'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Repo Files
            </button>
            <button
              type="button"
              onClick={() => setTab('checkpoints')}
              className={`inline-flex h-8 items-center gap-1 rounded-md px-2.5 text-xs font-medium whitespace-nowrap cursor-pointer ${
                tab === 'checkpoints'
                  ? 'bg-violet-500/25 text-violet-100'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <History className="h-3.5 w-3.5" />
              <span className="tabular-nums">Checkpoints ({checkpoints.length})</span>
            </button>
          </div>

          {tab !== 'checkpoints' && (
            <button
              type="button"
              onClick={() => (tab === 'catalog' ? loadCatalog(true) : loadDir(currentPath))}
              disabled={catalogLoading || treeLoading}
              aria-label="Refresh 3D Asset Vault"
              className="flex h-9 w-9 items-center justify-center rounded-lg border border-white/10 bg-white/[0.04] text-slate-300 hover:border-cyan-400/40 cursor-pointer"
            >
              <RefreshCw className={`h-4 w-4 ${catalogLoading || treeLoading ? 'animate-spin' : ''}`} />
            </button>
          )}
          <button
            type="button"
            onClick={onClose}
            aria-label="Close Asset Vault"
            className="flex h-9 w-9 items-center justify-center rounded-lg border border-white/10 bg-white/[0.04] text-slate-300 hover:text-white cursor-pointer"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      </div>

      {/* TAB 1: PARSED CATALOG.JSON ACROSS ALL 8 CATEGORIES */}
      {tab === 'catalog' && (
        <div className="mt-3 space-y-3">
          {/* Category Filter Controls */}
          <div className="flex flex-wrap items-center gap-1.5">
            <button
              type="button"
              onClick={() => setSelectedCategory('all')}
              className={`rounded-lg border px-2.5 py-1 text-xs font-medium cursor-pointer ${
                selectedCategory === 'all'
                  ? 'border-cyan-400/50 bg-cyan-500/20 text-cyan-100'
                  : 'border-white/10 bg-[#0B1225] text-slate-400 hover:text-slate-200'
              }`}
            >
              All ({catalogItems.length})
            </button>
            {VAULT_CATEGORIES.map((cat) => {
              const count = catalogItems.filter((i) => i.category === cat).length;
              return (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setSelectedCategory(cat)}
                  className={`rounded-lg border px-2.5 py-1 text-xs font-medium cursor-pointer ${
                    selectedCategory === cat
                      ? 'border-cyan-400/50 bg-cyan-500/20 text-cyan-100'
                      : 'border-white/10 bg-[#0B1225] text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {cat.replace('_', ' ')} ({count})
                </button>
              );
            })}
          </div>

          {catalogLoading ? (
            <div className="flex items-center justify-center gap-2 py-8 text-xs text-slate-400">
              <Loader2 className="h-4 w-4 animate-spin text-cyan-400" />
              <span>Fetching catalog.json from raw.githubusercontent.com...</span>
            </div>
          ) : !catalogOk ? (
            <div className="rounded-xl border border-amber-400/30 bg-amber-500/10 p-4 text-xs text-amber-200 space-y-2">
              <div className="font-mono">{catalogStatus}</div>
              <button
                type="button"
                onClick={onOpenSecrets}
                className="rounded-lg border border-amber-300/40 bg-amber-500/20 px-3 py-1.5 font-semibold text-amber-100 hover:bg-amber-500/30 cursor-pointer"
              >
                Update Asset Vault Repo in Secrets
              </button>
            </div>
          ) : filteredCatalog.length === 0 ? (
            <div className="py-8 text-center text-xs text-slate-400">
              No assets found in this category.
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5 max-h-[320px] overflow-y-auto pr-0.5">
              {filteredCatalog.slice(0, 36).map((item) => (
                <div
                  key={item.id}
                  className="flex items-center justify-between gap-2.5 rounded-xl border border-white/[0.08] bg-[#0B1225]/85 p-2.5"
                >
                  <div className="min-w-0 flex-1">
                    <div className="text-xs font-semibold text-slate-100 truncate">{item.name}</div>
                    <div className="text-[11px] text-slate-400 truncate">
                      {item.source} · {item.category}
                    </div>
                    {item.format === 'audio' && (
                      <audio
                        controls
                        preload="none"
                        src={item.rawUrl}
                        className="mt-1.5 h-7 w-full"
                      />
                    )}
                  </div>
                  <button
                    type="button"
                    disabled={resolvingId === item.id}
                    onClick={() => handleAddCatalogItem(item)}
                    className="inline-flex h-8 items-center gap-1 rounded-lg border border-cyan-400/40 bg-cyan-500/15 px-2.5 text-xs font-semibold text-cyan-200 hover:bg-cyan-500/25 cursor-pointer shrink-0"
                  >
                    {resolvingId === item.id ? (
                      <Loader2 className="h-3.5 w-3.5 animate-spin" />
                    ) : (
                      <Plus className="h-3.5 w-3.5" />
                    )}
                    <span>Pick</span>
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 2: LIVE GITHUB REPOSITORY FILE TREE */}
      {tab === 'tree' && (
        <div className="mt-3">
          {currentPath && (
            <button
              type="button"
              onClick={navigateUp}
              className="mb-2.5 inline-flex items-center gap-1.5 rounded-lg border border-white/10 bg-[#0B1225] px-2.5 py-1.5 text-xs text-cyan-200 hover:border-cyan-400/40 cursor-pointer"
            >
              <ArrowLeft className="h-3.5 w-3.5" />
              <span>Up one directory</span>
            </button>
          )}

          {treeLoading ? (
            <div className="flex items-center justify-center gap-2 py-8 text-xs text-slate-400">
              <Loader2 className="h-4 w-4 animate-spin text-cyan-400" />
              <span>Fetching live GitHub repository tree...</span>
            </div>
          ) : !treeOk ? (
            <div className="rounded-xl border border-amber-400/30 bg-amber-500/10 p-4 text-xs text-amber-200 space-y-2">
              <div className="font-mono">
                HTTP {treeHttpStatus || 'ERR'} · {treeStatus}
              </div>
              <button
                type="button"
                onClick={onOpenSecrets}
                className="rounded-lg border border-amber-300/40 bg-amber-500/20 px-3 py-1.5 font-semibold text-amber-100 hover:bg-amber-500/30 cursor-pointer"
              >
                Configure GitHub PAT & Repo in Secrets
              </button>
            </div>
          ) : treeItems.length === 0 ? (
            <div className="py-8 text-center text-xs text-slate-400">
              Repository directory is empty.
            </div>
          ) : (
            <div className="divide-y divide-white/[0.06] rounded-xl border border-white/[0.08] bg-[#0B1225]/80">
              {treeItems.map((item) => (
                <div
                  key={item.path}
                  className="flex items-center justify-between gap-3 px-3.5 py-2.5 text-xs"
                >
                  {item.type === 'dir' ? (
                    <button
                      type="button"
                      onClick={() => loadDir(item.path)}
                      className="flex items-center gap-2 text-cyan-200 hover:text-cyan-100 font-medium cursor-pointer truncate"
                    >
                      <Folder className="h-4 w-4 text-cyan-400 shrink-0" />
                      <span className="truncate">{item.name}/</span>
                    </button>
                  ) : (
                    <div className="flex items-center gap-2 text-slate-200 truncate">
                      <FileCode2 className="h-4 w-4 text-violet-300 shrink-0" />
                      <span className="truncate font-mono">{item.name}</span>
                    </div>
                  )}

                  <div className="flex items-center gap-3 shrink-0 text-slate-400 font-mono tabular-nums">
                    {item.type === 'file' && <span>{(item.size / 1024).toFixed(1)} KB</span>}
                    {item.html_url && (
                      <a
                        href={item.html_url}
                        target="_blank"
                        rel="noreferrer"
                        className="text-cyan-300 hover:text-cyan-200"
                        aria-label={`Open ${item.name} on GitHub`}
                      >
                        <ExternalLink className="h-3.5 w-3.5" />
                      </a>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 3: 1-SECOND ROLLBACK CHECKPOINTS */}
      {tab === 'checkpoints' && (
        <div className="mt-3 space-y-2.5">
          {checkpoints.length === 0 ? (
            <div className="rounded-xl border border-white/[0.08] bg-[#0B1225]/70 px-4 py-8 text-center text-xs text-slate-400">
              No rollback checkpoints saved yet. Checkpoints are saved automatically after every 5-stage build and right before every live hot-patch.
            </div>
          ) : (
            <div className="space-y-2 max-h-[340px] overflow-y-auto pr-0.5">
              {checkpoints.map((cp) => {
                const timeStr = new Date(cp.createdAt).toLocaleTimeString([], {
                  hour: '2-digit',
                  minute: '2-digit',
                  second: '2-digit',
                });
                return (
                  <div
                    key={cp.id}
                    className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-white/[0.08] bg-[#0B1225]/85 px-3.5 py-3"
                  >
                    <div className="min-w-0 flex-1 space-y-0.5">
                      <div className="flex flex-wrap items-center gap-2 text-xs">
                        <span className="font-semibold text-slate-100 truncate">{cp.label}</span>
                        <span className="text-slate-600" aria-hidden="true">·</span>
                        <span className="font-mono text-[11px] text-cyan-300">{cp.engine}</span>
                        <span className="text-slate-600" aria-hidden="true">·</span>
                        <span className="font-mono text-[11px] tabular-nums text-slate-400">
                          {cp.generatedFiles.length} files · {timeStr}
                        </span>
                      </div>
                      {cp.prompt && (
                        <p className="text-xs text-slate-400 truncate max-w-2xl">{cp.prompt}</p>
                      )}
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        type="button"
                        onClick={() => onRestoreCheckpoint(cp.id)}
                        className="inline-flex min-h-[36px] items-center gap-1.5 rounded-lg border border-violet-400/45 bg-violet-500/20 px-3 text-xs font-semibold text-violet-100 hover:bg-violet-500/30 whitespace-nowrap cursor-pointer"
                      >
                        <RotateCcw className="h-3.5 w-3.5" />
                        <span>Restore</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => onDeleteCheckpoint(cp.id)}
                        aria-label={`Delete checkpoint ${cp.label}`}
                        className="inline-flex h-9 w-9 items-center justify-center rounded-lg border border-white/10 bg-white/[0.03] text-slate-400 hover:border-rose-400/40 hover:text-rose-300 cursor-pointer"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
    </section>
  );
}
