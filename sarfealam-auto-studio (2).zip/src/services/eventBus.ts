import type {
  ActuatorExecutionRecord,
  ChatMessage,
  SatelliteBotId,
  SecretsConfig,
  VoiceStatusSnapshot,
  WorldState,
} from '../types/studio';

export interface StudioEventMap {
  'world:updated': WorldState;
  'voice:status': VoiceStatusSnapshot;
  'voice:user_speech': { text: string; source: 'gemini-live' | 'native-bridge' | 'web-speech' };
  'voice:error': { message: string };
  'actuator:executed': ActuatorExecutionRecord;
  'chat:message': ChatMessage;
  'secrets:updated': SecretsConfig;
  'pipeline:stage': { stage: number; label: string; paused: boolean };
  'bot:progress': {
    botId: SatelliteBotId;
    status: 'idle' | 'active' | 'paused' | 'done' | 'error';
    task: string;
    progress: number;
  };
}

type EventKey = keyof StudioEventMap;
type Listener<K extends EventKey> = (payload: StudioEventMap[K]) => void;

class StudioEventBus {
  private listeners: Map<EventKey, Set<Listener<EventKey>>> = new Map();

  on<K extends EventKey>(event: K, listener: Listener<K>): () => void {
    let bucket = this.listeners.get(event);
    if (!bucket) {
      bucket = new Set();
      this.listeners.set(event, bucket);
    }
    bucket.add(listener as Listener<EventKey>);
    return () => {
      bucket?.delete(listener as Listener<EventKey>);
    };
  }

  emit<K extends EventKey>(event: K, payload: StudioEventMap[K]): void {
    const bucket = this.listeners.get(event);
    if (!bucket) return;
    bucket.forEach((fn) => {
      try {
        fn(payload);
      } catch (err) {
        console.error(`[EventBus] Listener error on "${event}":`, err);
      }
    });
  }

  clear(): void {
    this.listeners.clear();
  }
}

export const studioBus = new StudioEventBus();
