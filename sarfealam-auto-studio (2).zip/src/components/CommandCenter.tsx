import { Cpu, GitBranch, Layers, Plus, ScanEye, X } from 'lucide-react';
import type {
  SatelliteBotId,
  SatelliteBotState,
  SubBotState,
  VoiceState,
  VoiceTransport,
  WorldState,
} from '../types/studio';

interface CommandCenterProps {
  world: WorldState;
  voiceState: VoiceState;
  voiceTransport: VoiceTransport;
  liveEnabled: boolean;
  onOrbTap: () => void;
  onBotSelect: (botId: SatelliteBotId) => void;
  onSpawnQuickSubBot: () => void;
  onRemoveSubBot: (id: string) => void;
}

const ORB_VISUALS: Record<
  VoiceState,
  {
    label: string;
    ringColor: string;
    coreGradient: string;
    glowShadow: string;
    beamHex: string;
    textColor: string;
  }
> = {
  IDLE: {
    label: 'IDLE',
    ringColor: 'border-cyan-400/35',
    coreGradient: 'from-cyan-500/30 via-slate-900 to-violet-600/30',
    glowShadow: 'shadow-[0_0_45px_rgba(34,211,238,0.22)]',
    beamHex: '#22D3EE',
    textColor: 'text-cyan-200',
  },
  LISTENING: {
    label: 'LISTENING',
    ringColor: 'border-cyan-300/80',
    coreGradient: 'from-cyan-400/55 via-sky-500/35 to-indigo-600/40',
    glowShadow: 'shadow-[0_0_65px_rgba(34,211,238,0.52)]',
    beamHex: '#38BDF8',
    textColor: 'text-cyan-100',
  },
  THINKING: {
    label: 'THINKING',
    ringColor: 'border-violet-400/80',
    coreGradient: 'from-violet-500/55 via-indigo-600/45 to-cyan-500/30',
    glowShadow: 'shadow-[0_0_65px_rgba(139,92,246,0.52)]',
    beamHex: '#A78BFA',
    textColor: 'text-violet-200',
  },
  SPEAKING: {
    label: 'SPEAKING',
    ringColor: 'border-emerald-400/80',
    coreGradient: 'from-emerald-400/50 via-cyan-500/40 to-teal-700/40',
    glowShadow: 'shadow-[0_0_65px_rgba(16,185,129,0.48)]',
    beamHex: '#34D399',
    textColor: 'text-emerald-200',
  },
  PAUSED: {
    label: 'PAUSED',
    ringColor: 'border-amber-400/75',
    coreGradient: 'from-amber-500/45 via-amber-900/35 to-slate-900',
    glowShadow: 'shadow-[0_0_52px_rgba(245,158,11,0.38)]',
    beamHex: '#F59E0B',
    textColor: 'text-amber-200',
  },
};

const BOT_ACCENTS: Record<
  SatelliteBotState['accent'],
  { border: string; bar: string; stroke: string; label: string }
> = {
  cyan: {
    border: 'border-cyan-400/30 hover:border-cyan-400/60',
    bar: 'bg-cyan-400',
    stroke: '#22D3EE',
    label: 'text-cyan-300',
  },
  violet: {
    border: 'border-violet-400/30 hover:border-violet-400/60',
    bar: 'bg-violet-400',
    stroke: '#A78BFA',
    label: 'text-violet-300',
  },
  emerald: {
    border: 'border-emerald-400/30 hover:border-emerald-400/60',
    bar: 'bg-emerald-400',
    stroke: '#34D399',
    label: 'text-emerald-300',
  },
  amber: {
    border: 'border-amber-400/30 hover:border-amber-400/60',
    bar: 'bg-amber-400',
    stroke: '#FBBF24',
    label: 'text-amber-300',
  },
};

function BotIcon({ id }: { id: SatelliteBotId }) {
  switch (id) {
    case 'asset-hunter':
      return <Layers className="h-4 w-4 text-cyan-300" />;
    case 'code-bot':
      return <Cpu className="h-4 w-4 text-violet-300" />;
    case 'vision-qa':
      return <ScanEye className="h-4 w-4 text-emerald-300" />;
    case 'github-heal':
      return <GitBranch className="h-4 w-4 text-amber-300" />;
  }
}

export function CommandCenter({
  world,
  voiceState,
  voiceTransport,
  liveEnabled,
  onOrbTap,
  onBotSelect,
  onSpawnQuickSubBot,
  onRemoveSubBot,
}: CommandCenterProps) {
  const effectiveState: VoiceState =
    world.paused && voiceState === 'IDLE' ? 'PAUSED' : voiceState;
  const orb = ORB_VISUALS[effectiveState];

  const orderedBots: SatelliteBotState[] = [
    world.runningBots['asset-hunter'],
    world.runningBots['code-bot'],
    world.runningBots['vision-qa'],
    world.runningBots['github-heal'],
  ];

  // Anchor coordinates for the 4 curved fiber-optic beams in SVG 800x210 space
  const beamTargets = [
    { bot: orderedBots[0], x: 100, y: 196, cx1: 310, cy1: 118, cx2: 145, cy2: 115 },
    { bot: orderedBots[1], x: 300, y: 196, cx1: 365, cy1: 132, cx2: 315, cy2: 138 },
    { bot: orderedBots[2], x: 500, y: 196, cx1: 435, cy1: 132, cx2: 485, cy2: 138 },
    { bot: orderedBots[3], x: 700, y: 196, cx1: 490, cy1: 118, cx2: 655, cy2: 115 },
  ];

  return (
    <section
      aria-label="Landscape of Signals JARVIS Command Center"
      className="relative overflow-hidden rounded-2xl border border-white/[0.08] bg-[#070B18]/90 px-4 pt-4 pb-5"
    >
      {/* Subtle 3D Perspective Topographic "World State" Grid at Base */}
      <div className="pointer-events-none absolute inset-x-0 bottom-0 h-44 overflow-hidden opacity-60" aria-hidden="true">
        <svg
          viewBox="0 0 800 180"
          preserveAspectRatio="none"
          className="h-full w-full"
        >
          <defs>
            <linearGradient id="topoFade" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#22D3EE" stopOpacity="0" />
              <stop offset="55%" stopColor="#22D3EE" stopOpacity="0.16" />
              <stop offset="100%" stopColor="#8B5CF6" stopOpacity="0.28" />
            </linearGradient>
          </defs>
          {/* Perspective horizon rows */}
          {[28, 52, 78, 108, 140, 174].map((y, idx) => (
            <path
              key={y}
              d={`M 0 ${y} Q 200 ${y - 8 + (idx % 2) * 5}, 400 ${y + 3} T 800 ${y}`}
              fill="none"
              stroke="url(#topoFade)"
              strokeWidth={idx > 3 ? 1.2 : 0.8}
            />
          ))}
          {/* Perspective vanishing meridians */}
          {[-260, -140, -40, 60, 160, 260, 360, 460, 560, 660, 760, 860, 960, 1060].map((x) => (
            <line
              key={x}
              x1="400"
              y1="6"
              x2={x}
              y2="180"
              stroke="url(#topoFade)"
              strokeWidth="0.75"
            />
          ))}
        </svg>
      </div>

      {/* Header Line */}
      <div className="relative z-10 flex flex-wrap items-center justify-between gap-2 mb-1">
        <div>
          <h2 className="font-display text-sm sm:text-base font-semibold text-slate-100">
            Landscape of Signals · JARVIS Command Center
          </h2>
          <p className="text-xs text-slate-400">
            Tap Core Orb to {liveEnabled ? 'barge-in & speak' : 'wake JARVIS Live'} ·{' '}
            <span className="font-mono text-slate-300">
              {voiceTransport === 'gemini-live' ? 'Gemini Live WS' : 'Native Bridge'}
            </span>
          </p>
        </div>

        <button
          type="button"
          onClick={onSpawnQuickSubBot}
          className="inline-flex min-h-[34px] items-center gap-1.5 rounded-lg border border-white/10 bg-[#0D152B] px-2.5 text-xs font-medium text-slate-300 hover:border-violet-400/50 hover:text-violet-200 transition-colors cursor-pointer"
        >
          <Plus className="h-3.5 w-3.5" />
          <span>Spawn Sub-Bot</span>
        </button>
      </div>

      {/* Central Holographic Core Orb + Curved SVG Fiber-Optic Signal Beams */}
      <div className="relative z-10 flex flex-col items-center">
        {/* Interactive Holographic Core Orb */}
        <div className="relative flex flex-col items-center justify-center pt-2 pb-1">
          {effectiveState === 'LISTENING' && (
            <span
              className="pointer-events-none absolute h-28 w-28 rounded-full border border-cyan-400/60 animate-sonar"
              aria-hidden="true"
            />
          )}
          {effectiveState === 'SPEAKING' && (
            <span
              className="pointer-events-none absolute h-28 w-28 rounded-full border border-emerald-400/60 animate-sonar"
              aria-hidden="true"
            />
          )}

          <button
            type="button"
            onClick={onOrbTap}
            aria-label={`JARVIS Core Orb, current state ${orb.label}. Tap to trigger voice or barge-in.`}
            className={`group relative flex h-28 w-28 sm:h-32 sm:w-32 items-center justify-center rounded-full border-2 bg-gradient-to-br transition-all duration-300 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-300 ${orb.ringColor} ${orb.coreGradient} ${orb.glowShadow}`}
          >
            {/* Outer Orbital Ring */}
            <span
              className={`pointer-events-none absolute inset-1.5 rounded-full border border-dashed border-cyan-300/35 ${
                effectiveState === 'THINKING' ? 'animate-orb-spin-fast' : 'animate-orb-spin'
              }`}
              aria-hidden="true"
            />
            {/* Inner Counter-Rotating Ring */}
            <span
              className="pointer-events-none absolute inset-3.5 rounded-full border border-violet-300/30 animate-orb-spin-reverse"
              aria-hidden="true"
            />
            {/* Luminous Center Core */}
            <span
              className="relative flex flex-col items-center justify-center rounded-full px-2 text-center animate-orb-breathe"
            >
              <span className="font-display text-xs font-bold tracking-[0.16em] text-slate-50">
                JARVIS
              </span>
              <span className={`mt-0.5 font-mono text-[10px] font-semibold tracking-wider ${orb.textColor}`}>
                {orb.label}
              </span>
            </span>
          </button>
        </div>

        {/* Animated SVG Curved Fiber-Optic Light Beams connecting Core -> 4 Satellite Bot Pods */}
        <div className="relative -mt-3 w-full h-16 sm:h-20 pointer-events-none" aria-hidden="true">
          <svg
            viewBox="0 0 800 205"
            preserveAspectRatio="none"
            className="h-full w-full overflow-visible"
          >
            <defs>
              <filter id="beamGlow" x="-20%" y="-20%" width="140%" height="140%">
                <feGaussianBlur stdDeviation="3.5" result="blur" />
                <feMerge>
                  <feMergeNode in="blur" />
                  <feMergeNode in="SourceGraphic" />
                </feMerge>
              </filter>
            </defs>

            {beamTargets.map(({ bot, x, y, cx1, cy1, cx2, cy2 }) => {
              const isActive = bot.status === 'active' || effectiveState === 'THINKING';
              const accentStroke = BOT_ACCENTS[bot.accent].stroke;
              const d = `M 400 10 C ${cx1} ${cy1}, ${cx2} ${cy2}, ${x} ${y}`;

              return (
                <g key={bot.id}>
                  {/* Ambient glass fiber track */}
                  <path
                    d={d}
                    fill="none"
                    stroke={accentStroke}
                    strokeOpacity={isActive ? 0.35 : 0.16}
                    strokeWidth={isActive ? 3.5 : 2}
                  />
                  {/* Flowing fiber-optic light packet */}
                  <path
                    d={d}
                    fill="none"
                    stroke={isActive ? accentStroke : orb.beamHex}
                    strokeOpacity={isActive ? 0.95 : 0.55}
                    strokeWidth={isActive ? 3 : 2}
                    strokeDasharray="24 96"
                    filter="url(#beamGlow)"
                    className={
                      bot.status === 'paused'
                        ? ''
                        : isActive
                        ? 'animate-signal-flow-fast'
                        : 'animate-signal-flow'
                    }
                  />
                  {/* Terminal node halo */}
                  <circle
                    cx={x}
                    cy={y}
                    r={isActive ? 5 : 3.5}
                    fill={accentStroke}
                    fillOpacity={isActive ? 0.9 : 0.45}
                  />
                </g>
              );
            })}
          </svg>
        </div>

        {/* 4 Floating Satellite Bot Pods + Live Equalizer Mini-Displays */}
        <div className="relative z-10 grid w-full grid-cols-2 lg:grid-cols-4 gap-2.5 sm:gap-3">
          {orderedBots.map((bot) => {
            const style = BOT_ACCENTS[bot.accent];
            const peak = Math.max(...bot.telemetryBars);

            return (
              <button
                key={bot.id}
                type="button"
                onClick={() => onBotSelect(bot.id)}
                className={`group flex flex-col justify-between rounded-xl border bg-[#0B1226]/90 p-3 text-left transition-all duration-200 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400 ${style.border}`}
              >
                {/* Pod Header */}
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5">
                      <BotIcon id={bot.id} />
                      <span className="font-display text-xs sm:text-sm font-semibold text-slate-100 truncate">
                        {bot.name}
                      </span>
                    </div>
                    <p className="mt-0.5 text-[11px] text-slate-400 truncate">{bot.role}</p>
                  </div>
                  <span
                    className={`font-mono text-[10px] font-semibold uppercase tracking-wide shrink-0 ${
                      bot.status === 'active'
                        ? style.label
                        : bot.status === 'paused'
                        ? 'text-amber-300'
                        : bot.status === 'done'
                        ? 'text-emerald-300'
                        : 'text-slate-500'
                    }`}
                  >
                    {bot.status}
                  </span>
                </div>

                {/* Live Mini-Display: Animated Equalizer Telemetry Bars */}
                <div className="mt-3 rounded-lg border border-white/[0.06] bg-[#050914] px-2.5 py-2">
                  <div className="flex h-10 items-end justify-between gap-1">
                    {bot.telemetryBars.map((val, i) => (
                      <div
                        key={i}
                        className="relative flex-1 h-full flex items-end"
                      >
                        <div
                          className={`w-full rounded-t-sm transition-transform duration-200 origin-bottom ${
                            bot.status === 'paused' ? 'bg-amber-400/75' : style.bar
                          }`}
                          style={{
                            height: '100%',
                            transform: `scaleY(${Math.max(0.12, val / 100)})`,
                            opacity: bot.status === 'active' ? 0.95 : 0.45,
                          }}
                        />
                      </div>
                    ))}
                  </div>
                  <div className="mt-1.5 flex items-center justify-between gap-2 text-[11px]">
                    <span className="text-slate-400 truncate">{bot.currentTask}</span>
                    <span className="font-mono tabular-nums text-slate-300 shrink-0">
                      {bot.status === 'done' ? '100%' : `${peak}%`}
                    </span>
                  </div>
                </div>
              </button>
            );
          })}
        </div>

        {/* Dynamically Spawned Specialist Sub-Bots Row */}
        {world.spawnedSubBots.length > 0 && (
          <div className="relative z-10 mt-3 w-full">
            <div className="mb-1.5 flex items-center justify-between text-xs text-slate-400">
              <span className="font-medium text-violet-200">
                Specialist Sub-Bots ({world.spawnedSubBots.length})
              </span>
            </div>
            <div className="flex flex-wrap gap-2">
              {world.spawnedSubBots.map((sb: SubBotState) => (
                <div
                  key={sb.id}
                  className="flex items-center gap-3 rounded-xl border border-violet-400/30 bg-[#0D142B]/95 px-3 py-2"
                >
                  <div className="min-w-0">
                    <div className="text-xs font-semibold text-slate-100">{sb.name}</div>
                    <div className="text-[11px] text-slate-400">{sb.role}</div>
                  </div>
                  {/* Mini equalizer */}
                  <div className="flex h-6 w-14 items-end gap-0.5" aria-hidden="true">
                    {sb.telemetryBars.slice(0, 6).map((v, i) => (
                      <span
                        key={i}
                        className={`flex-1 rounded-t-sm transition-transform duration-200 origin-bottom ${
                          sb.status === 'paused' ? 'bg-amber-400/80' : 'bg-violet-400/85'
                        }`}
                        style={{ height: '100%', transform: `scaleY(${Math.max(0.15, v / 100)})` }}
                      />
                    ))}
                  </div>
                  <button
                    type="button"
                    onClick={() => onRemoveSubBot(sb.id)}
                    aria-label={`Dismiss ${sb.name}`}
                    className="rounded-md p-1 text-slate-400 hover:bg-white/10 hover:text-slate-100 cursor-pointer"
                  >
                    <X className="h-3.5 w-3.5" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
