import { studioBus } from './eventBus';
import type { LanguageCode, SecretsConfig, VisionAnalysisRecord } from '../types/studio';

export interface VisionAnalyzeResult {
  ok: boolean;
  httpStatus: number;
  record?: VisionAnalysisRecord;
  error?: string;
}

function extractBase64Payload(dataUrl: string): { mimeType: string; base64: string } {
  const match = dataUrl.match(/^data:([^;]+);base64,(.+)$/);
  if (match) {
    return { mimeType: match[1] || 'image/jpeg', base64: match[2] };
  }
  return { mimeType: 'image/jpeg', base64: dataUrl };
}

/**
 * Live Camera Vision Eye -> Gemini Vision (gemini-2.5-flash)
 * Captures JPEG frame analysis, updates Vision QA telemetry on EventBus,
 * and returns both a spoken summary and an actionable 3D/App build spec.
 */
export async function analyzeFrameWithGeminiVision(
  imageDataUrl: string,
  secrets: SecretsConfig,
  language: LanguageCode,
  userHint?: string
): Promise<VisionAnalyzeResult> {
  const geminiKey = secrets.apiKeys.gemini?.trim() || '';
  if (!geminiKey) {
    return {
      ok: false,
      httpStatus: 0,
      error: 'Save a Gemini API key (AIza...) in the Secrets panel to enable Gemini Vision Eye analysis.',
    };
  }

  studioBus.emit('bot:progress', {
    botId: 'vision-qa',
    status: 'active',
    task: 'Analyzing frame via Gemini Vision',
    progress: 45,
  });

  const { mimeType, base64 } = extractBase64Payload(imageDataUrl);
  const model = 'gemini-2.5-flash';
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${encodeURIComponent(geminiKey)}`;

  const langRule =
    language === 'hi'
      ? 'Write "summary" in concise spoken Hindi (1-2 sentences) suited for voice readout, and "buildSpec" in clear English technical specification.'
      : 'Write "summary" in concise spoken English addressing "Sir" (1-2 sentences), and "buildSpec" as a concrete 3D/app architecture prompt.';

  const promptText = [
    'You are JARVIS Vision Eye inside Sarfealam Auto-Studio.',
    'Analyze this camera snapshot or screenshot carefully.',
    userHint ? `User context: ${userHint}` : '',
    langRule,
    'Return ONLY raw JSON (no markdown code fences) with this exact schema:',
    '{ "summary": "concise spoken observation", "buildSpec": "detailed actionable prompt to recreate or enhance this scene/app in Sarfealam Auto-Studio including objects, colors, layout, lighting, and UI controls" }',
  ]
    .filter(Boolean)
    .join('\n');

  try {
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [
          {
            role: 'user',
            parts: [
              { inlineData: { mimeType, data: base64 } },
              { text: promptText },
            ],
          },
        ],
        generationConfig: {
          responseMimeType: 'application/json',
        },
      }),
    });

    if (!res.ok) {
      const errText = await res.text().catch(() => '');
      studioBus.emit('bot:progress', {
        botId: 'vision-qa',
        status: 'error',
        task: `Vision HTTP ${res.status}`,
        progress: 0,
      });
      return {
        ok: false,
        httpStatus: res.status,
        error: `Gemini Vision HTTP ${res.status}: ${errText.slice(0, 160) || res.statusText}`,
      };
    }

    const data = await res.json();
    const rawText = (data?.candidates?.[0]?.content?.parts?.[0]?.text || '').trim();
    const cleaned = rawText
      .replace(/^```(?:json)?\s*/i, '')
      .replace(/\s*```$/i, '')
      .trim();

    let summary = 'Visual frame analyzed, Sir.';
    let buildSpec = rawText;

    try {
      const parsed = JSON.parse(cleaned);
      if (typeof parsed?.summary === 'string' && parsed.summary.trim()) {
        summary = parsed.summary.trim();
      }
      if (typeof parsed?.buildSpec === 'string' && parsed.buildSpec.trim()) {
        buildSpec = parsed.buildSpec.trim();
      }
    } catch {
      if (cleaned) {
        summary = cleaned.slice(0, 180);
        buildSpec = cleaned;
      }
    }

    const record: VisionAnalysisRecord = {
      id: `vision_${Date.now()}`,
      imageDataUrl,
      summary,
      buildSpec,
      model,
      timestamp: Date.now(),
    };

    studioBus.emit('bot:progress', {
      botId: 'vision-qa',
      status: 'done',
      task: 'Visual spec locked to World State',
      progress: 100,
    });

    return { ok: true, httpStatus: res.status, record };
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'Network error calling Gemini Vision';
    studioBus.emit('bot:progress', {
      botId: 'vision-qa',
      status: 'error',
      task: 'Vision network error',
      progress: 0,
    });
    return { ok: false, httpStatus: 0, error: msg };
  }
}
