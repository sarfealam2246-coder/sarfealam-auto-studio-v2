import type { EngineType, LanguageCode, StudioMode } from '../types/studio';

interface TopBarProps {
  language: LanguageCode;
  mode: StudioMode;
  engine: EngineType;
  onLanguageChange: (lang: LanguageCode) => void;
  onModeChange: (mode: StudioMode) => void;
  onEngineChange: (engine: EngineType) => void;
}

const ENGINES: EngineType[] = ['Auto', 'Capacitor 3D/App', 'Godot 4', 'Flutter', 'Unity'];

export function TopBar({
  language,
  mode,
  engine,
  onLanguageChange,
  onModeChange,
  onEngineChange,
}: TopBarProps) {
  return (
    <header className="sticky top-0 z-30 border-b border-cyan-500/15 bg-[#050811]/90 backdrop-blur-xl">
      <div className="mx-auto flex max-w-[1440px] flex-wrap items-center justify-between gap-x-4 gap-y-2 px-4 py-2.5">
        {/* Brand Title */}
        <div className="flex items-center gap-2.5 shrink-0">
          <div
            className="flex h-8 w-8 items-center justify-center rounded-lg border border-cyan-400/35 bg-gradient-to-br from-cyan-500/20 to-violet-500/20 shadow-[0_0_16px_rgba(34,211,238,0.18)]"
            aria-hidden="true"
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
              <circle cx="12" cy="12" r="4" stroke="#22D3EE" strokeWidth="1.8" />
              <path
                d="M12 2.5V6.5M12 17.5V21.5M2.5 12H6.5M17.5 12H21.5"
                stroke="#A78BFA"
                strokeWidth="1.8"
                strokeLinecap="round"
              />
            </svg>
          </div>
          <h1 className="font-display text-base sm:text-lg font-semibold tracking-tight text-slate-50 whitespace-nowrap shrink-0">
            Sarfealam Auto-Studio
          </h1>
        </div>

        {/* Studio Controls: Language, Mode, Engine */}
        <div className="flex flex-wrap items-center gap-2 sm:gap-2.5">
          {/* English | हिंदी Language Toggle */}
          <div
            className="inline-flex items-center rounded-lg border border-white/10 bg-[#0B1224] p-0.5"
            role="group"
            aria-label="Voice and Interface Language"
          >
            <button
              type="button"
              onClick={() => onLanguageChange('en')}
              className={`min-h-[34px] rounded-md px-2.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400 ${
                language === 'en'
                  ? 'bg-cyan-500/20 text-cyan-200 border border-cyan-400/30'
                  : 'text-slate-400 hover:text-slate-200 border border-transparent'
              }`}
            >
              English
            </button>
            <button
              type="button"
              onClick={() => onLanguageChange('hi')}
              className={`min-h-[34px] rounded-md px-2.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-400 ${
                language === 'hi'
                  ? 'bg-cyan-500/20 text-cyan-200 border border-cyan-400/30'
                  : 'text-slate-400 hover:text-slate-200 border border-transparent'
              }`}
            >
              हिंदी
            </button>
          </div>

          {/* JARVIS | Manual Mode Toggle */}
          <div
            className="inline-flex items-center rounded-lg border border-white/10 bg-[#0B1224] p-0.5"
            role="group"
            aria-label="Studio Execution Mode"
          >
            <button
              type="button"
              onClick={() => onModeChange('jarvis')}
              className={`min-h-[34px] rounded-md px-2.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-400 ${
                mode === 'jarvis'
                  ? 'bg-violet-500/25 text-violet-100 border border-violet-400/35'
                  : 'text-slate-400 hover:text-slate-200 border border-transparent'
              }`}
            >
              JARVIS
            </button>
            <button
              type="button"
              onClick={() => onModeChange('manual')}
              className={`min-h-[34px] rounded-md px-2.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-400 ${
                mode === 'manual'
                  ? 'bg-slate-700/70 text-slate-100 border border-slate-500/40'
                  : 'text-slate-400 hover:text-slate-200 border border-transparent'
              }`}
            >
              Manual
            </button>
          </div>

          {/* Engine Selector */}
          <label className="inline-flex items-center gap-1.5 rounded-lg border border-white/10 bg-[#0B1224] px-2.5 min-h-[38px]">
            <span className="text-[11px] font-medium text-slate-400 whitespace-nowrap">Engine</span>
            <select
              aria-label="Target Build Engine"
              value={engine}
              onChange={(e) => onEngineChange(e.target.value as EngineType)}
              className="bg-transparent text-xs font-semibold text-cyan-200 focus:outline-none cursor-pointer pr-1"
            >
              {ENGINES.map((eng) => (
                <option key={eng} value={eng} className="bg-[#0B1224] text-slate-100">
                  {eng}
                </option>
              ))}
            </select>
          </label>
        </div>
      </div>
    </header>
  );
}
