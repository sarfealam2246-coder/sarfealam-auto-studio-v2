import type {
  AIProviderId,
  SecretsConfig,
  SupabaseEndpointConfig,
  UserRule,
  WorldState,
} from '../types/studio';

const SECRETS_STORAGE_KEY = 'sarfealam_auto_studio_secrets_v1';
const WORLD_STORAGE_KEY = 'sarfealam_auto_studio_world_v1';

export const DEFAULT_SECRETS: SecretsConfig = {
  apiKeys: {
    gemini: '',
    groq: '',
    nvidia: '',
    openrouter: '',
    cohere: '',
  },
  activeProvider: 'auto',
  preferGeminiLive: true,
  githubUsername: 'sarfealam2246-coder',
  githubPat: '',
  assetVaultRepo: 'sarfealam2246-coder/sarfealam-3d-assets',
  studioSupabase: {
    url: '',
    anonKey: '',
  },
  appsSupabase: {
    url: '',
    anonKey: '',
  },
};

export { APPS_SUPABASE_SQL, STUDIO_SUPABASE_SQL } from './supabaseClient';

export function detectKeyProvider(rawKey: string): AIProviderId | null {
  const key = rawKey.trim();
  if (!key) return null;
  if (key.startsWith('AIza')) return 'gemini';
  if (key.startsWith('gsk_')) return 'groq';
  if (key.startsWith('nvapi-')) return 'nvidia';
  if (key.startsWith('sk-or-v1-') || key.startsWith('sk-or-')) return 'openrouter';
  if (key.length >= 36 && /^[A-Za-z0-9]{36,64}$/.test(key)) return 'cohere';
  return null;
}

export function loadSecrets(): SecretsConfig {
  try {
    const raw = localStorage.getItem(SECRETS_STORAGE_KEY);
    if (!raw) return structuredClone(DEFAULT_SECRETS);
    const parsed = JSON.parse(raw) as Partial<SecretsConfig>;
    return {
      ...DEFAULT_SECRETS,
      ...parsed,
      apiKeys: {
        ...DEFAULT_SECRETS.apiKeys,
        ...(parsed.apiKeys ?? {}),
      },
      studioSupabase: {
        ...DEFAULT_SECRETS.studioSupabase,
        ...(parsed.studioSupabase ?? {}),
      },
      appsSupabase: {
        ...DEFAULT_SECRETS.appsSupabase,
        ...(parsed.appsSupabase ?? {}),
      },
    };
  } catch {
    return structuredClone(DEFAULT_SECRETS);
  }
}

export function saveSecrets(secrets: SecretsConfig): void {
  try {
    localStorage.setItem(SECRETS_STORAGE_KEY, JSON.stringify(secrets));
  } catch (err) {
    console.error('[Storage] Failed to save secrets:', err);
  }
}

export function loadWorldState(): Partial<WorldState> | null {
  try {
    const raw = localStorage.getItem(WORLD_STORAGE_KEY);
    if (!raw) return null;
    return JSON.parse(raw) as Partial<WorldState>;
  } catch {
    return null;
  }
}

export function saveWorldState(state: WorldState): void {
  try {
    // Keep snapshot lightweight by capping stored snapshot size if needed
    const toStore: WorldState = {
      ...state,
      chatHistory: state.chatHistory.slice(-80),
    };
    localStorage.setItem(WORLD_STORAGE_KEY, JSON.stringify(toStore));
  } catch (err) {
    console.error('[Storage] Failed to persist World State:', err);
  }
}

export function clearWorldStateStorage(): void {
  try {
    localStorage.removeItem(WORLD_STORAGE_KEY);
  } catch {
    // ignore
  }
}

export async function testSupabaseEndpoint(
  config: SupabaseEndpointConfig,
  targetTable: string
): Promise<{ ok: boolean; httpStatus: number; message: string }> {
  const cleanUrl = config.url.trim().replace(/\/+$/, '');
  const cleanKey = config.anonKey.trim();

  if (!cleanUrl || !cleanKey) {
    return {
      ok: false,
      httpStatus: 0,
      message: 'Both Supabase URL and Anon Key are required.',
    };
  }

  try {
    const res = await fetch(`${cleanUrl}/rest/v1/${targetTable}?select=*&limit=1`, {
      method: 'GET',
      headers: {
        apikey: cleanKey,
        Authorization: `Bearer ${cleanKey}`,
        Accept: 'application/json',
      },
    });

    if (res.ok) {
      return {
        ok: true,
        httpStatus: res.status,
        message: `Connected — table "${targetTable}" verified (HTTP ${res.status}).`,
      };
    }

    const errText = await res.text().catch(() => '');
    if (res.status === 404 || errText.includes('does not exist') || errText.includes('PGRST205')) {
      return {
        ok: false,
        httpStatus: res.status,
        message: `Supabase reachable (HTTP ${res.status}), but table "${targetTable}" is missing. Copy & run Table SQL.`,
      };
    }

    return {
      ok: false,
      httpStatus: res.status,
      message: `HTTP ${res.status}: ${errText.slice(0, 140) || res.statusText}`,
    };
  } catch (err) {
    return {
      ok: false,
      httpStatus: 0,
      message: err instanceof Error ? err.message : 'Network error reaching Supabase.',
    };
  }
}

export async function syncRuleToStudioSupabase(
  rule: UserRule,
  config: SupabaseEndpointConfig
): Promise<boolean> {
  const cleanUrl = config.url.trim().replace(/\/+$/, '');
  const cleanKey = config.anonKey.trim();
  if (!cleanUrl || !cleanKey) return false;

  try {
    const res = await fetch(`${cleanUrl}/rest/v1/user_rules`, {
      method: 'POST',
      headers: {
        apikey: cleanKey,
        Authorization: `Bearer ${cleanKey}`,
        'Content-Type': 'application/json',
        Prefer: 'resolution=merge-duplicates',
      },
      body: JSON.stringify({
        id: rule.id,
        rule: rule.rule,
        created_at: new Date(rule.createdAt).toISOString(),
      }),
    });
    return res.ok;
  } catch {
    return false;
  }
}

export async function syncWorldStateToStudioSupabase(
  state: WorldState,
  config: SupabaseEndpointConfig
): Promise<boolean> {
  const cleanUrl = config.url.trim().replace(/\/+$/, '');
  const cleanKey = config.anonKey.trim();
  if (!cleanUrl || !cleanKey) return false;

  try {
    const res = await fetch(`${cleanUrl}/rest/v1/studio_state`, {
      method: 'POST',
      headers: {
        apikey: cleanKey,
        Authorization: `Bearer ${cleanKey}`,
        'Content-Type': 'application/json',
        Prefer: 'resolution=merge-duplicates',
      },
      body: JSON.stringify({
        id: 'primary',
        active_prompt: state.activePrompt,
        selected_engine: state.selectedEngine,
        paused: state.paused,
        current_stage: state.currentStage,
        world_snapshot: {
          language: state.language,
          mode: state.mode,
          activePanel: state.activePanel,
          fileCount: state.generatedFiles.length,
          selectedAssetsCount: state.selectedAssets.length,
          spawnedSubBots: state.spawnedSubBots.map((b) => ({ name: b.name, role: b.role })),
        },
        updated_at: new Date().toISOString(),
      }),
    });
    return res.ok;
  } catch {
    return false;
  }
}

const DYNAMIC_SKILLS_KEY = 'dynamic_skills';

export function loadDynamicSkills(): import('../types/studio').DynamicSkill[] {
  try {
    const raw = localStorage.getItem(DYNAMIC_SKILLS_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function saveDynamicSkills(skills: import('../types/studio').DynamicSkill[]): void {
  try {
    localStorage.setItem(DYNAMIC_SKILLS_KEY, JSON.stringify(skills));
  } catch (err) {
    console.error('[Storage] Failed to save dynamic_skills:', err);
  }
}

export async function syncDynamicSkillToStudioSupabase(
  skill: import('../types/studio').DynamicSkill,
  config: SupabaseEndpointConfig
): Promise<boolean> {
  const cleanUrl = config.url.trim().replace(/\/+$/, '');
  const cleanKey = config.anonKey.trim();
  if (!cleanUrl || !cleanKey) return false;

  try {
    const res = await fetch(`${cleanUrl}/rest/v1/dynamic_skills`, {
      method: 'POST',
      headers: {
        apikey: cleanKey,
        Authorization: `Bearer ${cleanKey}`,
        'Content-Type': 'application/json',
        Prefer: 'resolution=merge-duplicates',
      },
      body: JSON.stringify({
        id: skill.id,
        name: skill.name,
        role: skill.description,
        skill_payload: {
          url: skill.url,
          httpStatus: skill.httpStatus,
          sampleKeys: skill.sampleKeys,
        },
        created_at: new Date(skill.createdAt).toISOString(),
      }),
    });
    return res.ok;
  } catch {
    return false;
  }
}

const CHECKPOINTS_STORAGE_KEY = 'sarfealam_rollback_checkpoints_v1';

export function loadCheckpoints(): import('../types/studio').RollbackCheckpoint[] {
  try {
    const raw = localStorage.getItem(CHECKPOINTS_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function saveCheckpoints(checkpoints: import('../types/studio').RollbackCheckpoint[]): void {
  try {
    localStorage.setItem(CHECKPOINTS_STORAGE_KEY, JSON.stringify(checkpoints.slice(0, 12)));
  } catch (err) {
    console.warn('[Storage] Trimming checkpoints due to localStorage quota:', err);
    try {
      localStorage.setItem(CHECKPOINTS_STORAGE_KEY, JSON.stringify(checkpoints.slice(0, 4)));
    } catch {
      // ignore
    }
  }
}

