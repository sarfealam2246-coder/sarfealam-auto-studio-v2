import type {
  AIProviderId,
  EngineType,
  LanguageCode,
  PanelType,
  ProviderTestResult,
  SecretsConfig,
  StudioMode,
  WorldState,
} from '../types/studio';

export interface ToolCallRequest {
  id: string;
  name: string;
  args: Record<string, unknown>;
}

export interface AIRouterResponse {
  provider: AIProviderId | 'local-actuator';
  model: string;
  text: string;
  toolCalls: ToolCallRequest[];
  error?: string;
}

export interface ProviderMeta {
  id: AIProviderId;
  label: string;
  placeholder: string;
  prefixHint: string;
  defaultModel: string;
  fallbackModel?: string;
  endpoint: string;
}

export const AI_PROVIDERS: Record<AIProviderId, ProviderMeta> = {
  gemini: {
    id: 'gemini',
    label: 'Google Gemini',
    placeholder: 'AIzaSy...',
    prefixHint: 'Starts with AIza',
    defaultModel: 'gemini-2.5-flash',
    endpoint: 'https://generativelanguage.googleapis.com/v1beta',
  },
  groq: {
    id: 'groq',
    label: 'Groq Cloud',
    placeholder: 'gsk_...',
    prefixHint: 'Starts with gsk_',
    defaultModel: 'openai/gpt-oss-120b',
    fallbackModel: 'llama-3.3-70b-versatile',
    endpoint: 'https://api.groq.com/openai/v1/chat/completions',
  },
  nvidia: {
    id: 'nvidia',
    label: 'NVIDIA NIM',
    placeholder: 'nvapi-...',
    prefixHint: 'Starts with nvapi-',
    defaultModel: 'meta/llama-3.3-70b-instruct',
    endpoint: 'https://integrate.api.nvidia.com/v1/chat/completions',
  },
  openrouter: {
    id: 'openrouter',
    label: 'OpenRouter',
    placeholder: 'sk-or-v1-...',
    prefixHint: 'Starts with sk-or-v1-',
    defaultModel: 'google/gemini-2.5-flash',
    fallbackModel: 'meta-llama/llama-3.3-70b-instruct:free',
    endpoint: 'https://openrouter.ai/api/v1/chat/completions',
  },
  cohere: {
    id: 'cohere',
    label: 'Cohere',
    placeholder: 'Cohere API key...',
    prefixHint: '40-char alphanumeric key',
    defaultModel: 'command-r-plus-08-2024',
    endpoint: 'https://api.cohere.com/v2/chat',
  },
};

export interface CanonicalToolSpec {
  name: string;
  description: string;
  parameters: {
    type: 'object';
    properties: Record<
      string,
      {
        type: 'string' | 'boolean';
        description: string;
        enum?: string[];
      }
    >;
    required?: string[];
  };
}

export const JARVIS_TOOLS: CanonicalToolSpec[] = [
  {
    name: 'open_panel',
    description:
      'Open or close a Sarfealam Auto-Studio workspace panel (secrets vault, generated code viewer, 3D asset vault, admin & rules, camera vision QA, or none to close).',
    parameters: {
      type: 'object',
      properties: {
        panel: {
          type: 'string',
          enum: ['secrets', 'code', 'vault', 'admin', 'camera', 'none'],
          description: 'Panel to open, or "none" to close the active panel.',
        },
      },
      required: ['panel'],
    },
  },
  {
    name: 'toggle_fullscreen',
    description: 'Expand or collapse Display A viewport fullscreen mode.',
    parameters: {
      type: 'object',
      properties: {
        enabled: {
          type: 'boolean',
          description: 'True to expand Display A fullscreen, false to collapse.',
        },
      },
      required: ['enabled'],
    },
  },
  {
    name: 'switch_language',
    description: 'Switch studio interface and JARVIS spoken voice language between English (en) and Hindi (hi).',
    parameters: {
      type: 'object',
      properties: {
        lang: {
          type: 'string',
          enum: ['en', 'hi'],
          description: '"en" for English (en-IN) or "hi" for Hindi (hi-IN).',
        },
      },
      required: ['lang'],
    },
  },
  {
    name: 'switch_mode',
    description: 'Switch studio control mode between autonomous JARVIS mode and Manual mode.',
    parameters: {
      type: 'object',
      properties: {
        mode: {
          type: 'string',
          enum: ['jarvis', 'manual'],
          description: '"jarvis" for autonomous execution or "manual" for step-by-step manual control.',
        },
      },
      required: ['mode'],
    },
  },
  {
    name: 'set_engine',
    description: 'Select the target build engine for the studio project.',
    parameters: {
      type: 'object',
      properties: {
        engine: {
          type: 'string',
          enum: ['Auto', 'Capacitor 3D/App', 'Godot 4', 'Flutter', 'Unity'],
          description: 'Target runtime/game engine.',
        },
      },
      required: ['engine'],
    },
  },
  {
    name: 'pause_work',
    description:
      'Freeze the active build execution cursor immediately without disconnecting Voice, GitHub, or Supabase and without deleting generated files.',
    parameters: {
      type: 'object',
      properties: {},
    },
  },
  {
    name: 'inspect_work',
    description:
      'Inspect current generated files, active build stage, and Display A workspace state (especially while paused) and report status aloud.',
    parameters: {
      type: 'object',
      properties: {},
    },
  },
  {
    name: 'resume_work',
    description: 'Resume execution from the exact paused stage and cursor.',
    parameters: {
      type: 'object',
      properties: {},
    },
  },
  {
    name: 'spawn_sub_bot',
    description: 'Dynamically spawn a new specialist sub-bot pod in the Landscape of Signals Command Center.',
    parameters: {
      type: 'object',
      properties: {
        name: {
          type: 'string',
          description: 'Short specialist name, e.g., "Shader Synth" or "Audio Rig".',
        },
        role: {
          type: 'string',
          description: 'Concise specialist responsibility, e.g., "PBR material tuning".',
        },
      },
      required: ['name', 'role'],
    },
  },
  {
    name: 'save_user_rule',
    description: 'Persist a permanent user preference or engineering rule into localStorage and Studio Supabase.',
    parameters: {
      type: 'object',
      properties: {
        rule: {
          type: 'string',
          description: 'The permanent rule to remember for all future builds.',
        },
      },
      required: ['rule'],
    },
  },
  {
    name: 'start_build_pipeline',
    description:
      'Start or update the 5-stage autonomous studio build pipeline for a user app or game prompt.',
    parameters: {
      type: 'object',
      properties: {
        prompt: {
          type: 'string',
          description: 'What app, 3D scene, or game to build in the studio.',
        },
      },
      required: ['prompt'],
    },
  },
  {
    name: 'fetch_project_assets',
    description:
      'Hunt matching 3D .glb models, PolyHaven PBR textures, HDRI skies, .wav audio SFX, Wikimedia Commons photos, and Iconify vector icons before generating final game/app code, displaying them in Display A for user Keep/Reject selection.',
    parameters: {
      type: 'object',
      properties: {
        prompt: {
          type: 'string',
          description: 'Project topic or asset keywords to search for.',
        },
        mode: {
          type: 'string',
          enum: ['auto', 'game_3d', 'commercial_app'],
          description: 'Whether to prioritize 3D game assets or commercial app photos/icons.',
        },
      },
      required: ['prompt'],
    },
  },
  {
    name: 'select_assets',
    description:
      'Apply voice or text Keep/Reject/Replace/Confirm selections to the Asset Picker cards in Display A (e.g., "Keep the first and third, reject the second" or "Find another army truck").',
    parameters: {
      type: 'object',
      properties: {
        keep_indices: {
          type: 'string',
          description: 'Comma-separated 1-based indices of cards to keep, e.g. "1,3".',
        },
        reject_indices: {
          type: 'string',
          description: 'Comma-separated 1-based indices of cards to reject and replace, e.g. "2".',
        },
        replace_query: {
          type: 'string',
          description: 'Specific asset search phrase to find a replacement, e.g. "army truck".',
        },
        confirm: {
          type: 'boolean',
          description: 'Set true to confirm all kept assets and proceed to Design/Codegen.',
        },
      },
    },
  },
  {
    name: 'generate_image',
    description:
      'Generate a custom banner, app logo, splash art, or texture using Gemini Image Generation and preview it in Display A.',
    parameters: {
      type: 'object',
      properties: {
        prompt: {
          type: 'string',
          description: 'Detailed visual description of the image to generate.',
        },
      },
      required: ['prompt'],
    },
  },
  {
    name: 'generate_video_cutscene',
    description:
      'Handle a video or animated cut-scene request. If cloud video generation is unavailable on the key, honestly inform the user and generate an interactive HTML5 3D animated cut-scene in Display A.',
    parameters: {
      type: 'object',
      properties: {
        prompt: {
          type: 'string',
          description: 'Description of the requested video or animated cut-scene.',
        },
      },
      required: ['prompt'],
    },
  },
  {
    name: 'fetch_any_api',
    description:
      'Connect to any open JSON or web API URL on demand, inspect its response fields, and save it as a reusable Dynamic Skill in localStorage.',
    parameters: {
      type: 'object',
      properties: {
        url: {
          type: 'string',
          description: 'Full https:// URL of the open JSON/web endpoint.',
        },
        skill_name: {
          type: 'string',
          description: 'Optional human-friendly name for the learned skill.',
        },
        description: {
          type: 'string',
          description: 'Optional brief note on what this API provides.',
        },
      },
      required: ['url'],
    },
  },
  {
    name: 'patch_live_code',
    description:
      'Hot-patch the live playable code in Display A without resetting the project (e.g., "change truck color", "make headlights brighter", "add discount banner", or fix a runtime error). Automatically creates a 1-second Rollback Checkpoint in Vault.',
    parameters: {
      type: 'object',
      properties: {
        instruction: {
          type: 'string',
          description: 'Exact visual, gameplay, audio, or UI modification to apply to the live code.',
        },
      },
      required: ['instruction'],
    },
  },
  {
    name: 'publish_github_apk',
    description:
      'Push all generated project files, real APK workflows, and PIN-locked Owner Admin Web panel in ONE SINGLE ATOMIC COMMIT via GitHub Git Trees API, enable GitHub Pages (/docs), and start the autonomous self-healing Actions APK build loop.',
    parameters: {
      type: 'object',
      properties: {
        repo_name: {
          type: 'string',
          description: 'Optional custom GitHub repository name (defaults to sanitized project name).',
        },
      },
    },
  },
  {
    name: 'download_local_zip',
    description:
      'Package the complete generated project, workflows, and Owner Admin docs into a local ZIP archive via jszip for immediate download.',
    parameters: {
      type: 'object',
      properties: {},
    },
  },
];

export function buildGeminiFunctionDeclarations() {
  return JARVIS_TOOLS.map((tool) => ({
    name: tool.name,
    description: tool.description,
    parameters: {
      type: 'OBJECT',
      properties: Object.fromEntries(
        Object.entries(tool.parameters.properties).map(([k, v]) => [
          k,
          {
            type: v.type.toUpperCase(),
            description: v.description,
            ...(v.enum ? { enum: v.enum } : {}),
          },
        ])
      ),
      ...(tool.parameters.required ? { required: tool.parameters.required } : {}),
    },
  }));
}

function buildOpenAITools() {
  return JARVIS_TOOLS.map((tool) => ({
    type: 'function',
    function: {
      name: tool.name,
      description: tool.description,
      parameters: tool.parameters,
    },
  }));
}

export function buildJarvisSystemPrompt(state: WorldState): string {
  const rulesText =
    state.userRules.length > 0
      ? state.userRules.map((r, i) => `${i + 1}. ${r.rule}`).join('\n')
      : 'None saved yet.';

  const langDirective =
    state.language === 'hi'
      ? 'Respond concisely in natural conversational Hindi (Devanagari or Hinglish) suited for voice readout.'
      : 'Respond concisely in crisp, respectful English ("Sir") suited for low-latency spoken voice readout.';

  const candidateSummary =
    state.candidateAssets.length > 0
      ? state.candidateAssets
          .map((a, idx) => `#${idx + 1} ${a.name} [${a.category}, ${a.status}]`)
          .join('; ')
      : 'None loaded';

  return [
    'You are JARVIS, the autonomous voice and UI kernel inside Sarfealam Auto-Studio (a standalone Capacitor 6 Android studio).',
    langDirective,
    'Whenever the user asks to open a panel, toggle fullscreen, switch language, switch mode, change engine, pause, inspect, resume, spawn a sub-bot, save a rule, fetch project assets, keep/reject/replace assets, generate an image or video cut-scene, connect to any API URL, or build an app/game, ALWAYS invoke the matching tool call directly.',
    'Keep spoken replies under 2-3 clear sentences without markdown asterisks or code fences unless specifically asked.',
    '',
    'LIVE WORLD STATE:',
    `- Active Prompt: ${state.activePrompt || 'None'}`,
    `- Engine: ${state.selectedEngine}`,
    `- Mode: ${state.mode}`,
    `- Language: ${state.language === 'hi' ? 'Hindi (hi-IN)' : 'English (en-IN)'}`,
    `- Paused: ${state.paused}`,
    `- Stage: ${state.currentStage}/5 (${state.stageLabel})`,
    `- Active Panel: ${state.activePanel}`,
    `- Candidate Assets in Display A: ${candidateSummary}`,
    `- Locked Selected Assets: ${state.selectedAssets.length} (confirmed: ${state.assetsConfirmed})`,
    `- Vision Eye Spec: ${state.visionAnalysis ? state.visionAnalysis.summary : 'None'}`,
    `- Generated Media: ${state.generatedMedia.length} item(s)`,
    `- Learned Dynamic Skills: ${state.dynamicSkills.map((s) => s.name).join(', ') || 'None'}`,
    `- Generated Files (${state.generatedFiles.length}): ${state.generatedFiles.map((f) => f.path).join(', ') || 'None'}`,
    `- Spawned Sub-Bots: ${state.spawnedSubBots.map((b) => `${b.name} (${b.role})`).join(', ') || 'None'}`,
    '',
    'USER PERMANENT RULES:',
    rulesText,
  ].join('\n');
}

export function resolveActiveProvider(secrets: SecretsConfig): {
  provider: AIProviderId;
  apiKey: string;
} | null {
  const priority: AIProviderId[] = ['gemini', 'groq', 'nvidia', 'openrouter', 'cohere'];
  if (secrets.activeProvider !== 'auto') {
    const key = secrets.apiKeys[secrets.activeProvider]?.trim();
    if (key) return { provider: secrets.activeProvider, apiKey: key };
  }
  for (const id of priority) {
    const key = secrets.apiKeys[id]?.trim();
    if (key) return { provider: id, apiKey: key };
  }
  return null;
}

function extractOrdinals(fragment: string): number[] {
  const map: Record<string, number> = {
    first: 1, '1st': 1, one: 1, '1': 1, पहला: 1,
    second: 2, '2nd': 2, two: 2, '2': 2, दूसरा: 2,
    third: 3, '3rd': 3, three: 3, '3': 3, तीसरा: 3,
    fourth: 4, '4th': 4, four: 4, '4': 4, चौथा: 4,
    fifth: 5, '5th': 5, five: 5, '5': 5,
    sixth: 6, '6th': 6, six: 6, '6': 6,
    seventh: 7, '7th': 7, seven: 7, '7': 7,
    eighth: 8, '8th': 8, eight: 8, '8': 8,
  };
  const found = new Set<number>();
  const tokens = fragment.toLowerCase().match(/[a-z0-9\u0900-\u097F]+/g) || [];
  for (const tok of tokens) {
    if (map[tok]) found.add(map[tok]);
  }
  return Array.from(found).sort((a, b) => a - b);
}

/**
 * Deterministic Robot UI Actuator parser.
 * Executes explicit UI commands cleanly even before an AI API key is entered,
 * and ensures instantaneous reliability for direct studio controls.
 */
export function parseDirectCommandIntent(input: string): ToolCallRequest[] {
  const text = input.trim();
  const lower = text.toLowerCase();
  const calls: ToolCallRequest[] = [];
  const mkId = (suffix: string) => `local_${Date.now()}_${suffix}`;

  // Panel commands
  if (/(open|show|go to)\s+(the\s+)?secrets|api key|vault config|खोलो सीक्रेट|सीक्रेट्स/.test(lower)) {
    calls.push({ id: mkId('panel'), name: 'open_panel', args: { panel: 'secrets' as PanelType } });
  } else if (/(open|show|view)\s+(the\s+)?code|files|editor|कोड दिखाओ/.test(lower)) {
    calls.push({ id: mkId('panel'), name: 'open_panel', args: { panel: 'code' as PanelType } });
  } else if (/(open|show|browse)\s+(the\s+)?(3d\s+)?vault|वॉल्ट/.test(lower)) {
    calls.push({ id: mkId('panel'), name: 'open_panel', args: { panel: 'vault' as PanelType } });
  } else if (/(open|show)\s+(the\s+)?admin|rules|world state|एडमिन/.test(lower)) {
    calls.push({ id: mkId('panel'), name: 'open_panel', args: { panel: 'admin' as PanelType } });
  } else if (/(open|show|start)\s+(the\s+)?camera|vision|कैमरा/.test(lower)) {
    calls.push({ id: mkId('panel'), name: 'open_panel', args: { panel: 'camera' as PanelType } });
  } else if (/(close|hide)\s+(the\s+)?panel|go home|home screen|बंद करो/.test(lower)) {
    calls.push({ id: mkId('panel'), name: 'open_panel', args: { panel: 'none' as PanelType } });
  }

  // Fullscreen commands
  if (/(exit|collapse|close|disable)\s+fullscreen|minimize display/.test(lower)) {
    calls.push({ id: mkId('fs'), name: 'toggle_fullscreen', args: { enabled: false } });
  } else if (/(enter|enable|expand|open|go)\s+fullscreen|full screen|फुलस्क्रीन/.test(lower)) {
    calls.push({ id: mkId('fs'), name: 'toggle_fullscreen', args: { enabled: true } });
  }

  // Language commands
  if (/(switch|change|set|speak)\s+(to\s+)?hindi|हिंदी में/.test(lower) || lower === 'hindi' || lower === 'हिंदी') {
    calls.push({ id: mkId('lang'), name: 'switch_language', args: { lang: 'hi' as LanguageCode } });
  } else if (/(switch|change|set|speak)\s+(to\s+)?english|अंग्रेजी/.test(lower) || lower === 'english') {
    calls.push({ id: mkId('lang'), name: 'switch_language', args: { lang: 'en' as LanguageCode } });
  }

  // Mode commands
  if (/(switch|set|go)\s+(to\s+)?manual(\s+mode)?|मैनुअल/.test(lower)) {
    calls.push({ id: mkId('mode'), name: 'switch_mode', args: { mode: 'manual' as StudioMode } });
  } else if (/(switch|set|go)\s+(to\s+)?jarvis(\s+mode)?|ऑटो मोड/.test(lower)) {
    calls.push({ id: mkId('mode'), name: 'switch_mode', args: { mode: 'jarvis' as StudioMode } });
  }

  // Engine commands
  if (/(set|switch|use|select)\s+(engine\s+)?(to\s+)?godot/.test(lower)) {
    calls.push({ id: mkId('eng'), name: 'set_engine', args: { engine: 'Godot 4' as EngineType } });
  } else if (/(set|switch|use|select)\s+(engine\s+)?(to\s+)?flutter/.test(lower)) {
    calls.push({ id: mkId('eng'), name: 'set_engine', args: { engine: 'Flutter' as EngineType } });
  } else if (/(set|switch|use|select)\s+(engine\s+)?(to\s+)?unity/.test(lower)) {
    calls.push({ id: mkId('eng'), name: 'set_engine', args: { engine: 'Unity' as EngineType } });
  } else if (/(set|switch|use|select)\s+(engine\s+)?(to\s+)?capacitor/.test(lower)) {
    calls.push({ id: mkId('eng'), name: 'set_engine', args: { engine: 'Capacitor 3D/App' as EngineType } });
  } else if (/(set|switch|use|select)\s+engine\s+(to\s+)?auto/.test(lower)) {
    calls.push({ id: mkId('eng'), name: 'set_engine', args: { engine: 'Auto' as EngineType } });
  }

  // Pause / Inspect / Resume
  if (/\b(pause|freeze|hold|stop work|रुको|पॉज़)\b/.test(lower)) {
    calls.push({ id: mkId('pause'), name: 'pause_work', args: {} });
  }
  if (/\b(inspect|check status|inspect work|audit|जाँच|स्टेटस)\b/.test(lower)) {
    calls.push({ id: mkId('inspect'), name: 'inspect_work', args: {} });
  }
  if (/\b(resume|continue|unpause|आगे बढ़ो|रिज्यूम)\b/.test(lower)) {
    calls.push({ id: mkId('resume'), name: 'resume_work', args: {} });
  }

  // Phase 2: Universal API Connector (fetch_any_api)
  const urlMatch = text.match(/https?:\/\/[^\s"'<>]+/i);
  if (urlMatch && /(fetch|connect|learn|api|endpoint|skill|call)/i.test(lower)) {
    calls.push({
      id: mkId('api'),
      name: 'fetch_any_api',
      args: { url: urlMatch[0] },
    });
  }

  // Phase 2: Gemini Image Generation
  const imgMatch = text.match(/(?:generate|create|make|draw)\s+(?:an?\s+)?(?:image|banner|logo|texture|poster|icon|art)\s*(?:of|for|:)?\s*(.+)$/i);
  if (imgMatch && imgMatch[1].trim().length > 2) {
    calls.push({
      id: mkId('img'),
      name: 'generate_image',
      args: { prompt: imgMatch[1].trim() },
    });
  }

  // Phase 2: Video / Animated Cut-Scene fallback
  const vidMatch = text.match(/(?:generate|create|make)\s+(?:a\s+|an\s+)?(?:video|cut[- ]?scene|cinematic|trailer|animation)\s*(?:of|for|:)?\s*(.*)$/i);
  if (vidMatch && calls.length === 0) {
    calls.push({
      id: mkId('vid'),
      name: 'generate_video_cutscene',
      args: { prompt: (vidMatch[1] || text).trim() },
    });
  }

  // Phase 2: Asset Picker Keep / Reject / Replace / Confirm voice commands
  if (/\b(keep|reject|replace)\b/i.test(lower) && calls.length === 0) {
    const keepClause = lower.match(/keep\s+([^,.;]+?)(?=\s*(?:and\s+)?reject|\s*$|,|\.)/);
    const rejectClause = lower.match(/(?:reject|drop|remove)\s+([^,.;]+?)(?=\s*(?:and\s+)?keep|\s*$|,|\.)/);
    const keepIdx = keepClause ? extractOrdinals(keepClause[1]) : [];
    const rejectIdx = rejectClause ? extractOrdinals(rejectClause[1]) : [];
    if (keepIdx.length > 0 || rejectIdx.length > 0) {
      calls.push({
        id: mkId('sel'),
        name: 'select_assets',
        args: {
          ...(keepIdx.length ? { keep_indices: keepIdx.join(',') } : {}),
          ...(rejectIdx.length ? { reject_indices: rejectIdx.join(',') } : {}),
        },
      });
    }
  }

  const anotherMatch = text.match(/(?:find|get|swap|replace with)\s+(?:another|a different|new)\s+(.+)$/i);
  if (anotherMatch && calls.length === 0) {
    calls.push({
      id: mkId('replace'),
      name: 'select_assets',
      args: { replace_query: anotherMatch[1].trim() },
    });
  }

  if (/(confirm|lock)\s+(?:selected\s+)?assets/i.test(lower) && calls.length === 0) {
    calls.push({
      id: mkId('confirm_assets'),
      name: 'select_assets',
      args: { confirm: true },
    });
  }

  // Phase 2: Hunt / Fetch project assets
  const assetHuntMatch = text.match(/(?:fetch|find|hunt|search|get)\s+(?:project\s+)?assets\s*(?:for|:)?\s*(.+)$/i);
  if (assetHuntMatch && calls.length === 0) {
    calls.push({
      id: mkId('hunt'),
      name: 'fetch_project_assets',
      args: { prompt: assetHuntMatch[1].trim(), mode: 'auto' },
    });
  }

  // Phase 4: Atomic GitHub Push & Cloud APK Build / Download Local ZIP
  if (/(download|export)\s+(local\s+)?zip/i.test(lower) && calls.length === 0) {
    calls.push({
      id: mkId('zip'),
      name: 'download_local_zip',
      args: {},
    });
  } else if (/(push|publish|deploy|export)\s+(to\s+)?github|build\s+cloud\s+apk|trigger\s+apk\s+workflow/i.test(lower) && calls.length === 0) {
    calls.push({
      id: mkId('gh_apk'),
      name: 'publish_github_apk',
      args: {},
    });
  }

  // Spawn sub-bot
  const spawnMatch = text.match(/spawn\s+(?:sub[- ]?bot\s+|bot\s+)?([a-zA-Z0-9 _-]{2,28})(?:\s+(?:for|as|role)\s+(.+))?$/i);
  if (spawnMatch) {
    calls.push({
      id: mkId('spawn'),
      name: 'spawn_sub_bot',
      args: {
        name: spawnMatch[1].trim(),
        role: (spawnMatch[2] || 'Autonomous specialist task').trim(),
      },
    });
  }

  // Save user rule
  const ruleMatch = text.match(/(?:save rule|remember rule|add rule|always remember)[:\s]+(.+)$/i);
  if (ruleMatch && ruleMatch[1].trim().length > 2) {
    calls.push({
      id: mkId('rule'),
      name: 'save_user_rule',
      args: { rule: ruleMatch[1].trim() },
    });
  }

  // Phase 3: Live Code Hot-Patch intent (change/make/add/tweak/fix/patch on live preview)
  if (
    /^(?:patch|tweak|modify|update|change|make|add|fix)\s+.{4,}/i.test(text) &&
    !/^(?:make|create|build)\s+(?:a\s+|an\s+)?(?:new\s+)?(?:3d\s+)?(?:app|game|simulator|store)/i.test(text) &&
    calls.length === 0
  ) {
    calls.push({
      id: mkId('patch'),
      name: 'patch_live_code',
      args: { instruction: text },
    });
  }

  // Build command
  const buildMatch = text.match(/^(?:build|create|make|generate)\s+(?:a\s+|an\s+)?(.{4,})/i);
  if (buildMatch && calls.length === 0) {
    calls.push({
      id: mkId('build'),
      name: 'start_build_pipeline',
      args: { prompt: text },
    });
  }

  return calls;
}

async function callGemini(
  apiKey: string,
  systemPrompt: string,
  userMessage: string,
  history: Array<{ role: 'user' | 'model'; text: string }>
): Promise<AIRouterResponse> {
  const model = AI_PROVIDERS.gemini.defaultModel;
  const url = `${AI_PROVIDERS.gemini.endpoint}/models/${model}:generateContent?key=${encodeURIComponent(apiKey)}`;

  const contents = [
    ...history.slice(-10).map((m) => ({
      role: m.role,
      parts: [{ text: m.text }],
    })),
    { role: 'user', parts: [{ text: userMessage }] },
  ];

  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      systemInstruction: { parts: [{ text: systemPrompt }] },
      contents,
      tools: [{ functionDeclarations: buildGeminiFunctionDeclarations() }],
      toolConfig: { functionCallingConfig: { mode: 'AUTO' } },
    }),
  });

  if (!res.ok) {
    const body = await res.text().catch(() => '');
    throw new Error(`Gemini HTTP ${res.status}: ${body.slice(0, 180) || res.statusText}`);
  }

  const data = await res.json();
  const parts = data?.candidates?.[0]?.content?.parts ?? [];
  const textParts: string[] = [];
  const toolCalls: ToolCallRequest[] = [];

  for (const part of parts) {
    if (typeof part.text === 'string' && part.text.trim()) {
      textParts.push(part.text.trim());
    }
    if (part.functionCall?.name) {
      toolCalls.push({
        id: `gem_${Date.now()}_${toolCalls.length}`,
        name: part.functionCall.name,
        args: (part.functionCall.args as Record<string, unknown>) ?? {},
      });
    }
  }

  return {
    provider: 'gemini',
    model,
    text: textParts.join(' '),
    toolCalls,
  };
}

async function callOpenAICompatible(
  provider: 'groq' | 'nvidia' | 'openrouter',
  apiKey: string,
  systemPrompt: string,
  userMessage: string,
  history: Array<{ role: 'user' | 'model'; text: string }>
): Promise<AIRouterResponse> {
  const meta = AI_PROVIDERS[provider];
  const modelsToTry = meta.fallbackModel ? [meta.defaultModel, meta.fallbackModel] : [meta.defaultModel];

  const messages = [
    { role: 'system', content: systemPrompt },
    ...history.slice(-10).map((m) => ({
      role: m.role === 'model' ? 'assistant' : 'user',
      content: m.text,
    })),
    { role: 'user', content: userMessage },
  ];

  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    Authorization: `Bearer ${apiKey}`,
  };
  if (provider === 'openrouter') {
    headers['HTTP-Referer'] = 'https://sarfealam.autostudio.app';
    headers['X-Title'] = 'Sarfealam Auto-Studio';
  }

  let lastError = '';
  for (const model of modelsToTry) {
    const res = await fetch(meta.endpoint, {
      method: 'POST',
      headers,
      body: JSON.stringify({
        model,
        messages,
        tools: buildOpenAITools(),
        tool_choice: 'auto',
        temperature: 0.3,
      }),
    });

    if (res.ok) {
      const data = await res.json();
      const message = data?.choices?.[0]?.message;
      const text = typeof message?.content === 'string' ? message.content.trim() : '';
      const rawCalls = Array.isArray(message?.tool_calls) ? message.tool_calls : [];
      const toolCalls: ToolCallRequest[] = rawCalls.map((tc: { id?: string; function?: { name?: string; arguments?: string } }, i: number) => {
        let parsedArgs: Record<string, unknown> = {};
        try {
          parsedArgs = tc.function?.arguments ? JSON.parse(tc.function.arguments) : {};
        } catch {
          parsedArgs = {};
        }
        return {
          id: tc.id || `${provider}_${Date.now()}_${i}`,
          name: tc.function?.name || '',
          args: parsedArgs,
        };
      }).filter((tc: ToolCallRequest) => Boolean(tc.name));

      return { provider, model, text, toolCalls };
    }

    const body = await res.text().catch(() => '');
    lastError = `${meta.label} (${model}) HTTP ${res.status}: ${body.slice(0, 160) || res.statusText}`;
    // Retry fallback model only on 400/404 model unavailability
    if (res.status !== 400 && res.status !== 404) {
      throw new Error(lastError);
    }
  }

  throw new Error(lastError || `${meta.label} request failed`);
}

async function callCohere(
  apiKey: string,
  systemPrompt: string,
  userMessage: string,
  history: Array<{ role: 'user' | 'model'; text: string }>
): Promise<AIRouterResponse> {
  const model = AI_PROVIDERS.cohere.defaultModel;
  const messages = [
    { role: 'system', content: systemPrompt },
    ...history.slice(-10).map((m) => ({
      role: m.role === 'model' ? 'assistant' : 'user',
      content: m.text,
    })),
    { role: 'user', content: userMessage },
  ];

  const res = await fetch(AI_PROVIDERS.cohere.endpoint, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model,
      messages,
      tools: buildOpenAITools(),
    }),
  });

  if (!res.ok) {
    const body = await res.text().catch(() => '');
    throw new Error(`Cohere HTTP ${res.status}: ${body.slice(0, 180) || res.statusText}`);
  }

  const data = await res.json();
  const contentBlocks = Array.isArray(data?.message?.content) ? data.message.content : [];
  const text = contentBlocks
    .filter((b: { type?: string; text?: string }) => b.type === 'text' && typeof b.text === 'string')
    .map((b: { text: string }) => b.text)
    .join(' ')
    .trim();

  const rawCalls = Array.isArray(data?.message?.tool_calls) ? data.message.tool_calls : [];
  const toolCalls: ToolCallRequest[] = rawCalls.map((tc: { id?: string; function?: { name?: string; arguments?: string } }, i: number) => {
    let parsedArgs: Record<string, unknown> = {};
    try {
      parsedArgs = tc.function?.arguments ? JSON.parse(tc.function.arguments) : {};
    } catch {
      parsedArgs = {};
    }
    return {
      id: tc.id || `cohere_${Date.now()}_${i}`,
      name: tc.function?.name || '',
      args: parsedArgs,
    };
  }).filter((tc: ToolCallRequest) => Boolean(tc.name));

  return { provider: 'cohere', model, text, toolCalls };
}

export async function routeJarvisCommand(
  userMessage: string,
  state: WorldState,
  secrets: SecretsConfig
): Promise<AIRouterResponse> {
  const resolved = resolveActiveProvider(secrets);
  const systemPrompt = buildJarvisSystemPrompt(state);
  const history = state.chatHistory
    .filter((m) => m.role === 'user' || m.role === 'jarvis')
    .map((m) => ({
      role: m.role === 'user' ? ('user' as const) : ('model' as const),
      text: m.text,
    }));

  if (!resolved) {
    const localCalls = parseDirectCommandIntent(userMessage);
    if (localCalls.length > 0) {
      return {
        provider: 'local-actuator',
        model: 'deterministic-actuator',
        text: '',
        toolCalls: localCalls,
      };
    }

    const msg =
      state.language === 'hi'
        ? 'कृपया Secrets पैनल में Gemini, Groq, NVIDIA, OpenRouter या Cohere की API कुंजी जोड़ें। आप अभी भी "open secrets", "pause", "inspect", या "build" कमांड चला सकते हैं।'
        : 'No AI provider key is saved yet, Sir. Open the Secrets panel to add Gemini, Groq, NVIDIA, OpenRouter, or Cohere. Direct actuator commands like "open secrets", "pause", "inspect", or "build ..." work immediately.';
    return {
      provider: 'local-actuator',
      model: 'deterministic-actuator',
      text: msg,
      toolCalls: [],
    };
  }

  try {
    const { provider, apiKey } = resolved;
    if (provider === 'gemini') {
      return await callGemini(apiKey, systemPrompt, userMessage, history);
    }
    if (provider === 'cohere') {
      return await callCohere(apiKey, systemPrompt, userMessage, history);
    }
    return await callOpenAICompatible(provider, apiKey, systemPrompt, userMessage, history);
  } catch (err) {
    const errMsg = err instanceof Error ? err.message : 'Unknown provider error';
    const localFallback = parseDirectCommandIntent(userMessage);
    return {
      provider: resolved.provider,
      model: AI_PROVIDERS[resolved.provider].defaultModel,
      text: localFallback.length > 0 ? '' : `Provider error: ${errMsg}`,
      toolCalls: localFallback,
      error: errMsg,
    };
  }
}

export interface ActiveLLMCallResult {
  ok: boolean;
  provider: AIProviderId;
  model: string;
  text: string;
  httpStatus: number;
  error?: string;
}

/**
 * Reusable direct-client LLM caller for the Zero-Shortcut 5-Stage Code Generator & Hot-Patch engine.
 * Routes through whichever provider key is active in Secrets Vault via CapacitorHttp / fetch().
 */
export async function callActiveLLM(
  systemPrompt: string,
  userPrompt: string,
  secrets: SecretsConfig,
  options?: { jsonMode?: boolean; temperature?: number }
): Promise<ActiveLLMCallResult> {
  const resolved = resolveActiveProvider(secrets);
  if (!resolved) {
    return {
      ok: false,
      provider: 'gemini',
      model: 'none',
      text: '',
      httpStatus: 0,
      error: 'No AI provider key configured in Secrets Vault.',
    };
  }

  const { provider, apiKey } = resolved;
  const meta = AI_PROVIDERS[provider];
  const temperature = options?.temperature ?? 0.2;

  try {
    if (provider === 'gemini') {
      const model = meta.defaultModel;
      const url = `${meta.endpoint}/models/${model}:generateContent?key=${encodeURIComponent(apiKey)}`;
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          systemInstruction: { parts: [{ text: systemPrompt }] },
          contents: [{ role: 'user', parts: [{ text: userPrompt }] }],
          generationConfig: {
            temperature,
            ...(options?.jsonMode ? { responseMimeType: 'application/json' } : {}),
          },
        }),
      });
      if (!res.ok) {
        const body = await res.text().catch(() => '');
        return {
          ok: false,
          provider,
          model,
          text: '',
          httpStatus: res.status,
          error: `Gemini HTTP ${res.status}: ${body.slice(0, 180) || res.statusText}`,
        };
      }
      const data = await res.json();
      const text = (data?.candidates?.[0]?.content?.parts ?? [])
        .map((p: { text?: string }) => p.text || '')
        .join('')
        .trim();
      return { ok: true, provider, model, text, httpStatus: res.status };
    }

    if (provider === 'cohere') {
      const model = meta.defaultModel;
      const res = await fetch(meta.endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model,
          messages: [
            { role: 'system', content: systemPrompt },
            { role: 'user', content: userPrompt },
          ],
          temperature,
        }),
      });
      if (!res.ok) {
        const body = await res.text().catch(() => '');
        return {
          ok: false,
          provider,
          model,
          text: '',
          httpStatus: res.status,
          error: `Cohere HTTP ${res.status}: ${body.slice(0, 180) || res.statusText}`,
        };
      }
      const data = await res.json();
      const text = (data?.message?.content ?? [])
        .filter((b: { type?: string; text?: string }) => b.type === 'text')
        .map((b: { text: string }) => b.text)
        .join('')
        .trim();
      return { ok: true, provider, model, text, httpStatus: res.status };
    }

    // OpenAI-compatible providers: Groq, NVIDIA NIM, OpenRouter
    const modelsToTry = meta.fallbackModel ? [meta.defaultModel, meta.fallbackModel] : [meta.defaultModel];
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${apiKey}`,
    };
    if (provider === 'openrouter') {
      headers['HTTP-Referer'] = 'https://sarfealam.autostudio.app';
      headers['X-Title'] = 'Sarfealam Auto-Studio';
    }

    let lastStatus = 0;
    let lastErr = '';
    for (const model of modelsToTry) {
      const res = await fetch(meta.endpoint, {
        method: 'POST',
        headers,
        body: JSON.stringify({
          model,
          messages: [
            { role: 'system', content: systemPrompt },
            { role: 'user', content: userPrompt },
          ],
          temperature,
        }),
      });
      lastStatus = res.status;
      if (res.ok) {
        const data = await res.json();
        const text = (data?.choices?.[0]?.message?.content ?? '').trim();
        return { ok: true, provider, model, text, httpStatus: res.status };
      }
      const body = await res.text().catch(() => '');
      lastErr = `${meta.label} (${model}) HTTP ${res.status}: ${body.slice(0, 180) || res.statusText}`;
      if (res.status !== 400 && res.status !== 404) break;
    }

    return {
      ok: false,
      provider,
      model: meta.defaultModel,
      text: '',
      httpStatus: lastStatus,
      error: lastErr || `${meta.label} request failed`,
    };
  } catch (err) {
    return {
      ok: false,
      provider,
      model: meta.defaultModel,
      text: '',
      httpStatus: 0,
      error: err instanceof Error ? err.message : 'Network error calling AI provider',
    };
  }
}

export async function testProviderKey(
  provider: AIProviderId,
  apiKey: string
): Promise<ProviderTestResult> {
  const key = apiKey.trim();
  const meta = AI_PROVIDERS[provider];
  const started = performance.now();

  if (!key) {
    return {
      ok: false,
      httpStatus: 0,
      latencyMs: 0,
      model: meta.defaultModel,
      message: 'Enter an API key before testing.',
      testedAt: Date.now(),
    };
  }

  try {
    let res: Response;
    let modelUsed = meta.defaultModel;

    if (provider === 'gemini') {
      res = await fetch(
        `${meta.endpoint}/models/${meta.defaultModel}:generateContent?key=${encodeURIComponent(key)}`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            contents: [{ role: 'user', parts: [{ text: 'Reply with OK.' }] }],
          }),
        }
      );
    } else if (provider === 'cohere') {
      res = await fetch(meta.endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${key}`,
        },
        body: JSON.stringify({
          model: meta.defaultModel,
          messages: [{ role: 'user', content: 'Reply with OK.' }],
          max_tokens: 8,
        }),
      });
    } else {
      const headers: Record<string, string> = {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${key}`,
      };
      if (provider === 'openrouter') {
        headers['HTTP-Referer'] = 'https://sarfealam.autostudio.app';
        headers['X-Title'] = 'Sarfealam Auto-Studio';
      }
      res = await fetch(meta.endpoint, {
        method: 'POST',
        headers,
        body: JSON.stringify({
          model: meta.defaultModel,
          messages: [{ role: 'user', content: 'Reply with OK.' }],
          max_tokens: 8,
        }),
      });

      if (!res.ok && (res.status === 400 || res.status === 404) && meta.fallbackModel) {
        modelUsed = meta.fallbackModel;
        res = await fetch(meta.endpoint, {
          method: 'POST',
          headers,
          body: JSON.stringify({
            model: modelUsed,
            messages: [{ role: 'user', content: 'Reply with OK.' }],
            max_tokens: 8,
          }),
        });
      }
    }

    const latencyMs = Math.round(performance.now() - started);
    if (res.ok) {
      return {
        ok: true,
        httpStatus: res.status,
        latencyMs,
        model: modelUsed,
        message: `Verified (${modelUsed})`,
        testedAt: Date.now(),
      };
    }

    const errBody = await res.text().catch(() => '');
    return {
      ok: false,
      httpStatus: res.status,
      latencyMs,
      model: modelUsed,
      message: errBody.slice(0, 140) || res.statusText,
      testedAt: Date.now(),
    };
  } catch (err) {
    return {
      ok: false,
      httpStatus: 0,
      latencyMs: Math.round(performance.now() - started),
      model: meta.defaultModel,
      message: err instanceof Error ? err.message : 'Network error',
      testedAt: Date.now(),
    };
  }
}

export async function testGitHubPat(
  username: string,
  pat: string
): Promise<{ ok: boolean; httpStatus: number; scopes: string[]; login?: string; message: string }> {
  const token = pat.trim();
  if (!token) {
    return { ok: false, httpStatus: 0, scopes: [], message: 'Enter a GitHub PAT token first.' };
  }
  try {
    const res = await fetch('https://api.github.com/user', {
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: 'application/vnd.github+json',
      },
    });
    const scopesHeader = res.headers.get('x-oauth-scopes') || '';
    const scopes = scopesHeader
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean);

    if (!res.ok) {
      return {
        ok: false,
        httpStatus: res.status,
        scopes,
        message: `HTTP ${res.status}: ${res.statusText || 'Authentication failed'}`,
      };
    }

    const data = await res.json();
    const login = typeof data?.login === 'string' ? data.login : username;
    const hasRepo = scopes.length === 0 || scopes.includes('repo');
    const hasWorkflow = scopes.length === 0 || scopes.includes('workflow');
    const scopeSummary =
      scopes.length > 0
        ? `Scopes: ${scopes.join(', ')}`
        : 'Fine-grained PAT verified';

    return {
      ok: true,
      httpStatus: res.status,
      scopes,
      login,
      message: `Authenticated as @${login}. ${scopeSummary}${!hasRepo || !hasWorkflow ? ' (ensure repo + workflow scopes)' : ''}`,
    };
  } catch (err) {
    return {
      ok: false,
      httpStatus: 0,
      scopes: [],
      message: err instanceof Error ? err.message : 'Network error contacting GitHub',
    };
  }
}

export interface GitHubVaultItem {
  name: string;
  path: string;
  type: 'file' | 'dir';
  size: number;
  download_url: string | null;
  html_url: string;
}

export async function fetchGitHubVaultContents(
  repoSlug: string,
  path = '',
  pat?: string
): Promise<{ ok: boolean; httpStatus: number; items: GitHubVaultItem[]; message: string }> {
  const cleanRepo = repoSlug.trim().replace(/^https?:\/\/github\.com\//i, '').replace(/\/+$/, '');
  if (!cleanRepo || !cleanRepo.includes('/')) {
    return { ok: false, httpStatus: 0, items: [], message: 'Invalid repo format. Expected owner/repo.' };
  }

  const cleanPath = path.replace(/^\/+/, '');
  const url = `https://api.github.com/repos/${cleanRepo}/contents/${cleanPath}`;
  const headers: Record<string, string> = {
    Accept: 'application/vnd.github+json',
  };
  if (pat?.trim()) {
    headers.Authorization = `Bearer ${pat.trim()}`;
  }

  try {
    const res = await fetch(url, { headers });
    if (!res.ok) {
      return {
        ok: false,
        httpStatus: res.status,
        items: [],
        message:
          res.status === 404
            ? `Repository or path not found (HTTP 404). Add a GitHub PAT in Secrets if "${cleanRepo}" is private.`
            : `GitHub HTTP ${res.status}: ${res.statusText}`,
      };
    }
    const data = await res.json();
    const list: GitHubVaultItem[] = Array.isArray(data)
      ? data.map((item: GitHubVaultItem) => ({
          name: item.name,
          path: item.path,
          type: item.type,
          size: item.size || 0,
          download_url: item.download_url || null,
          html_url: item.html_url || '',
        }))
      : [];
    return {
      ok: true,
      httpStatus: res.status,
      items: list,
      message: `Loaded ${list.length} items from ${cleanRepo}${cleanPath ? '/' + cleanPath : ''}`,
    };
  } catch (err) {
    return {
      ok: false,
      httpStatus: 0,
      items: [],
      message: err instanceof Error ? err.message : 'Network error contacting GitHub API',
    };
  }
}
